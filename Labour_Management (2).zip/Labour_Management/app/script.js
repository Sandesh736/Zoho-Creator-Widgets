

 let labourPhotoBase64 = "";// Variable to store captured image


getProductionIndent();
getPO();
getJobAssigment();
getContractors();
getSO();
// let ID = "";
// let Img_URL = "";
let hours;
let portal_access = "";

 let capturedImageFile = null;

   ZOHO.CREATOR.UTIL.getQueryParams().then(function (response_params) {
      const log_in_details = JSON.parse(response_params.log_in_details_info);
      portal_access = log_in_details.portal_access;
       console.log("portal_access",portal_access);
   });

// Initialize Select2 for production indent dropdown
$(document).ready(function () {
  // Initialize all Select2 dropdowns
  $('#production-indent').select2({ placeholder: "Select Indents", allowClear: true, width: 'resolve' });
  $('#po').select2({ placeholder: "Select POs", allowClear: true, width: 'resolve' });
  $('#sales-order').select2({ placeholder: "Select SOs", allowClear: true, width: 'resolve' });

  // ✅ Hide all Select2 containers initially
  $('#production-indent').next('.select2-container').hide();
  $('#po').next('.select2-container').hide();
  $('#sales-order').next('.select2-container').hide();
});

// Start camera on page load

  function toggleField(containerId) {
    console.log("Containerid",containerId);
   
  if(containerId =="sales-order")
  {
    console.log("show sales order");
    $('#sales-order').next('.select2-container').show();
    document.getElementById("Sales-Order").style.display = "block";
    $('#po').next('.select2-container').hide();
     $('#production-indent').next('.select2-container').hide();
      document.getElementById("Production-Indent").style.display = "none";
       document.getElementById("PO").style.display = "none";


  }
    
  if(containerId =="production-indent")
  {
    console.log("show_production_indent");
    $('#production-indent').next('.select2-container').show();
    document.getElementById("Production-Indent").style.display = "block";
     $('#sales-order').next('.select2-container').hide();
      $('#po').next('.select2-container').hide();
       document.getElementById("PO").style.display = "none";
        document.getElementById("Sales-Order").style.display = "none";
  }
  if(containerId =="po")
  {
    console.log("show po");
    $('#po').next('.select2-container').show();
    document.getElementById("PO").style.display = "block";
      $('#po').next('.select2-container').hide();
     $('#production-indent').next('.select2-container').hide();
      document.getElementById("Production-Indent").style.display = "none";
      document.getElementById("Sales-Order").style.display = "none";
  }
  
   
  }
  function showHideFields(need_so, need_production_indent, need_purchase_order) {
    // Sales Order
    if (need_so === "true") {
        $('#sales-order').next('.select2-container').show();
        document.getElementById("Sales-Order").style.display = "block";
    } else {
        $('#sales-order').next('.select2-container').hide();
        document.getElementById("Sales-Order").style.display = "none";
    }

    // Production Indent
    if (need_production_indent === "true") {
        $('#production-indent').next('.select2-container').show();
        document.getElementById("Production-Indent").style.display = "block";
    } else {
        $('#production-indent').next('.select2-container').hide();
        document.getElementById("Production-Indent").style.display = "none";
    }

    // PO
    if (need_purchase_order === "true") {
        $('#po').next('.select2-container').show();
        document.getElementById("PO").style.display = "block";
    } else {
        $('#po').next('.select2-container').hide();
        document.getElementById("PO").style.display = "none";
    }
}


  
  function capturePhoto(cameraID) {
  
    let canvas_id = "captured-image";

    document.querySelector('.camera-container').style.display = 'block';

     const recapture_btn = document.getElementById("recapture-btn");
     recapture_btn.style.display = "none";
      const capture_btn = document.getElementById("capture-btn");
      capture_btn.style.display = "block";

      if(cameraID=="camera-job")
      {
        clearInputs();
        document.getElementById("camera-container-job").style.display = 'block';
        document.getElementById("qr-scanner-box-job").style.display = 'none';
        document.getElementById("capture-btn-job").style.display="block";
        document.getElementById("recapture-btn-job").style.display="none";
        canvas_id = "captured-image-job";
      
      

      }
      if(cameraID=="camera-attendance")
      {
        clearinputsAttendance();
        document.getElementById("camera-container-attendance").style.display = 'block';
        document.getElementById("qr-scanner-box-attendance").style.display = 'none';
        document.getElementById("capture-btn-attendance").style.display="block";
        document.getElementById("recapture-btn-attendance").style.display="none";
        canvas_id = "captured-image-attendance";

      }
      if(cameraID=="camera-break")
      {
        document.getElementById("camera-container-attendance").style.display = 'block';
        document.getElementById("qr-scanner-box-attendance").style.display = 'none';
        document.getElementById("capture-btn-attendance").style.display="block";
        document.getElementById("recapture-btn-attendance").style.display="none";
        canvas_id = "captured-image-break";

      }
 
     const video = document.getElementById(cameraID);
     video.style.display = "block"; // Show video element

   
 const constraints = {
        video: {
            facingMode: 'environment', // This specifies the back camera
            aspectRatio: 1
            // width: { ideal: 500 },    // Optional resolution settings
            // height: { ideal: 500 }
        }
    };

    navigator.mediaDevices.getUserMedia(constraints)
      .then((stream) => {
        // cameraStream = stream;
        video.srcObject = stream;
      })
      .catch((err) => {
        console.error("Camera error:", err);
        show_alert("Error", "Unable to access camera");
      });
    //  const video = document.getElementById("camera");
    const canvas = document.getElementById(canvas_id);
    const context = canvas.getContext("2d");

    // Set canvas size same as video
    canvas.width = video.videoWidth;
    canvas.height = video.videoHeight

    // Draw the current video frame to canvas
    context.drawImage(video, 0, 0, canvas.width, canvas.height);
     labourPhotoBase64 = canvas.toDataURL("image/png");
    // //console.log("Captured Image:", labourPhotoBase64);
    //if labourPhotoBase64 is empty, hide recapture button
    if(labourPhotoBase64=="data:,")
    {
      //console.log("Captured Image:", labourPhotoBase64);
      const recapture_btn = document.getElementById("recapture-btn");
      recapture_btn.style.display = "none";
      //console.log("check if");
    }
    //after capturing photo 
  else
    {
    document.getElementById("recapture-btn").style.display = "block";
    document.getElementById("capture-btn").style.display = "none";

    document.getElementById("recapture-btn-job").style.display = "block";
    document.getElementById("capture-btn-job").style.display = "none";

    document.getElementById("recapture-btn-attendance").style.display = "block";
    document.getElementById("capture-btn-attendance").style.display = "none";

    document.getElementById("recapture-btn-break").style.display = "block";
    document.getElementById("capture-btn-break").style.display = "none"
    // //console.log("base 64",labourPhotoBase64);
    //if attendance camera is used call getlabourIdbyFace function
    if(cameraID == "camera")
    {
      showLoading();
      const startTime = Date.now();
      getLabourIdByFace(labourPhotoBase64, cameraID) //here we pass base64 image and camera id
      .finally(() => {
       const elapsed = Date.now() - startTime;
       const minDuration = 3000; // 3 seconds
       const remaining = minDuration - elapsed;
       setTimeout(hideLoading, remaining > 0 ? remaining : 0);
      })
    }
    if(cameraID =="camera-attendance")
    {
      
      showLoading();
      const startTime = Date.now();
      getLabourIdByFace(labourPhotoBase64, cameraID) //here we pass base64 image and camera id
      .finally(() => {
       const elapsed = Date.now() - startTime;
       const minDuration = 3000; // 3 seconds
       const remaining = minDuration - elapsed;
       setTimeout(hideLoading, remaining > 0 ? remaining : 0);
      })

    }
    if(cameraID == "camera-job")
    {
      showLoading();
      const startTime = Date.now();
      getLabourIdByFace(labourPhotoBase64, cameraID)
      .finally(() => {
       const elapsed = Date.now() - startTime;
       const minDuration = 3000; // 3 seconds
       const remaining = minDuration - elapsed;
       setTimeout(hideLoading, remaining > 0 ? remaining : 0);
      })
    }
    if(cameraID =="camera-break")
    {
       showLoading();
      const startTime = Date.now();
      getLabourIdByFace(labourPhotoBase64, cameraID)
      .finally(() => {
       const elapsed = Date.now() - startTime;
       const minDuration = 3000; // 3 seconds
       const remaining = minDuration - elapsed;
       setTimeout(hideLoading, remaining > 0 ? remaining : 0);
      })

    }
    capturedImageFile = dataURLtoFile(labourPhotoBase64, "captured_photo.png");
    //console.log("Captured File Object:", capturedImageFile);
    //console.log("size",capturedImageFile.size);
   if (capturedImageFile.size > 1048576)
   {
       show_alert("Error","File size should be less than 1 MB.");
   }
   
    stopCamera(cameraID);
}

    // Optionally show the canvas
    canvas.style.display = "block";
    
   
  }
  function hideMuliselectDropdown()
  {
  $('#production-indent').next('.select2-container').hide();
  $('#po').next('.select2-container').hide();
  $('#sales-order').next('.select2-container').hide();

  document.getElementById("Sales-Order").style.display = "none";
  document.getElementById("Production-Indent").style.display = "none";
  document.getElementById("PO").style.display = "none";


  }


  function dataURLtoFile(dataurl, filename) {
   
  const arr = dataurl.split(',');
  const matchResult = arr[0].match(/:(.*?);/);
  const mime = matchResult ? matchResult[1] : ''; // Safely handle null case
  // const mime = arr[0].match(/:(.*?);/)[1]; // extract MIME type
  const bstr = atob(arr[1]); // decode base64
  let n = bstr.length;
  const u8arr = new Uint8Array(n);

  while (n--) {
    u8arr[n] = bstr.charCodeAt(n);
  }

  return new File([u8arr], filename, { type: mime });

}
function recapturePhoto(canvasID,cameraID) {
  const canvas = document.getElementById(canvasID);
  const context = canvas.getContext("2d");
    document.querySelector('.camera-container').style.display = 'block';
      if(cameraID=="camera-job")
      {
        clearInputs();
        document.getElementById("camera-container-job").style.display = 'block';
        document.getElementById("qr-scanner-box-job").style.display = 'none';
        document.getElementById("capture-btn-job").style.display="block";
        document.getElementById("recapture-btn-job").style.display="none";

      }
      if(cameraID=="camera-attendance")
      {
        clearinputsAttendance();
        document.getElementById("camera-container-attendance").style.display = 'block';
        document.getElementById("qr-scanner-box-attendance").style.display = 'none';
        document.getElementById("capture-btn-attendance").style.display="block";
        document.getElementById("recapture-btn-attendance").style.display="none";
       

      }
      if(cameraID =="camera-break")
      {
         clearInputsBreak();
         document.getElementById("camera-container-break").style.display = 'block';
         document.getElementById("qr-scanner-box-break").style.display = 'none';
         document.getElementById("capture-btn-break").style.display="block";
         document.getElementById("recapture-btn-break").style.display="none";
      }
  const recapture_btn = document.getElementById("recapture-btn");
  const captured_btn = document.getElementById("capture-btn");
  captured_btn.style.display = "block";
  recapture_btn.style.display = "none";

  document.getElementById("capture-btn-job").style.display ="block";
  document.getElementById("recapture-btn-job").style.display ="none";

  document.getElementById("capture-btn-attendance").style.display ="block";
  document.getElementById("recapture-btn-attendance").style.display ="none";

  document.getElementById("capture-btn-break").style.display ="block";
  document.getElementById("recapture-btn-break").style.display ="none";

  // Clear canvas
  context.clearRect(0, 0, canvas.width, canvas.height);
  canvas.style.display = "none";

  // Reset captured image string
  labourPhotoBase64 = "";
  const video = document.getElementById(cameraID);
  video.style.display = "block";

  const constraints = {
        video: {
            facingMode: 'environment', // This specifies the back camera
            aspectRatio: 1             // width: { ideal: 300 },    // Optional resolution settings
            // width: { ideal: 500 },    // Optional resolution settings
            // height: { ideal: 500 }
        }
    };


  // Restart the camera
  

  navigator.mediaDevices.getUserMedia(constraints)
    .then((stream) => {
      //  cameraStream = stream; 
      video.srcObject = stream;

      // video.onloadedmetadata = () => {
      //   video.play();
      // };
    })
    .catch((err) => {
      console.error("Camera error:", err);
      show_alert("Error","Unable to access camera");
    });
}



function stopCamera(cameraID) {
  //console.log("camera id",cameraID);
  const video = document.getElementById(cameraID);
  // video.style.display = "none"; // Hide video element
  const stream = video.srcObject;

  if (stream) {
    const tracks = stream.getTracks(); // Get all media tracks (video/audio)
    tracks.forEach(track => track.stop()); // Stop each track
    video.srcObject = null; // Clear video source
    video.style.display = "none"; // Hide video element
    //console.log("Camera stopped.");
  }

}
//this function will fetch labour data by scanning face 
// here we pass base64 image and camera id from capture function
async function getLabourIdByFace(base64, cameraID) {
  let pureBase64 = base64.replace("data:image/png;base64,", "");


  let url = "https://pehechan-api-803399936090.asia-south1.run.app/labour/face_attendance";

  return fetch(url, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({ image_base64: pureBase64 })
  })
  .then(response => {
    if (!response.ok) {
      // show_alert("Error",`${response.status}`);
      console.log("Error",response);
      throw new Error(`HTTP error! status: ${response.status}`);
      
      
    }
    return response.json();
  })
  .then(async data => {
    // console.log("Response from server:", data);
    let labourID = data.lid;
    let confidence = data.confidence;
    // console.log("id",labourID);
    console.log("confidence",confidence);
    // if( cameraID == "camera-attendance" || cameraID =="camera-job" && confidence < 0.89)
    // {
    // show_alert("Error","Labour not found");
    // //console.log("labour not found");
    // return;
    // }
       

    if(cameraID == "camera" && labourID !=null && confidence > 0.70)
    {

      // //console.log("test camera");
      let labour_data = await getLabourData(labourID);
      // //console.log("Labour Data:", labour_data);
      let labour_name = labour_data.Labour_Name;
      let labour_id = labour_data.ID;
      let contractor_data = labour_data.Contractor;
      let contractor_name = contractor_data.NAME_WITH_CODE;
      show_alert("Error","Labour Already Exist ID:"+ labour_id +" Name: "+ labour_name +" Contractor: "+contractor_name);
      document.getElementById("selected-job").value = "";
      document.getElementById("labour-id").value = "";
      document.getElementById("labour-name").value = "";
      document.getElementById("labour-contact").value = "";
      // document.getElementById("add-labour-btn").style.display ="none";
    }
    else
    {
      document.getElementById("add-labour-btn").style.display ="block";
    }


    if (cameraID == "camera-attendance" && confidence > 0.70) {
      show_alert("Success","Confidence: "+ confidence);
      
      // //console.log("Labour ID:", labourID);
      document.getElementById("labour-rec-id-attendance").value = labourID;

       document.getElementById("scan-by-attendance").value ="";
       document.getElementById("scan-by-attendance").value ="Face";
      getLabourData(labourID); //pass rec id
      showhidebtn(labourID); //pass rec id
    }
    if(cameraID == "camera-attendance" && confidence < 0.70)
    {
      show_alert("Error","Labour not found");
      //console.log("labour not found attendance");

    }
    if (cameraID == "camera-job" && confidence > 0.70) {
         show_alert("Success","Confidence: "+ confidence);
        document.getElementById("labour-id").value = labourID;
        document.getElementById("scan-by-attendance").value ="";
       document.getElementById("scan-by-job").value ="Face";
      getOpenJobAssignment(labourID); //pass rec id
      getNameAndContractor(labourID); //pass rec id
    }
    if(cameraID == "camera-job" && confidence < 0.70)
    {
      show_alert("Error","Labour not found");
      //console.log("labour not found job");
    }
    if(cameraID=="camera-break" && confidence > 0.70)
    {
      show_alert("Success","Confidence: "+confidence);
      document.getElementById("scan-by-break").value ="Face";
      GetLabourAttendaceByID(labourID);
    }

  })
  .catch(error => {
    console.error("Error:", error);
    // show_alert("Error","Failed to Fetch");
  });
}

function showLoading() {
  document.getElementById("loading-overlay").style.display = "block";
  document.getElementById("loading").style.display = "block";
  document.body.style.overflow = "hidden";


}

function hideLoading() {
  document.getElementById("loading-overlay").style.display = "none";
  document.getElementById("loading").style.display = "none";
  document.body.style.overflow = "";

}


  
  //show scan qr for job assignment
  function showQRView() {
    document.getElementById("main-menu").classList.add("hidden");
    document.getElementById("qr-scan-view").classList.remove("hidden");

    // if(btn =="Assign-Job")
    // {
    //   document.getElementById("closejob").style.display = "none";
    //   document.getElementById("assign-job").style.display = "block";

    // }
    // else
    // {
      
    //    document.getElementById("assign-job").style.display = "none";
    //    document.getElementById("closejob").style.display = "block";
    // }
    startQRScanner("qr-reader");
  }
 async function showJobAuditView() {
  document.getElementById("main-menu").classList.add("hidden");
  document.getElementById("Job-Audit").classList.remove("hidden");
  const jobs = await getjobforaudit();
  console.log("jobs",jobs);
  renderJobsGrid(jobs);

}

function renderJobsGrid(jobs) {
const container = document.getElementById("Job-Audit");
container.innerHTML = ""; // clear old contents

if (!jobs || jobs.length === 0) {
  container.innerHTML = "<p>No jobs found.</p>";
  return;
}

// 🔹 Create header section
const header = document.createElement("div");
header.className = "job-audit-header";
header.style.display = "flex";

// 🔹 Go Back Button
const backButton = document.createElement("button");
backButton.className = "back-btn";
backButton.style.backgroundColor = "#2e6f40";
backButton.style.color = "white";

// Create the icon element
const icon = document.createElement("i");
icon.className = "bi bi-arrow-left-circle-fill";
icon.style.marginRight = "8px"; // Optional spacing between icon and text

// Add icon and text to the button
backButton.appendChild(icon);
backButton.appendChild(document.createTextNode("Back To Main Menu"));

// Append button to desired location, for example:
document.body.appendChild(backButton);


// 🔹 Go Back Logic
backButton.addEventListener("click", () => {
  document.getElementById("Job-Audit").classList.add("hidden");
  document.getElementById("main-menu").classList.remove("hidden");
});

header.appendChild(backButton);

// 🔹 Add header to container
container.appendChild(header);

// 🔹 Create jobs grid
const grid = document.createElement("div");
grid.className = "jobs-grid";

// 🔹 Add "Unassigned" item first
const unassignedItem = document.createElement("div");
unassignedItem.className = "grid-item";
unassignedItem.textContent = "Unassigned";
unassignedItem.value = "unassigned";
unassignedItem.style.backgroundColor ="#FF7074	";
unassignedItem.style.color = "white";

unassignedItem.addEventListener("click", async () => {
  let unassigned_labour = await GetUnAssignedLabour();
  openUnassignedModal(unassigned_labour);
});

grid.appendChild(unassignedItem);

// 🔹 Add jobs from array
jobs.forEach(job => {
  const item = document.createElement("div");
  item.className = "grid-item";
  item.textContent = job.Job || "Unnamed Job";
  item.value = job.ID || "";

  item.addEventListener("click", () => openJobModal(job));

  grid.appendChild(item);
});

// 🔹 Append grid to container
container.appendChild(grid);

}
async function openJobModal(job) {
  const modal = document.getElementById("jobModal");
  const title = document.getElementById("modalJobTitle");
  const id = document.getElementById("JobEntryCount");

  const entriesContainer = document.getElementById("modalJobEntries");

  title.textContent = job.Job || "Unknown Job";



  // Clear previous entries
  entriesContainer.innerHTML = "<p>Loading entries...</p>";

  try {
    const job_entries = await GetJobEntry(job.ID); // Your async fetching of entries

    if (!job_entries || job_entries.length === 0) {
      entriesContainer.innerHTML = "<p>No entries found for this job.</p>";
      id.textContent = `Total Assigned: ${job_entries.length}`;
     
    } else {
      id.textContent = `Total Assigned: ${job_entries.length}`;
      
      entriesContainer.innerHTML = ""; // clear loading text

      // Render each entry as a grid item
      job_entries.forEach(async entry => {
        const entryDiv = document.createElement("div");
entryDiv.className = "job-entry-item";

let labour_name = entry.Labour_Name;
let labour_data = await getLabourData(labour_name.ID);

let startDate = parseCustomDateTime(entry.Start_Time);
let currentDate = new Date();
let durationMs = currentDate - startDate;
let durationStr = formatDuration(durationMs);

let imageId = `labour-img-${labour_name.ID}`;
let btnId = `toggle-btn-${labour_name.ID}`;

// HTML content
entryDiv.innerHTML = `
  <button id="${btnId}" 
    style="
      background-color: #007bff;
      color: white;
      border: none;
      padding: 6px 12px;
      border-radius: 5px;
      cursor: pointer;
      font-size: 14px;
      margin-bottom: 5px;
    ">
    Show Image
  </button><br>

  <a href="${labour_data.Image_Url}" target="_blank" rel="noopener">
    <img id="${imageId}" src="${labour_data.Image_Url}" alt="Labour Image" 
         style="max-width: 100px; max-height: 100px; margin-top: 5px; display: none;">
  </a><br>

  <strong>${labour_name.Labour_Name || 'Entry'}</strong><br>
  Assigned Time: ${entry.Start_Time || 'N/A'}<br>
  Job Duration: ${durationStr || 'N/A'}
`;

// Toggle behavior
setTimeout(() => {
  const img = document.getElementById(imageId);
  const btn = document.getElementById(btnId);

  btn.addEventListener("click", () => {
    const isVisible = img.style.display !== "none";
    img.style.display = isVisible ? "none" : "block";
    btn.textContent = isVisible ? "Show Image" : "Hide Image";
  });
}, 0);

        entriesContainer.appendChild(entryDiv);
      });
    }
  } catch (error) {
    entriesContainer.innerHTML = `<p>Error loading entries.</p>`;
    console.error("Failed to fetch job entries:", error);
  }

  // Show modal
  modal.classList.remove("hidden");
}

async function openUnassignedModal(unassignedLabour) {
  try {
  const modal = document.getElementById("jobModal");
  const title = document.getElementById("modalJobTitle");
  const id = document.getElementById("JobEntryCount");
  const entriesContainer = document.getElementById("modalJobEntries");

  // Set title and clear content
  title.textContent = "Unassigned Labour";
  id.textContent = `Total Unassigned: ${unassignedLabour.length}`;
  entriesContainer.innerHTML = "";

  // Show entries
  if (!unassignedLabour || unassignedLabour.length === 0) {
    entriesContainer.innerHTML = "<p>No unassigned labour found.</p>";
  } else {
    for (const labour of unassignedLabour) {
      try {
        const entryDiv = document.createElement("div");
        entryDiv.className = "job-entry-item";

        let labour_data = await getLabourData(labour.Labour_Name.ID);
        let imageId = `labour-img-${labour.Labour_Name.ID}`;
        let btnId = `toggle-btn-${labour.Labour_Name.ID}`;

        console.log("labour_data", labour_data);

        entryDiv.innerHTML = `
          <button id="${btnId}" 
            style="
              background-color: #28a745;
              color: white;
              border: none;
              padding: 6px 12px;
              border-radius: 5px;
              cursor: pointer;
              font-size: 14px;
              margin-bottom: 5px;
            ">
            Show Image
          </button><br>

          <a href="${labour_data.Image_Url}" target="_blank" rel="noopener">
            <img id="${imageId}" src="${labour_data.Image_Url}" alt="Labour Image" 
                 style="max-width: 100px; max-height: 100px; margin-top: 5px; display: none;">
          </a><br>

          <strong>${labour.Labour_Name.Labour_Name || 'Unnamed Labour'}</strong><br>
          Log In Time: ${labour.Log_In_Time || 'N/A'}
        `;

        // Toggle behavior
        setTimeout(() => {
          const img = document.getElementById(imageId);
          const btn = document.getElementById(btnId);
          if (btn && img) {
            btn.addEventListener("click", () => {
              const isVisible = img.style.display !== "none";
              img.style.display = isVisible ? "none" : "block";
              btn.textContent = isVisible ? "Show Image" : "Hide Image";
            });
          }
        }, 0);

        entriesContainer.appendChild(entryDiv);
      } catch (entryErr) {
        console.error("Error while processing an unassigned labour entry:", entryErr);
          const id = document.getElementById("JobEntryCount")
          id.textContent = `Total Unassigned: 0`;
        entriesContainer.innerHTML += `<p style="color:red;">No Unassigned Labours</p>`;
      }
    }
  }

  modal.classList.remove("hidden");
} catch (err) {
  console.error("Failed to display unassigned labours:", err);
  const entriesContainer = document.getElementById("modalJobEntries");
  if (entriesContainer) {
    entriesContainer.innerHTML = `<p style="color:red;">No Unassigned Labours</p>`;
  }
}

}


function closeJobModal() {
  const modal = document.getElementById("jobModal");
  modal.classList.add("hidden");
}

// Close modal when clicking on close button
document.getElementById("modalClose").addEventListener("click", closeJobModal);

// Optional: close modal when clicking outside modal-content
document.getElementById("jobModal").addEventListener("click", (e) => {
  if (e.target === e.currentTarget) {
    closeJobModal();
  }
});


//for job audit
// GetJobEntry("196425000010700946")
async function GetJobEntry(ID)
{

  

  try {
        const allRecords = [];
        let recordCursor = "";
        let config = {};

        do {
            config = {
             app_name: "inventory",
             report_name: "All_Job_Entries",
             criteria: "Job == " + ID + " && End_Time == null && Start_Time != null" ,
             max_records: 1000,
             record_cursor: recordCursor
            };

            const response = await ZOHO.CREATOR.DATA.getRecords(config);
            recordCursor = response?.record_cursor;

            if (response.code === 3000) {
                allRecords.push(...response.data);
                // console.log("job entries",allRecords);
              
                console.log("job entries",response.data);
            }
        } while (recordCursor);
          return allRecords;
    } catch (error) {
        // console.error("Error fetching records from All Quizzes:, error");
        return [];
    }

}
async function GetUnAssignedLabour()
{
 
  
  try {
        const allRecords = [];
        let recordCursor = "";
        let config = {};

        do {
            config = {
             app_name: "inventory",
             report_name: "All_Labour_Attendances",
            criteria: 'Job_Assigned == "No" && Log_Out_Time == null',
            // criteria:'Job_Assigned == "No"',
            max_records: 1000,
             record_cursor: recordCursor
            };

            const response = await ZOHO.CREATOR.DATA.getRecords(config);
            recordCursor = response?.record_cursor;
            // console.log("reponse unassigned",response);

            if (response.code === 3000) {
                allRecords.push(...response.data);
                // console.log("job entries",allRecords);
              
                // console.log("unassigned labours",response.data);
            }
        } while (recordCursor);
          return allRecords;
    } catch (error) {
        // console.error("Error",error);
        return [];
    }

}

  
  function ShowBreakView(btn)
  {
    document.getElementById("main-menu").classList.add("hidden");
    document.getElementById("Break").classList.remove("hidden");
    if(btn =="BreakIn")
    {
      document.getElementById("BreakIn").style.display = "block";
      document.getElementById("BreakOut").style.display ="none";
       document.getElementById("break-out").style.display ="block";
       document.getElementById("break-out-label").style.display="block";
    }
    else
    {
       document.getElementById("BreakIn").style.display = "none";
       document.getElementById("BreakOut").style.display = "block";
       document.getElementById("break-out").style.display ="none";
       document.getElementById("break-out-label").style.display="none";
    }
    startQRScanner('qr-reader-break');

  }

    
let qrReaderInstance = null; // Make this global
let scannedData = null;

let isScannerRunning = false;

function startQRScanner(qrID) {
  // Reset container state
    clearInputs();
    clearinputsAttendance();
    clearInputsBreak();
     //dispaly qr-scanner box of job,attendance,break
     document.getElementById("qr-scanner-box-job").style.display = 'flex';
     document.getElementById("qr-scanner-box-attendance").style.display = 'flex';
     document.getElementById("qr-scanner-box-break").style.display ='flex';
    //hide camera container of job,attendance,break 
     document.getElementById("camera-container-attendance").style.display = 'none';
     document.getElementById("camera-container-job").style.display = 'none';
     document.getElementById("camera-container-break").style.display = 'none';

    // hide qr success message of job,attendance
     document.getElementById("qr-success-msg").style.display = "none";
     document.getElementById("qr-success-msg-break").style.display = "none";
     document.getElementById("qr-success-msg-job").style.display = "none";
      //display qr reader for job,attendance,break
     document.getElementById("qr-reader").style.display = "block";
     document.getElementById("qr-reader-container").style.display = "block";
     document.getElementById("qr-reader-break").style.display = "block";
     document.getElementById("qr-reader-attendance").style.display = "block";
 
 
  
  // document.getElementById("qr-border").style.display = "block";

  qrReaderInstance = new Html5Qrcode(qrID);
  qrReaderInstance.start(
    { facingMode: "environment" },
    { fps: 10, qrbox: { width: 250, height: 250 } },
    qrCodeMessage => {
      scannedData = qrCodeMessage;
       document.getElementById("labour-id").value = scannedData;
       document.getElementById("scan-by-job").value ="QR";
       document.getElementById("scan-by-attendance").value ="QR";
       document.getElementById("scan-by-break").value ="QR";

      //console.log("qr_id",qrID);
      
      if(qrID=="qr-reader-attendance")
      {
      getLabourData(scannedData);
      showhidebtn(scannedData);
      }
      if(qrID=="qr-reader")
      {
        getOpenJobAssignment(scannedData);
        getNameAndContractor(scannedData);
      }
      if(qrID =="qr-reader-break")
      {
        GetLabourAttendaceByID(scannedData);

      }

       document.getElementById("labour-rec-id-attendance").value= scannedData;
       
 

      isScannerRunning = false;
      qrReaderInstance.stop().then(() => {
        // ✅ Hide QR reader and animation
        document.getElementById("qr-reader").style.display = "none";
        document.getElementById("scan-line").style.display = "none";

        document.getElementById("qr-reader-attendance").style.display = "none";
        document.getElementById("scan-line-attendance").style.display = "none";

        document.getElementById("qr-reader-break").style.display = "none";
        document.getElementById("scan-line-break").style.display = "none";
        // document.getElementById("qr-border").style.display = "none";

        // ✅ Show success message
        document.getElementById("qr-success-msg").style.display = "block";
        document.getElementById("qr-success-msg-job").style.display = "block";
        document.getElementById("qr-success-msg-break").style.display = "block";

      });
    }
  ).then(() => {
     document.getElementById("scan-line").style.display = "block";
     document.getElementById("scan-line-attendance").style.display = "block";
     document.getElementById("scan-line-break").style.display = "block";
     isScannerRunning = true;
  }).catch(err => {
    console.error("Camera error:", err);
  });
}

function activateButton(button) {
  // Remove "active" from all action buttons
  document.querySelectorAll('.action-btn').forEach(btn => btn.classList.remove('active'));

  // Add "active" to the clicked button
  button.classList.add('active');
}


function AddLabour()
{
  let gender = "";
  let labourName = document.getElementById("labour-name").value;
  let labourContact = document.getElementById("labour-contact").value;
  let contractor = document.getElementById("Contractor").value;
  let SelectedGender = document.querySelector('input[name="Labour-gender"]:checked');
  if(SelectedGender)
  {
  gender =  document.querySelector('input[name="Labour-gender"]:checked').value;
  }
  
  // AddLabourCloud("196425000010182147",labourName,labourContact,contractor,gender);
  //console.log("capturedImageFile", capturedImageFile);
  // Optional contact validation
if (labourContact !== "" && (labourContact.length !== 10 || isNaN(labourContact)))
{
  show_alert("Error", "Enter valid 10-digit contact number");
  return;
}

 if (labourName === "" || contractor === "" || capturedImageFile == null || gender == "") 
{
  show_alert("Error", "Enter mandatory fields");
  return;
}
else
{

  var config = {
  app_name: "inventory",
  form_name: "Add_Labour",
  payload: {
    "data": {
        "Labour_Name": labourName,
        "Contact":labourContact,
        "Contractor":contractor,
        "Gender":gender
        
   }
  }
};
ZOHO.CREATOR.DATA.addRecords(config).then(function (response) {
  if (response.code == 3000) {
    console.log("Labour Added successfullly",response);
    const res_data = response.data;
    let labourId = res_data.ID;
     // Get the ID of the newly added record

    uploadCapturedImage(labourId, capturedImageFile);
    AddLabourCloud(labourId,labourName,labourContact,contractor,gender);
    // show_alert("Success","Labour Added Successfully");
    clearInputs(); // Clear inputs after successful addition
    recapturePhoto("captured-image","camera");
    
  }
    if(response.code==3001){

    console.error("Error adding record:",response);
    let error_msg = response.error[0].alert_message;
    show_alert("Error",error_msg);
  }
 
}).catch(function (e) {
  console.error("Error adding record:", e);
  show_alert("Error",JSON.stringify(e));
});
}

 
}
function showAddLabourView() {
  document.getElementById("main-menu").classList.add("hidden");
  document.getElementById("add-labour-view").classList.remove("hidden");

  capturePhoto('camera');
}
//show scan qr for attendance
function showScanQrAttendance(btn)
{
  // console.log("btn",btn);
  document.getElementById("main-menu").classList.add("hidden");


  document.getElementById("Attendance").classList.remove("hidden");
   if(btn == "LogIn")
  {
        
      document.getElementById("clock").style.display = "none";
      document.getElementById("LogIn").style.display = "block";
      document.getElementById("LogOut").style.display = "none";

      // console.log("dispaly log in");

  }
  if(btn == "LogOut")
  {
    // console.log("display log out");
    document.getElementById("clock").style.display = "flex";
    document.getElementById("LogOut").style.display = "block";
    document.getElementById("LogIn").style.display ="none";

  }
  
//  const qr_view =  document.getElementById("JobAssignment-view");
//  qr_view.appendChild(html_str);


  // Start the QR scanner
  startQRScanner("qr-reader-attendance");
}
// function AddLabourCloud(labourId, labourName, labourContact, contractor, gender)
// AddLabourCloud();
//this function will add labour to cloud
async function AddLabourCloud(labourId, labourName, labourContact, contractor, gender) {
  try {
    let pureBase64 = labourPhotoBase64.replace("data:image/png;base64,", "");

    const sanitize = (value) => {
      return value !== undefined && value !== null && String(value).trim() !== "" ? value : "NA";
    };

    const data = {
      address: sanitize("NA"),
      adhaar: sanitize("NA"),
      contractor_id: sanitize(contractor),
      dob: sanitize("NA"),
      doj: sanitize("NA"),
      gender: sanitize(gender),
      lid: sanitize(labourId),
      name: sanitize(labourName),
      pan: sanitize("NA"),
      phone_number: sanitize(labourContact),
      zc_id: sanitize(labourId),
      images_base64: [pureBase64]
    };

    const url = "https://pehechan-api-803399936090.asia-south1.run.app/labour/api/create";
    const response = await fetch(url, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data)
    });

    if (!response.ok) {
      console.log("errror in addlabourcloud",response);
      let response_status_text = response.statusText;
      throw new Error(response_status_text);
    }

    const result = await response.json();
    console.log("Success:", result);
    show_alert("Success","Labour Added Successfully");

    const img_url = result.labour.image_urls[0];
    console.log("img_url", img_url);

    // If you want to use a test static URL instead:
    // const Img_URL = `'${img_url}'`; // or use hardcoded: 'https://...jpg'
    const Img_URL = img_url;

    await UpdateImageUrl(labourId, Img_URL); // ✅ Use await

  } catch (error) {
    console.error("Error in AddLabourCloud:", error);
    show_alert("Error",JSON.stringify(error));
  }
}





async function UpdateImageUrl(ID, Img_URL ) {
  try {
    console.log("update function called", ID, Img_URL);

    let config = {
      app_name: "inventory",
      report_name: "All_Labour_Databases",
      id: ID,
      payload: {
        data: {
          "Image_Url": Img_URL 
        }
      }
    };

    const response = await ZOHO.CREATOR.DATA.updateRecordById(config);
    console.log("response", response);

    if (response.code == 3000) {
      console.log("✅ Image URL updated successfully", response);
    } else {
      console.error("❌ Failed to update. Response code:", response.code);
    }

  } catch (error) {
    console.error("❌ Error in UpdateImageUrl:", error);
    console.log("error",error);
    console.log("url and id in catch",Img_URL,ID);
  }
}


function getNameAndContractor(ID)
{

  var config = {
  app_name: "inventory",
  report_name: "All_Labour_Databases",
  id : ID
};
ZOHO.CREATOR.DATA.getRecordById(config).then(function (response) {
  //console.log("Labour record",response);
  if(response.code==3000)
  {
  let labour_data = response.data;
  
  let labour_name = labour_data.Labour_Name;
  let contract_data = labour_data.Contractor;
  let contractor_name = contract_data.NAME_WITH_CODE;
  let contractor_id = contract_data.ID;

  let labour_name_job = document.getElementById("labour-name-job");
  labour_name_job.value = labour_name;
  let contractor_name_job= document.getElementById("contractor-job");
  contractor_name_job.value = contractor_name;

  }
  else
  {
    //console.log("getnameandcontractor",response);
  }
}).catch(function(error){
  //console.log("error",error);
});
}





function goBack(cameraID,canvas_id) {

  const canvas = document.getElementById(canvas_id);
  const context = canvas.getContext("2d");

  // Clear the canvas
  context.clearRect(0, 0, canvas.width, canvas.height);

  // Hide the canvas
  canvas.style.display = "none";
   // Reset the base64 image variable if needed
  labourPhotoBase64 = "";
  stopCamera(cameraID);
  // stopcameraAttendance();

//    Stop QR scanner if running
 if (qrReaderInstance && isScannerRunning) {
    qrReaderInstance.stop().then(() => {
      qrReaderInstance.clear();
      isScannerRunning = false;
    }).catch(err => {
      console.warn("Error stopping camera:", err);
    });
  }

  // Hide QR scan view
  
  // Clear input field
  clearInputs();
  clearinputsAttendance();
  clearInputsBreak();
  document.getElementById("qr-scan-view").classList.add("hidden");
  document.getElementById("add-labour-view").classList.add("hidden");
 
  document.getElementById("Attendance").classList.add("hidden");
  document.getElementById("Break").classList.add("hidden");

  // Show main menu again
  document.getElementById("main-menu").classList.remove("hidden");
}
function clearInputs() {
  hideMuliselectDropdown();
  document.getElementById("selected-job").value = "";
  document.getElementById("labour-id").value = "";
  document.getElementById("labour-name").value = "";
  document.getElementById("labour-contact").value = "";
 let selectedRadio = document.querySelector('input[name="job-assignment-radio"]:checked');
  if (selectedRadio) {
    selectedRadio.checked = false;
  }
let selectedact = document.querySelector('input[name="activity-type"]:checked');
if(selectedact)
{
  selectedact.checked = false;
}
let SelectedGender = document.querySelector('input[name="Labour-gender"]:checked');
if(SelectedGender)
{
  SelectedGender.checked = false;
}
 let allRadioButtons = document.querySelectorAll('input[name="activity-type"]');
    let activity_type_container = document.getElementById("activity-type-job");

    // Enable all radio buttons
    allRadioButtons.forEach(radio => {
        radio.disabled = false;
        if (radio.parentElement.tagName.toLowerCase() === 'label') {
            radio.parentElement.style.backgroundColor = '';  // Reset label background
            radio.parentElement.style.cursor = 'pointer';    // Reset cursor
        }
    });

    // Reset container background color too if you changed it before
    activity_type_container.style.backgroundColor = '';


// let job_type = document.querySelector('input[name="job-assignment-radio"]:checked');
 let job_type_container = document.getElementById("job-assignment-section");
 let allRadioButtonsJob = document.querySelectorAll('input[name="job-assignment-radio"]');


   // enable all radio buttons in the group
     allRadioButtonsJob.forEach(radio => {
        radio.disabled = false;
       
        radio.parentElement.style.backgroundColor = ''; // Assuming labels wrap inputs
    });
    job_type_container.style.backgroundColor = '';

  document.getElementById('hours').value = '';
  document.getElementById('minutes').value = '';
  document.getElementById('seconds').value = '';
  
  // document.getElementById("Labour-gender").value = "";
  let contractor_name_job= document.getElementById("contractor-job");
  let labour_name_job = document.getElementById("labour-name-job");
  contractor_name_job.value = "";
  labour_name_job.value = "";
  capturedImageFile = null;
  document.getElementById("Contractor").value = "";

  $('#production-indent').val(null).trigger('change');
  $('#po').val(null).trigger('change');
  $('#sales-order').val(null).trigger('change');
  let production_indent_select = document.getElementById("production-indent");
    production_indent_select.innerHTML = '';
     $('#production-indent').prop('disabled', false);
    getProductionIndent();

    let po_select = document.getElementById("po");
    po_select.innerHTML = '';
    $('#po').prop('disabled',false);
    getPO();

    
     //hide assign and close job button
     document.getElementById("assign-job").style.display="none";
     document.getElementById("closejob").style.display="none"; 

     //hide start time field
     document.getElementById("start-time").style.display="none";
     //hide label of start time
      const start_time_label = document.getElementById("start-label");
      start_time_label.style.display="none";


}
function clearInputsBreak()
{
  document.getElementById("job-entry-id").value = "";
  document.getElementById("labour-name-break").value = "";
  document.getElementById("log-in-session").value = "";
  // document.getElementById("break-in").value = "";
  document.getElementById("break-out").value = "";
}

function getJobAssigment(){
 var config = {
  app_name: "inventory",
  report_name: "All_Job_Lists"
};
ZOHO.CREATOR.DATA.getRecords(config).then(function (response) {
  //console.log("Job Assignments:", response);
let job_assignment_data = response.data;
let jobContainer = document.getElementById("job-assignment");

// Sort job_assignment_data by Job name (A to Z, case-insensitive)
job_assignment_data.sort((a, b) => a.Job.localeCompare(b.Job, undefined, { sensitivity: 'base' }));

job_assignment_data.forEach(element => {
  // Create label wrapper
  let label = document.createElement("label");
  label.style.display = "flex";
  label.style.alignItems = "center";
  label.style.gap = "8px";
  label.style.padding = "8px 12px";
  label.style.border = "1px solid #ccc";
  label.style.borderRadius = "6px";
  label.style.cursor = "pointer";
  label.style.height = "100%";
  label.style.maxWidth = "100%";
  // label.style.flex = "1 1 200px"; // Optional: ensures wrapping & size

  // Create radio input
  let radio = document.createElement("input");
  radio.type = "radio";
  radio.name = "job-assignment-radio";
  radio.value = element.ID;

  // Create text node for job name
  let text = document.createTextNode(element.Job);

  // Append radio + text to label
  label.appendChild(radio);
  label.appendChild(text);

  // Append label to container
  jobContainer.appendChild(label);
});


});

}
function GetPOSOProductionIndentByJob(Job_ID) {
  var config = {
    app_name: "inventory",
    criteria: "ID == " + Job_ID,
    report_name: "All_Job_Lists"
  };

  ZOHO.CREATOR.DATA.getRecords(config).then(function (response) {
    console.log("getsopoproduction", response);

    if (response.code == 3000) {
      let job_data = response.data[0];
      console.log("job-data", job_data);

      let need_production_indent = job_data.Need_Production_Indent;
      let need_so = job_data.Need_Sales_Order;
      let need_purchase_order = job_data.Need_Purchase_Order;

      console.log("values", need_production_indent, need_so, need_purchase_order);
       showHideFields(need_so, need_production_indent, need_purchase_order);
      // if(need_production_indent =="true")
      // {
      //   console.log("need production indent")
      //    toggleField('production-indent');
      // }
      // if(need_so =="true")
      // {
      //   console.log("need so");
      //   toggleField('sales-order');
      // }
      // if(need_purchase_order == "true")
      // {
      //   console.log("need po");
      //    toggleField('po');

      // }

      
      
     
    }
  });
}

// function toggleField(containerId, shouldShow,labelId) {
//   const selectElement = $('#' + containerId);
//   const select2Container = selectElement.next('.select2-container');
//   const labelContainerId = labelId; // e.g. sales-order → Sales-Order
//   const labelContainer = document.getElementById(containerId);
//   hideMuliselectDropdown();
//   if (shouldShow) {
//     select2Container.show();
//     labelContainer.style.display = 'block';
//   } else {
//     select2Container.hide();
//     labelContainer.style.display = 'none';
//   }
// }







// getjobforaudit();
async function getjobforaudit()
{

  try {
        const allRecords = [];
        let recordCursor = "";
        let config = {};

        do {
            config = {
              app_name: "inventory",
              report_name: "All_Job_Lists",
              max_records: 1000,
              record_cursor: recordCursor
            };

            const response = await ZOHO.CREATOR.DATA.getRecords(config);
            recordCursor = response?.record_cursor;

            if (response.code === 3000) {
                allRecords.push(...response.data);
                console.log("all job records",allRecords);
                // fetchTopics(allRecords);
                console.log("response",response.data);
            }
        } while (recordCursor);
          return allRecords;
    } catch (error) {
        // console.error("Error fetching records from All Quizzes:, error");
        return [];
    }

}


function getProductionIndent()
{
   var ProductionIndent = {
  app_name: "inventory",
  report_name: "All_Production_Indents"
};
ZOHO.CREATOR.DATA.getRecords(ProductionIndent).then(function (response) {
  // //console.log("Job Assignments:", response);
 let  production_indent_data = response.data;
 //console.log("Production Indent Data:", production_indent_data);
 let production_indent_select = document.getElementById("production-indent");
 production_indent_data.forEach(element => {
  let option = document.createElement("option");
    option.value = element.ID;
    option.textContent = element.Production_Indent_ID;
   production_indent_select.appendChild(option);
 });

});

}
function getSO()
{
     var so = {
  app_name: "inventory",
  report_name: "Planned_Dispatch_List",
  criteria:'Plan_Stage == "Preparing"'
};
ZOHO.CREATOR.DATA.getRecords(so).then(function (response) {
console.log("so response:", response);
 let  data = response.data;
 let so_data;
 console.log("sales order:",data);
  let so_select = document.getElementById("sales-order");
 data.forEach(element =>{
   so_data = element.Sales_Order;


  let option = document.createElement("option");
    option.value = so_data.ID;
    option.textContent = so_data.SO_Number;
   so_select.appendChild(option);


 })

 console.log("so data",so_data);


//  so_data.forEach(element1 => {
//   let option = document.createElement("option");
//     option.value = element1.ID;
//     option.textContent = element1.SO_Number;
//    so_select.appendChild(option);
//  });

});
}
function getPO()
{

  var PO = {
  app_name: "inventory",
  report_name: "PO_Purchase_Order_History"
};
ZOHO.CREATOR.DATA.getRecords(PO).then(function (response) {
  // //console.log("Job Assignments:", response);
 let  po_data = response.data;
 //console.log("PO Data:", po_data);
 let po_select = document.getElementById("po");
 po_data.forEach(element => {
  let option = document.createElement("option");
    option.value = element.ID;
    option.textContent = element.PO_ID;
    po_select.appendChild(option);
 });

});


}
function getContractors()
{
   var Contractor = {
  app_name: "inventory",
  report_name: "All_Vendors",
 criteria: 'Business_Type == "Labour Contractor"'
};
ZOHO.CREATOR.DATA.getRecords(Contractor).then(function (response) {
  //console.log("contractor", response);
 let  contractor_data = response.data;
 //console.log("Contractor Data:", contractor_data);
 let contractor_select = document.getElementById("Contractor");
 contractor_data.forEach(element => {
  let option = document.createElement("option");
    option.value = element.ID;
    option.textContent = element.NAME_WITH_CODE;
    contractor_select.appendChild(option);
 });

});

}

function AddJobEntry()
{
  //  if (!scannedData) {
  //   show_alert("Error","Please scan a QR code first!");
  //   return;
  // }
  
let jobAssignment = "";
let activityType = "";

let selected = $('#production-indent').val();
//console.log("Selected:", selected); 
let poSelected = $('#po').val();
//console.log("PO Selected:", poSelected);
let soSelected = $('#sales-order').val();
let labourId = document.getElementById("labour-id").value;
let selectedActivity = document.querySelector('input[name="activity-type"]:checked');
if(selectedActivity)
{
  activityType = selectedActivity.value;
}

let selectedRadio = document.querySelector('input[name="job-assignment-radio"]:checked');
  if (selectedRadio)
  {
   jobAssignment = selectedRadio.value;
  }
  console.log("values",soSelected,poSelected,selected);
  let polength = poSelected.length;
  let solength = soSelected.length;
  let selectedlength = selected.length;

//  if (polength == 0  && solength == 0 && selectedlength == 0) {

  
//   show_alert("Error", "Select PO, SO, or Production Indent");
//   return;
// }

let scan_by = document.getElementById("scan-by-job").value;
if(!jobAssignment || !labourId || !activityType) {
  show_alert("Error", "Enter mandatory field");
  return;
}
else{

var config = {
  app_name: "inventory",
  form_name: "Add_Job_Entry",
  payload: {
    "data": {
        "Labour_Name": labourId,
        "Job":jobAssignment,
        "PO":poSelected,
        "Production_Indent": selected,
        "Activity": activityType,
        "Sales_Order":soSelected,
        "Scan_Type_While_Job_Assign":scan_by
   }
  }
};
ZOHO.CREATOR.DATA.addRecords(config).then(function (response) {
  //console.log("AddJOb assignment",response);
  if (response.code == 3000) {
    //console.log("record Added successfullly",response);
    show_alert("Success","Job Assigned Successfully");
    clearInputs(); // Clear inputs after successful addition
    if(scan_by=="QR")
    {
    startQRScanner("qr-reader");
    }
    else
    {
      recapturePhoto("captured-image-job","camera-job");
    }
  }
  if(response.code==3001){

    console.error("Error adding record:",response);
    let error_msg = response.error[0].alert_message;
    show_alert("Error",error_msg);
  }
}).catch(function (e) {
  console.error("Error adding record:", e);
  show_alert("Error",JSON.stringify(e));
});
}


}

// Wait for DOM to load (if needed)
// Scroll to selected radio on page load
document.addEventListener("DOMContentLoaded", function () {
  setTimeout(() => {
    let selectedRadio = document.querySelector('input[name="job-assignment-radio"]:checked');
    if (selectedRadio) {
      selectedRadio.scrollIntoView({
        behavior: 'smooth',
        block: 'center',
        inline: 'nearest'
      });
    }
  }, 100);
});

// Scroll to radio when user changes selection
document.addEventListener("change", function (event) {
let selectedRadio = document.querySelector('input[name="job-assignment-radio"]:checked');

if (selectedRadio) {
  // Get the parent label and extract text
  let selectedValue = selectedRadio.value;
  let labelText = selectedRadio.parentElement.textContent.trim();
  console.log("selected job", labelText);

  document.getElementById("selected-job").value = labelText;
  GetPOSOProductionIndentByJob(selectedValue);
}

 
  if (event.target && event.target.name === "job-assignment-radio" && event.target.checked) {
    event.target.scrollIntoView({
      behavior: 'smooth',
      block: 'center',
      inline: 'nearest'
    });
  }
});





function show_alert(msg_type, text) {
    try {
        let btn = `<div><button class="ok btn" onclick="hide_alert()">OK</button></div>`;
        document.getElementById("loader_alert").style.display = "flex";
        document.querySelector(".container")?.classList.add("blur");

        let alertHTML = `<div style="color:${msg_type === 'Success' ? 'green' : 'red'};">
                            <i class="bi ${msg_type === 'Success' ? 'bi-check-circle-fill' : 'bi-x-circle-fill'}"></i>
                            ${text}
                         </div>` + btn;

        document.getElementById("text_alert").innerHTML = alertHTML;
    } catch (e) {
        console.error("Alert Error:", e);
    }
}


function hide_alert() {
    
    document.getElementById("loader_alert").style.display = "none";
    document.getElementById("text_alert").innerHTML = "";
    document.querySelector(".container")?.classList.remove("blur");
}


function uploadCapturedImage(id, capturedImageFile)
{
  // //console.log("capturedImage in Upload",capturedImageFile);

// var fileObject = document.getElementById("fileInput").files[0];
var config = {
  app_name: "inventory",
  report_name: "All_Labour_Databases",
  id : id,
  field_name : "Image",
  file : capturedImageFile
};
ZOHO.CREATOR.FILE.uploadFile(config).then(function (response) {
  // //console.log("check uploadcapture image",response);
});
}


function clearinputsAttendance()
{
  document.getElementById("labour-rec-id-attendance").value="";
  document.getElementById("labour-id-attendance").value="";
  document.getElementById("labour-name-attendance").value="";
  document.getElementById("labour-name-attendance").textContent="";
  document.getElementById("contractor-name-attendance").value="";
  document.getElementById("contractor-name-attendance").textContent="";
  document.getElementById("clockDisplay").textContent="00:00:00";
  document.getElementById("datetime").value = "";
  const logoutLabel = document.getElementById("logout-label");
  const logoutInput = document.getElementById("datetime");
  logoutLabel.style.display = "none";
  logoutInput.style.display = "none";

  // document.getElementById("LogIn").style.display="none";
  // document.getElementById("LogOut").style.display="none";

}

async function getLabourData(labourID) {
  var config = { 
    app_name: "inventory",
    report_name: "All_Labour_Databases",
    id: labourID
  };

  
    const response = await ZOHO.CREATOR.DATA.getRecordById(config);
    // //console.log("attendance record", response);

    if (response.code === 3000) {
      let labour_data = response.data;
      let labour_id = labour_data.Labour_ID;
      let labour_name = labour_data.Labour_Name;
      let contract_data = labour_data.Contractor;
      let contractor_name = contract_data.NAME_WITH_CODE;
      let contractor_id = contract_data.ID;

      // Populate labour name
      let labour_name_attendance = document.getElementById("labour-name-attendance");
      let option = document.createElement("option");
      option.value = labour_data.ID;
      option.textContent = labour_name;
      labour_name_attendance.appendChild(option);

      // Populate contractor name
      let contract_name = document.getElementById("contractor-name-attendance");
      let contractor_opt = document.createElement("option");
      contractor_opt.value = contractor_id;
      contractor_opt.textContent = contractor_name;
      contract_name.appendChild(contractor_opt);

      // Set labour ID
      document.getElementById("labour-id-attendance").value = labour_id;

      get_activity_from_login(labour_data.ID);

     

      // Return data
      return labour_data;
    } else {
      //console.log("no data found for labour");
     
    }
 
}

//show/hide log in log out btn
function showhidebtn(ID) {
  var config = {
    app_name: "inventory",
    report_name: "All_Labour_Attendances",
    // criteria: "Labour_Name == " + ID
    criteria: "Labour_Name == " + ID + " && Log_Out_Time == null"
  };

 ZOHO.CREATOR.DATA.getRecords(config).then(function (response) {
  //console.log("Check labour attendance data", response);

  let resp_data = response.data;

  if (response.code === 3000 && resp_data.length > 0) {
    // Sort by Log_In_Time or Created_Time in descending order (latest first)
    resp_data.sort(function (a, b) {
      return new Date(b.Log_In_Time || b.Created_Time) - new Date(a.Log_In_Time || a.Created_Time);
    });

    let latestRecord = resp_data[0]; // most recent record

    let log_in_time = latestRecord.Log_In_Time;
    let log_out_time = latestRecord.Log_Out_Time;

    if (!log_in_time && !log_out_time) {
      // No log-in yet
      //console.log("Labour has not logged in yet.");
      // document.getElementById("LogIn").style.display = "block";
      // document.getElementById("LogOut").style.display = "none";
    } else if (log_in_time && !log_out_time) {
      // Logged in but not logged out
      //console.log("Labour is logged in but not logged out.");
      let isoLogInTime = convertToISOFormat(log_in_time);
      updateWorkingDuration(isoLogInTime);
      // document.getElementById("LogIn").style.display = "none";
      // document.getElementById("LogOut").style.display = "block";
    } 
    // else {
      // Completed cycle
      //console.log("Labour already logged in and logged out.");
      // document.getElementById("LogIn").style.display = "block";
      // document.getElementById("LogOut").style.display = "none";
    // }

  } else {
    // No records found at all — show login
    console.log("No attendance records found.");
    // document.getElementById("LogIn").style.display = "block";
    // document.getElementById("LogOut").style.display = "none";
  }

   
  }).catch(function (error) {
    //means labour have no record of log in and log out
    //show log in btn
    // document.getElementById("LogIn").style.display="block";
    //hide log out btn
    // document.getElementById("LogOut").style.display="none";

    console.error("Error fetching labour attendance data", error);
   
  });
}

function GetLabourAttendaceByID(ID)
{
    var config = {
    app_name: "inventory",
    report_name: "All_Labour_Attendances",
    criteria: "Labour_Name == " + ID + " && Log_Out_Time == null"
 
  };

 ZOHO.CREATOR.DATA.getRecords(config).then(function (response) {
  console.log("Labour Attendance", response);

  let resp_data = response.data;

  if (response.code === 3000 && resp_data.length > 0) {
    // Sort by Log_In_Time or Created_Time in descending order (latest first)
    resp_data.sort(function (a, b) {
      return new Date(b.Log_In_Time || b.Created_Time) - new Date(a.Log_In_Time || a.Created_Time);
    });

    let latestRecord = resp_data[0];
    console.log("recent record of labour attendance",latestRecord);
    let labour_data = latestRecord.Labour_Name;
    let labour_name = labour_data.Labour_Name;
     let labour_name_break = document.getElementById("labour-name-break");
     let option = document.createElement("option");
      option.value = labour_data.ID;
      option.textContent = labour_name;
      labour_name_break.appendChild(option);


      // let rec_id = latestRecord.ID;
      let log_in_time = latestRecord.Log_In_Time;
      let log_in_session = document.getElementById("log-in-session");
      log_in_session.value = log_in_time;
      // let log_in_session = document.getElementById("log-in-session");
      // let option_log_in = document.createElement("option");
      // option_log_in.value = rec_id;
      // option_log_in.textContent = log_in_time;
      // log_in_session.appendChild(option);
      //fetch job entry id and populate in job entry field
      GetOpenJobEntryId(ID);
      GetLabourBreakReport(ID);



  }

}).catch (function (error){
  show_alert("Error",JSON.stringify(error));

});
}

function AddBreak()
{
let labourName = document.getElementById("labour-name-break").value;
let scan_by = document.getElementById("scan-by-break").value;
if(labourName == "")
{
  show_alert("Error","Enter Mandatory Fields");
  return;
}

    var config = {
  app_name: "inventory",
  form_name: "Labour_Break",
  payload: {
    "data": {
        "Labour_Name": labourName,
        "Scan_Type_While_Break_Out":scan_by
   }
  }
};
ZOHO.CREATOR.DATA.addRecords(config).then(function (response) {

  if (response.code == 3000) {
  
    show_alert("Success","Break Successfully Taken");
    // Clear inputs after successful addition
    clearInputsBreak();
    if(scan_by == "QR")
    {
    startQRScanner("qr-reader-break");
    }
    else
    {
      recapturePhoto("captured-image-break","camera-break");
    }
    
  }
    if(response.code==3001){

    console.error("Error adding record:",response);
    let error_msg = response.error[0].alert_message;
    show_alert("Error",error_msg);
  }
}).catch(function(e){
  show_alert("Error",JSON.stringify(e));

})

}
function GetLabourBreakReport(ID)
{

     var config = {
    app_name: "inventory",
    report_name: "Labour_Break_Report",
    criteria: "Labour_Name == " + ID + " && Break_In == null"
    //  criteria: "Labour_Name == " + ID + " && Log_Out_Time == null"
  };

 ZOHO.CREATOR.DATA.getRecords(config).then(function (response) {
  console.log("Labour Break Report", response);

  let resp_data = response.data;

  if (response.code === 3000 && resp_data.length > 0) {
    // Sort by Log_In_Time or Created_Time in descending order (latest first)
    resp_data.sort(function (a, b) {
      return new Date(b.Log_In_Time || b.Created_Time) - new Date(a.Log_In_Time || a.Created_Time);
    });

    let latestRecord = resp_data[0];
    console.log("recent data",latestRecord);
    let break_out = latestRecord.Break_Out1;
    let job_entry = latestRecord.Job_Entry_Id;
    let job_entry_id = job_entry.ID;
    // document.getElementById("job-entry-id").value = job_entry_id;
    document.getElementById("break-out").value = break_out;

  }
}).catch (function (error){
  console.log(error);
  // show_alert("Error",JSON.stringify(error));

});

}
function UpdateBreak()
{
let labour_rec_id = document.getElementById("labour-name-break").value;
let scan_by = document.getElementById("scan-by-break").value;

  let currentDateTime = getFormattedDateTime();


  var config = {
    app_name: "inventory",
    report_name: "Labour_Break_Report",
    payload: {
      // ✅ No quotes, because Labour_Name is a number
      criteria: `(Labour_Name == ${labour_rec_id} && Log_In_Session1 != null && Break_Out1 != null)`,
      data: {
        
     "Break_In":currentDateTime,
     "Scan_Type_While_Break_In":scan_by
       
      }
    }
  };

  ZOHO.CREATOR.DATA.updateRecords(config).then(function(response) {
   //console.log("check response update", response);
    if (response.code == 3000) {
      //console.log("update record attendance", response);
      
      let alertMessage = response?.result?.[0]?.error?.[0]?.alert_message?.[0];
       if (alertMessage)
         {
              //console.log("Alert message:", alertMessage);
               show_alert("Error", alertMessage);
         }
        else
        {
            show_alert("Success","Return To Work Successfully");
            clearInputsBreak(); // Clear inputs after successful addition
            if(scan_by =="QR")
            {
            startQRScanner("qr-reader-break");
            }
            else
            {
              recapturePhoto("captured-image-break","camera-break");
            }

        } 

       
    } 
  
  }).catch(function (e) {
            //console.log("check error", e);
            show_alert("Error", JSON.stringify(e));

        });

}
function get_activity_from_login(ID)
{

  var config = {
    app_name: "inventory",
    report_name: "All_Labour_Attendances",
    criteria: `Labour_Name ==  ${ID}  && Log_Out_Time == null`
  };

 ZOHO.CREATOR.DATA.getRecords(config).then(function (response) {
  //console.log("Check labour attendance data", response);

  let resp_data = response.data;
   if (response.code === 3000 && resp_data.length > 0) {
    // Sort by Log_In_Time or Created_Time in descending order (latest first)
    resp_data.sort(function (a, b) {
      return new Date(b.Log_In_Time || b.Created_Time) - new Date(a.Log_In_Time || a.Created_Time);
    });

    let latestRecord = resp_data[0];
       let log_in_time = latestRecord.Log_In_Time;
       let activity_type = latestRecord.Activity_Type;
     
       if(activity_type !="")
       {

        // set activity
      let activity = latestRecord.Activity_Type;
 
       validate_activity(activity);

        return;
    


       }
       if(log_in_time!="")
       {
        get_activity_from_job_data(ID,log_in_time);

       }
  }
  else
  {
    //console.log("no record found for labour attendance");
  }
 });
}
function validate_activity(activity)
{
    let radioToCheck = document.querySelector(`input[name="activity-type-attendance"][value="${activity}"]`);
     let allRadioButtons = document.querySelectorAll('input[name="activity-type-attendance"]');
     let act_container = document.getElementById('activity-type-attendance');
      if (radioToCheck) {
       radioToCheck.checked = true;

    // Disable all radio buttons in the group
     allRadioButtons.forEach(radio => {
        radio.disabled = true;
        radio.style.cursor = "not-allowed";
        radio.parentElement.style.backgroundColor = "#e0e0e0"; // Assuming labels wrap inputs
    });

    // Optionally dim the background of the container
    act_container.style.backgroundColor = "#f0f0f0";
    }

}
//get job data by log in time and id
function get_activity_from_job_data(ID,Log_in_Time)
{
  let criteria = `Labour_Name == ${ID} && Start_Time > "${Log_in_Time}"`;

  var config = {
    app_name: "inventory",
    report_name: "All_Job_Entries",
    criteria: criteria
    // criteria: "Labour_Name == " + ID + " && Added_Time >" + Log_in_Time
  }
  //console.log("get job data",config);

 ZOHO.CREATOR.DATA.getRecords(config).then(function (response) {
  //console.log("Check job data", response);

  let resp_data = response.data;

  if (response.code === 3000 && resp_data.length > 0) {
 
    resp_data.sort(function (a, b) {
      return new Date(b.Start_Time || b.Created_Time) - new Date(a.Start_Time || a.Created_Time);
    });

    let latestRecord = resp_data[0]; // most recent record
    //console.log("latest job data ",latestRecord);
    let activity_type = latestRecord.Activity;
    if(activity_type!="")
    {
       //set activity
      let activity = activity_type;
      
       //console.log("activity",activity);
       validate_activity(activity);

    
    }

  }
  else
  {
    //console.log("no data found by log in");
  }
}).catch(function (error)
{
  //console.log("Error",error);
})

}


function updateWorkingDuration(log_in_time) {

  ZOHO.CREATOR.UTIL.getQueryParams().then(function (response_params) {
      const log_in_details = JSON.parse(response_params.log_in_details_info);
      const portal_access = log_in_details.portal_access;
       console.log("portal_access",portal_access);

    let log_in = new Date(log_in_time);

    if (isNaN(log_in.getTime())) {
        console.error("Invalid login time:", log_in_time);
        return;
    }

    let now = new Date();
    let diff_ms = now - log_in;

    let total_seconds = Math.floor(diff_ms / 1000);
    hours = Math.floor(total_seconds / 3600);
    let minutes = Math.floor((total_seconds % 3600) / 60);
    let seconds = total_seconds % 60;

    let formattedTime =
        String(hours).padStart(2, '0') + ':' +
        String(minutes).padStart(2, '0') + ':' +
        String(seconds).padStart(2, '0');
        console.log("formated time",formattedTime);
        document.getElementById("datetime").value = formattedTime
        // 🕒 Show/Hide Log Out time input based on conditions
    const logoutLabel = document.getElementById("logout-label");
    const logoutInput = document.getElementById("datetime");

    if (hours > 16 && portal_access !== "Security_Guard") {
      console.log("⚠️ Working duration exceeded 17 hours:", formattedTime);

      logoutLabel.style.display = "inline-block";
      logoutInput.style.display = "inline-block";
    } else {
      logoutLabel.style.display = "none";
      logoutInput.style.display = "none";
    }


    document.getElementById("clockDisplay").textContent = formattedTime;
});   
}



function convertToISOFormat(rawDateString) {
    const monthMap = {
        Jan: "01", Feb: "02", Mar: "03", Apr: "04",
        May: "05", Jun: "06", Jul: "07", Aug: "08",
        Sep: "09", Oct: "10", Nov: "11", Dec: "12"
    };

    let [datePart, timePart] = rawDateString.split(" ");
    let [day, monthStr, year] = datePart.split("-");

    let month = monthMap[monthStr];
    return `${year}-${month}-${day}T${timePart}`;
}


function getOpenJobAssignment(ID)
{

  var config = {
    app_name: "inventory",
    report_name: "All_Job_Entries",
    criteria: "Labour_Name == " + ID + " && End_Time == null && Start_Time != null" 
    //  criteria: "Labour_Name == " + ID + " && Log_Out_Time == null"
  };

 ZOHO.CREATOR.DATA.getRecords(config).then(function (response) {
  console.log("Check open job assignment data", response);

  let resp_data = response.data;

  if (response.code === 3000 && resp_data.length > 0) {
   // show close job button
    document.getElementById("closejob").style.display="block";
   // hide assign job button
    document.getElementById("assign-job").style.display="none";
    //show job duration
     let job_duration_section = document.getElementById("job-duration-section");
     job_duration_section.style.display ="block";
    // Sort by Log_In_Time or Created_Time in descending order (latest first)
    resp_data.sort(function (a, b) {
      return new Date(b.Start_Time || b.Created_Time) - new Date(a.Start_Time || a.Created_Time);
    });

    let latestRecord = resp_data[0]; // most recent record
    //console.log("latest job assignment data ",latestRecord);
   
    let start_time = latestRecord.Start_Time;
    const start_time_input = document.getElementById("start-time");
    const start_time_label = document.getElementById("start-label");
    start_time_label.style.display="block";
    start_time_input.style.display = "block";
    start_time_input.value = start_time;

let startDate = parseCustomDateTime(start_time);
let currentDate = new Date(); // Current system time

let durationMs = currentDate - startDate;
let durationStr = formatDuration(durationMs);

console.log("Duration (HH:mm:ss):", durationStr)


    //disable production indent and autofill values
let production_indent_data = latestRecord.Production_Indent;

let production_indent_select = document.getElementById("production-indent");

production_indent_data.forEach(element => {
  // Check if option already exists
  let existingOption = Array.from(production_indent_select.options).find(
    option => option.value === element.ID
  );
//option not present create  new option
  if (!existingOption) {
    // //console.log("not duplicate");
    let option = document.createElement("option");
    option.value = element.ID;
    option.textContent = element.Production_Indent_ID;
    // option.selected = true; // select if you want to pre-select new options
    production_indent_select.appendChild(option);
  } //option already present
  else {
    // //console.log("duplicate");
    existingOption.value = element.ID;
    existingOption.textContent = element.Production_Indent_ID;
    existingOption.selected = true;
    production_indent_select.appendChild(existingOption);
  }
});


let so_select = document.getElementById("sales-order");
let so_data = latestRecord.Sales_Order;

so_data.forEach(element => {
  // Check if option already exists
  let existingOption = Array.from(so_select.options).find(
    option => option.value === element.ID
  );
//option not present create  new option
  if (!existingOption) {
    // //console.log("not duplicate");
    let option = document.createElement("option");
    option.value = element.ID;
    option.textContent = element.SO_Number;
    // option.selected = true; // select if you want to pre-select new options
    so_select.appendChild(option);
  } //option already present
  else {
    // //console.log("duplicate");
    existingOption.value = element.ID;
    existingOption.textContent = element.SO_Number;
    existingOption.selected = true;
    so_select.appendChild(existingOption);
  }
});
//disable multiselect PO indent  and autofill values
let po_data = latestRecord.PO ;
//console.log("Previous PO data",po_data);
let po_select = document.getElementById("po");

po_data.forEach(element => {
  // Check if option already exists
  let existingOption = Array.from(po_select.options).find(
    option => option.value === element.ID
  );

  if (!existingOption) {
    //console.log("not duplicate");
    let option = document.createElement("option");
    option.value = element.ID;
    option.textContent = element.PO_ID;
    // option.selected = true; // select if you want to pre-select new options
    po_select.appendChild(option);
  } else {
    //console.log("duplicate");
    existingOption.value = element.ID;
    existingOption.textContent = element.PO_ID;
    existingOption.selected = true;
    po_select.appendChild(existingOption);
  }
});

 // disable job assigment and autofill data in job assignment
let job_assigment = latestRecord.Job; // Make sure it matches the value type
let jobselect = document.querySelector(`input[name="job-assignment-radio"][value="${job_assigment.ID}"]`);
//console.log("job_select",jobselect);

if (jobselect) {
  jobselect.checked = true;
 
  let selectedRadio = document.querySelector('input[name="job-assignment-radio"]:checked');
  let labelText = selectedRadio.parentElement.textContent.trim();
  console.log("selected job", labelText);

  document.getElementById("selected-job").value = labelText;
  GetPOSOProductionIndentByJob(job_assigment.ID);
  
}
let job_type = document.querySelector('input[name="job-assignment-radio"]:checked');
let job_type_container = document.getElementById("job-assignment-section");
 let allRadioButtonsJob = document.querySelectorAll('input[name="job-assignment-radio"]');
if(job_type)
{
  // job_type.checked = false;
  job_type_container.style.backgroundColor = "#f9f9f9";

   // enable all radio buttons in the group
     allRadioButtonsJob.forEach(radio => {
        radio.disabled = true;
       
        radio.parentElement.style.backgroundColor = "#f9f9f9"; // Assuming labels wrap inputs
    });
}


//   let option = document.createElement("option");
//   option.value = job_assigment.ID;
//   option.textContent = job_assigment.Job;
//   option.selected=true;
//   jobselect.appendChild(option);

  //disable activity type and autofill data in activity
let activity = latestRecord.Activity;
let radioToCheck = document.querySelector(`input[name="activity-type"][value="${activity}"]`);

if (radioToCheck) {
  radioToCheck.checked = true;
 
}

let activity_type_attendance = document.querySelector('input[name="activity-type"]:checked');
let activity_type_container = document.getElementById("activity-type-job");
let allRadioButtons = document.querySelectorAll('input[name="activity-type"]');

if (activity_type_attendance) {
    // Change container background color
    activity_type_container.style.backgroundColor = "#f9f9f9";

    // Disable all radio buttons
    allRadioButtons.forEach(radio => {
        radio.disabled = true;

        // Optionally change label background color (parent label)
        if (radio.parentElement.tagName.toLowerCase() === 'label') {
            radio.parentElement.style.backgroundColor = "#f9f9f9";
            radio.parentElement.style.cursor = 'not-allowed'; // visually indicate disabled
        }
    });
}


// let activity = latestRecord.Activity;
// let activity_type = document.querySelector('input[name="activity-type"]:checked');
// activity_type.value = activity;

//get labour name
let labour_data = latestRecord.Labour_Name;
let labour_name = labour_data.Labour_Name;

// //console.log("labour_data",labour_name);
}
}).catch(function(e){
  console.log("error",e);
  // show_alert("Error","Labour Does Not Have Open Job");
  //show assign job button
  document.getElementById("assign-job").style.display ="block";
//hide close job button
 document.getElementById("closejob").style.display ="none";
  //hide start time
   const start_time_input = document.getElementById("start-time");
   start_time_input.style.display="none";
    const start_time_label = document.getElementById("start-label");
    start_time_label.style.display="none";
    let job_duration_section = document.getElementById("job-duration-section");
    job_duration_section.style.display ="none";

});
}

//labour click on log in button
function AddLabourAttendace()
{
  let labourName = document.getElementById("labour-name-attendance").value;
  let Contractor = document.getElementById("contractor-name-attendance").value;
  let Labour_ID = document.getElementById("labour-id-attendance").value;
  let scan_by = document.getElementById("scan-by-attendance").value;
  let activity = "";
  let selectedActivity = document.querySelector('input[name="activity-type-attendance"]:checked');
  if(selectedActivity)
  {
  activity = selectedActivity.value;
  }
  //console.log("input attendance",labourName,Contractor,Labour_ID);
  if (labourName === "" || Contractor === "" || Labour_ID == "") 
{
  show_alert("Error", "Enter mandatory fields");
  return;
}
else
{

  var config = {
  app_name: "inventory",
  form_name: "Labour_Attendance",
  payload: {
    "data": {
        "Labour_Name": labourName,
        "Contractor":Contractor,
        "Labour_ID":Labour_ID,
        "Scan_Type_While_Log_In":scan_by,
        "Activity_Type":activity
        
   }
  }
};
ZOHO.CREATOR.DATA.addRecords(config).then(function (response) {
  //console.log("check add attendance",response);
  if (response.code == 3000) {
    //console.log("record Added successfullly",response);
    // const res_data = response.data;
    // let labourId = res_data.ID;
     // Get the ID of the newly added record

    // uploadCapturedImage(labourId, capturedImageFile);
    show_alert("Success","Labour Successfully Logged In");
    clearinputsAttendance(); // Clear inputs after successful addition
    if(scan_by == "QR")
    {
    startQRScanner("qr-reader-attendance");
    }
    else
    {
      recapturePhoto("captured-image-attendance","camera-attendance");
    }
    
  }
    if(response.code==3001){

    console.error("Error adding record:",response);
    let error_msg = response.error[0].alert_message;
    show_alert("Error",error_msg);
  }
}).catch(function(e){
  show_alert("Error",JSON.stringify(e));

})
}
}

function parseCustomDateTime(str) {
  // Parses "18-Jul-2025 11:20:24" into a Date object
  const [datePart, timePart] = str.split(" ");
  const [day, monStr, year] = datePart.split("-");
  const [hour, min, sec] = timePart.split(":");

  const months = {
    Jan: 0, Feb: 1, Mar: 2, Apr: 3, May: 4, Jun: 5,
    Jul: 6, Aug: 7, Sep: 8, Oct: 9, Nov: 10, Dec: 11
  };

  return new Date(year, months[monStr], day, hour, min, sec);
}

function formatDuration(ms) {
  let totalSeconds = Math.floor(ms / 1000);
  let hours = Math.floor(totalSeconds / 3600);
  let minutes = Math.floor((totalSeconds % 3600) / 60);
  let seconds = totalSeconds % 60;
  document.getElementById("hours").value = hours;
  document.getElementById("minutes").value = minutes;
  document.getElementById("seconds").value = seconds;

  // Pad with leading zeros
  return (
    String(hours).padStart(2, '0') + ":" +
    String(minutes).padStart(2, '0') + ":" +
    String(seconds).padStart(2, '0')
  );
}
function getFormattedDateTime() {
    const now = new Date();

    const day = String(now.getDate()).padStart(2, '0');
    const monthNames = ["Jan", "Feb", "Mar", "Apr", "May", "Jun",
                        "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
    const month = monthNames[now.getMonth()];
    const year = now.getFullYear();

    const hours = String(now.getHours()).padStart(2, '0');
    const minutes = String(now.getMinutes()).padStart(2, '0');
    const seconds = String(now.getSeconds()).padStart(2, '0');

    return `${day}-${month}-${year} ${hours}:${minutes}:${seconds}`;
}
//fetch open job entry id for break in and break out
function GetOpenJobEntryId(ID)
{

   var config = {
    app_name: "inventory",
    report_name: "All_Job_Entries",
    criteria: "Labour_Name == " + ID + " && End_Time == null && Start_Time != null" 
    //  criteria: "Labour_Name == " + ID + " && Log_Out_Time == null"
  };

 ZOHO.CREATOR.DATA.getRecords(config).then(function (response) {
 

  let resp_data = response.data;

  if (response.code === 3000 && resp_data.length > 0) {
  
    resp_data.sort(function (a, b) {
      return new Date(b.Start_Time || b.Created_Time) - new Date(a.Start_Time || a.Created_Time);
    });

    let latestRecord = resp_data[0];
    let job_entry_id = latestRecord.ID;
    document.getElementById("job-entry-id").value = job_entry_id;


  }
  else
  {
    console.log("No records found in GetJobEntry");
  }
  }).catch(function(error)
{
  show_alert("Error","Labour Does Not Have Open Job");
})

}

function updateLabourAttendance() {
  let currentDateTime;
 

ZOHO.CREATOR.UTIL.getQueryParams().then(function (response_params) {
            const log_in_details = JSON.parse(response_params.log_in_details_info);
            let log_out_entry_mail = log_in_details.logged_mai_is;
            let log_out_entry_name = log_in_details.logged_in_user_name;
            //console.log("mail",log_out_entry_mail);
            //console.log("name",log_out_entry_name);
  let labourName = document.getElementById("labour-name-attendance").value;
  let contractor = document.getElementById("contractor-name-attendance").value;
  let labourID = document.getElementById("labour-id-attendance").value;
  let labour_rec_id = document.getElementById("labour-rec-id-attendance").value;
  let scan_by = document.getElementById("scan-by-attendance").value;
 
const Selected_LogOut_Time = document.getElementById("datetime").value;
console.log("selected_logOut_time",Selected_LogOut_Time);
const formattedTime = formatZohoDateTime(Selected_LogOut_Time);

console.log("Formatted Time for Zoho:", formattedTime);

   if(hours > 16 && Selected_LogOut_Time == "" && portal_access !=="Security_Guard")
  {
    show_alert("Error","Please Select LogOut Time");
    return;
    
  }
 
  if(Selected_LogOut_Time == "" && hours < 16)
  {
   currentDateTime = getFormattedDateTime();

  }
  else
  {
    currentDateTime = formattedTime;
  }
  

  //console.log("input attendance", labourName, contractor, labourID);
  

  var config = {
    app_name: "inventory",
    report_name: "All_Labour_Attendances",
    payload: {
      // ✅ No quotes, because Labour_Name is a number
      criteria: `(Labour_Name == ${labour_rec_id} && Log_Out_Time == null && Log_In_Time != null)`,
      data: {
        
     "Log_Out_Time":currentDateTime,
     "Log_Out_Entry_By_Employee_Mail":log_out_entry_mail,
     "Log_Out_Entry_By_Employee_Name":log_out_entry_name,
     "Scan_Type_While_Log_Out":scan_by
       
      }
    }
  };

  ZOHO.CREATOR.DATA.updateRecords(config).then(function(response) {
   console.log("check response update", response);
    if (response.code == 3000) {
      //console.log("update record attendance", response);
      
      let alertMessage = response?.result?.[0]?.error?.[0]?.alert_message?.[0];
       if (alertMessage)
         {
              //console.log("Alert message:", alertMessage);
               show_alert("Error", alertMessage);
         }
        else
        {
            show_alert("Success","Log Out Successfully");
            clearinputsAttendance(); // Clear inputs after successful addition
            if(scan_by =="QR")
            {
            startQRScanner("qr-reader-attendance");
            }
            else
            {
              recapturePhoto("captured-image-attendance","camera-attendance");
            }

        } 

       
    } 
  
  }).catch(function (e) {
            //console.log("check error", e);
            show_alert("Error", JSON.stringify(e));

        });
     

});
}

function formatZohoDateTime(htmlDateTimeValue) {
  if (!htmlDateTimeValue) {
    console.warn("No datetime value provided.");
    return null;
  }

  const date = new Date(htmlDateTimeValue);

  if (isNaN(date.getTime())) {
    console.error("Invalid datetime format:", htmlDateTimeValue);
    return null;
  }

  const day = String(date.getDate()).padStart(2, '0');
  const monthNames = ["Jan", "Feb", "Mar", "Apr", "May", "Jun",
                      "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
  const month = monthNames[date.getMonth()];
  const year = date.getFullYear();

  const hours = String(date.getHours()).padStart(2, '0');
  const minutes = String(date.getMinutes()).padStart(2, '0');
  const seconds = "00"; // Default to 00

  const formattedDateTime = `${day}-${month}-${year} ${hours}:${minutes}:${seconds}`;
  return formattedDateTime;
}

function updateJobEntry()
{
  let activityType = "";
  let jobAssignment = "";
  let job_duration = "";
  let labour_rec_id = document.getElementById("labour-id").value;
  let hours =  document.getElementById("hours").value;
  let minutes =  document.getElementById("minutes").value;
  let seconds = document.getElementById("seconds").value;
 
 


    job_duration = String(hours).padStart(2, '0') + ":" +
    String(minutes).padStart(2, '0') + ":" +
    String(seconds).padStart(2, '0');
    console.log("merge hh mm ss",job_duration);



  
  let scan_by = document.getElementById("scan-by-job").value;
  // let job_duration = document.getElementById("job-duration").value;
  let selectedActivity = document.querySelector('input[name="activity-type"]:checked');
  if(selectedActivity)
  {
  activityType = selectedActivity.value;
  }

  let selectedRadio = document.querySelector('input[name="job-assignment-radio"]:checked');
  if (selectedRadio)
  {
   jobAssignment = selectedRadio.value;
  }
  let piselected = $('#production-indent').val();
 
  let poSelected = $('#po').val();
  let soSelected = $('#sales-order').val();
  
  let currentDateTime = getFormattedDateTime();



  var config = {
    app_name: "inventory",
    report_name: "All_Job_Entries",
    payload: {
      // ✅ No quotes, because Labour_Name is a number
      criteria: `(Labour_Name == ${labour_rec_id} && End_Time == null && Start_Time != null)`,
      data: {
        
     "End_Time":currentDateTime,
     "Production_Indent":piselected,
     "PO":poSelected,
     "Job":jobAssignment,
     "Activity":activityType,
     "Sales_Order":soSelected,
     "Job_Duration":job_duration,
     "Scan_Type_While_Job_End":scan_by
     
       
      }
    }
  };
  
  ZOHO.CREATOR.DATA.updateRecords(config).then(function(response) {
   //console.log("check response jobEntry update", response);
    if (response.code == 3000) {
       console.log("update record JobEntry", response);
       show_alert("Success","Job Closed Successfully");
       clearInputs(); // Clear inputs after successful addition
       if(scan_by =="QR")
       {
       startQRScanner("qr-reader");
       }
       else
       {
        recapturePhoto("captured-image-job","camera-job");
       }

       
    } 
    else
    {
      let error_msg = response.error[0].alert_message;
      show_alert("Error",error_msg);
    }
  
  }).catch(function (e) {
            //console.log("check error", e);
            show_alert("Error", JSON.stringify(e));

        });
     


}



