// const { response } = require("express");

console.log("widget loaded");
let max_attempt = 0;
let quiz_transcript = "";

// getQuizData();

  // 🔹 Fetch records
// let quiz_master_map = {};

// get_allowed_department_rec();
// get_not_allowed_department_rec();
// get_all_department_rec();
// GetQuizScore();
// AddQuizHistory();



async function get_allowed_department_rec() {
    ZOHO.CREATOR.UTIL.getQueryParams().then(async function (response_params) {
   const log_in_details = JSON.parse(response_params.login_details);
    let department = log_in_details.department;
    // department = "196425000000147007";
    // console.log("Department:", department);

    try {
        const allRecords = [];
        let recordCursor = "";
        let config = {};

        do {
            config = {
                app_name: "chaizup-order-to-delivery",
                report_name: "Quiz_Master_Report",
                max_records: 1000,
                criteria: "Allowed_Department.ID == " + department + " || " + "All_Department == true" + "||" + "Not_Allowed_Department.ID !=" + department, // filter applied
                record_cursor: recordCursor
            };

            const response = await ZOHO.CREATOR.DATA.getRecords(config);
            recordCursor = response?.record_cursor;

            if (response.code === 3000) {
                allRecords.push(...response.data);
                console.log("allow department records",allRecords);
                fetchTopics(allRecords);
                // console.log("response",response.data);
            }
        } while (recordCursor);
          return allRecords;
    } catch (error) {
        // console.error("Error fetching records from All Quizzes:, error");
        return [];
    }
}); 
}
async function GetMasterRecordById(ID)
{
    var config = {
                   app_name: "chaizup-order-to-delivery",
                   report_name: "Quiz_Master_Report",
                   id : ID
};
ZOHO.CREATOR.DATA.getRecordById(config).then(function (response) {
  console.log(response);
  let quiz_data = response.data;
  let quiz_transcript = quiz_data.Quiz_Transcript;
  return quiz_transcript;
}).catch(function(error)
{
    console.log("error",error);
    return

})

}

 async function get_quiz_history_by_em() {
    try {
        const response_params = await ZOHO.CREATOR.UTIL.getQueryParams();
        const log_in_details = JSON.parse(response_params.login_details);
        const emp_rec_id = log_in_details.Employee_Rec_Id;

        const allRecords = [];
        let recordCursor = "";
        const quiz_master_map = {}; // Declare map here

        do {
            const config = {
                app_name: "chaizup-order-to-delivery",
                report_name: "Quiz_History",
                max_records: 1000,
                criteria: "Employee_Name == " + emp_rec_id,
                record_cursor: recordCursor
            };

            const response = await ZOHO.CREATOR.DATA.getRecords(config);
            recordCursor = response?.record_cursor;

            if (response.code === 3000) {
                const rec_data = response.data;
                allRecords.push(...rec_data);

                rec_data.forEach(element => {
                    const quiz_master_id = element.Quiz_Topic.ID;
                    const no_of_attempt = element.Number_of_Attempt;
                    const last_score = element.Last_Score;
                    console.log("quiz_master_id",quiz_master_id);
                    
                    quiz_master_map[quiz_master_id] = {
                        Number_of_Attempt: no_of_attempt,
                        Last_Score: last_score
                    };
                });
            }

        } while (recordCursor);

        console.log("Quiz history Map:", quiz_master_map);
        return quiz_master_map;

    } catch (error) {
        console.error("Error fetching records from Quiz History:", error);
        return {};
    }
}



async function get_not_allowed_department_rec() {
    ZOHO.CREATOR.UTIL.getQueryParams().then(async function (response_params) {
   const log_in_details = JSON.parse(response_params.login_details);
    let department = log_in_details.department;
   
    console.log("Department:", department);

    try {
        const allRecords = [];
        let recordCursor = "";
        let config = {};

        do {
            config = {
                app_name: "chaizup-order-to-delivery",
                report_name: "Quiz_Master_Report",
                max_records: 1000,
                criteria: "Not_Allowed_Department.ID == " + department, // filter applied
                record_cursor: recordCursor
            };

            const response = await ZOHO.CREATOR.DATA.getRecords(config);
            recordCursor = response?.record_cursor;

            if (response.code === 3000) 
            {
                allRecords.push(...response.data);
                console.log("not allowed records",allRecords);
                // console.log("response",response.data);
                //except this department if we have to show quiz to all departments
                //ShowQuizToAllDepartments(response.data);
            }
        }
          while (recordCursor);
          return allRecords;
    } catch (error) 
    {
        console.error("Error fetching records from All Quizzes:, error");
        return [];
    }
}); 
}
async function get_all_department_rec() {
    ZOHO.CREATOR.UTIL.getQueryParams().then(async function (response_params) {
   const log_in_details = JSON.parse(response_params.login_details);
    let department = log_in_details.department;
   
    console.log("Department:", department);

    try {
        const allRecords = [];
        let recordCursor = "";
        let config = {};

        do {
            config = {
                app_name: "chaizup-order-to-delivery",
                report_name: "Quiz_Master_Report",
                max_records: 1000,
                criteria:"All_Department == true",
                // criteria: "Allowed_Department.ID != " + department + " && Not_Allowed_Department.ID != " + department, // filter applied
                record_cursor: recordCursor
            };

            const response = await ZOHO.CREATOR.DATA.getRecords(config);
            recordCursor = response?.record_cursor;

            if (response.code === 3000) {
                allRecords.push(...response.data);
                console.log("all  department records",allRecords);
                // console.log("response",response.data);
            }
        } while (recordCursor);
          return allRecords;
    } catch (error) {
        console.error("Error fetching records from All Quizzes:, error");
        return [];
    }
}); 
}



function AddQuizHistory(quiz_topic,score)
{
    ZOHO.CREATOR.UTIL.getQueryParams().then(function (response_params) {
   const log_in_details = JSON.parse(response_params.login_details);
   let emp_rec_id = log_in_details.Employee_Rec_Id;
    console.log("Employee Record ID:", emp_rec_id);

  var config = {
  app_name: "chaizup-order-to-delivery",
  form_name: "Quiz_History_f",
  payload: {
    "data": {
      "Quiz_Topic":quiz_topic,
      "Employee_Name":emp_rec_id,
      "Last_Score":score
   }
  }
};
ZOHO.CREATOR.DATA.addRecords(config).then(function (response) {
    console.log("add quiz",response);
  if (response.code == 3000) {
    console.log(response);
  }
  if(response.code ==3001)
  {
   let error_msg = response.error[0].alert_message;
  //  show_alert("Error",error_msg);
  }
}).catch(function (error){
  console.error("Error adding quiz histroy",error);
})

});
}


async function GetQuizHistory(quiz_id,score) {
    ZOHO.CREATOR.UTIL.getQueryParams().then(async function (response_params) {
   const log_in_details = JSON.parse(response_params.login_details);
   let emp_rec_id = log_in_details.Employee_Rec_Id;


    // console.log("Employee Record ID:", emp_rec_id);

    try {
         const allRecords = [];
        let recordCursor = "";
        let config = {};

        do {
            config = {
                app_name: "chaizup-order-to-delivery",
                report_name: "Quiz_History",
                max_records: 1000,
                criteria: "Employee_Name ==" + emp_rec_id + "&&"+"Quiz_Topic =="+ quiz_id,
                // criteria: `Employee_Name == "${emp_rec_id}" && Quiz_Topic == "${quiz_id}"`, // filter applied
                record_cursor: recordCursor
            };

            const response = await ZOHO.CREATOR.DATA.getRecords(config);
            recordCursor = response?.record_cursor;
            // console.log("response",response);
           

            if (response.code === 3000) {
                let rec_data = response.data;
                
                 allRecords.push(...response.data);
                

                
                 
               rec_data.forEach(element => {
               let quiz_history_id = element.ID;
               let Last_Score = element.Last_Score;
            //    console.log("score", score);
                UpdateQuizHistory(quiz_history_id,score);

             // Correctly add each entry to the map
        //       quiz_score_map[quiz_history_id] = {
        //        ID: quiz_history_id,
        //        Last_Score: Last_Score
        //  };
      });
               
                // console.log("response",response.data);
            //    console.log("Quiz history Map:", quiz_score_map);
            }
        } while (recordCursor);
        
          return allRecords;
    } catch (error) {
        AddQuizHistory(quiz_id,score);
        // console.error("Error fetching records from Quiz History:, error");
        return [];
    }
}); 
}
function UpdateQuizHistory(quiz_id,score)
{
    console.log("score in update",score);

var config = {
  app_name: "chaizup-order-to-delivery",
  report_name: "Quiz_History",
  id: quiz_id,
  payload: {
    "data": {
    "Last_Score":score
} }
};
ZOHO.CREATOR.DATA.updateRecordById(config).then(function (response) {
    console.log("update response",response);
  if (response.code == 3000) {
    console.log("Quiz Updated",response);
    // show_alert("Success","Quiz Updated Successfully");
  }
  if(response.code == 3001)
  {
    let error_msg = response.error[0].alert_message;
    // show_alert("Error",error_msg);

  }
}).catch(function (error) {
  console.error("Error updating quiz:", error);
});

}
 async function CheckNoOfAttempt(max_attempt,quiz_id)
{
     ZOHO.CREATOR.UTIL.getQueryParams().then(async function (response_params) {
   const log_in_details = JSON.parse(response_params.login_details);
   let emp_rec_id = log_in_details.Employee_Rec_Id;


    // console.log("Employee Record ID:", emp_rec_id);

    try {
         const allRecords = [];
        let recordCursor = "";
        let config = {};

        do {
            config = {
                app_name: "chaizup-order-to-delivery",
                report_name: "Quiz_History",
                max_records: 1000,
                criteria: "Employee_Name ==" + emp_rec_id + "&&"+"Quiz_Topic =="+ quiz_id,
                // criteria: `Employee_Name == "${emp_rec_id}" && Quiz_Topic == "${quiz_id}"`, // filter applied
                record_cursor: recordCursor
            };

            const response = await ZOHO.CREATOR.DATA.getRecords(config);
            recordCursor = response?.record_cursor;
            // console.log("response",response);
           

            if (response.code === 3000) {
                let rec_data = response.data;
                
                 allRecords.push(...response.data);   
                for (let element of rec_data) {
               let no_of_attempt = element.Number_of_Attempt;
               let no_of_att = no_of_attempt + 1;
                if (no_of_att > max_attempt) {
                alert("No of attempts exceeded");
                return true; // this will now correctly return from the function
                }
             }
             return false; // if no match found
            
            }
        } while (recordCursor);
        
         
    } catch (error) {
       
        // console.error("Error fetching records from Quiz History:, error");
      
    }
}); 
}

function QuizHistoryOperation(operation_type)
{
    if(operation_type =="create")
    {
        AddQuizHistory(quiz_topic,score);

    }
    if(operation_type =="edit")
    {
        UpdateQuizHistory(quiz_topic,score);
    }
    if(operation_type =="read")
    {
        GetQuizHistory();
    }


}

function show_alert(msg_type, text) {
    try {
        let btn = `<div><button class="ok btn" onclick="hide_alert()">OK</button></div>`;
        document.getElementById("loader_alert").style.display = "flex";
       

        let alertHTML = `<div style="color:${msg_type === 'Success' ? 'green' : 'red'};">
                          
                            ${text}
                         </div>` + btn;

        document.getElementById("text_alert").innerHTML = alertHTML;
    } catch (e) {
        console.error("Alert Error:", e);
    }
}


function hide_alert() {
    
    document.getElementById("loader_alert").style.display = "none";
    document.getElementById("text_alert").innerHTML = "";
   
}



// Global State
let currentPage = 'home';
let selectedLanguage = '';
let selectedTopic = '';
let currentQuizDocId = '';
let currentQuestionIndex = 0;
let score = 0;
let isWaitingForAnswer = false;
let messages = [];
let lastWasCorrect = false;

const TOTAL_QUESTIONS = 10;

// ——— OpenAI & Chat History ———
const OPENAI_API_URL = 'https://api.openai.com/v1/chat/completions';
const API_KEY = typeof CONFIG !== 'undefined' ? CONFIG.API_KEY : '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'; // USE YOUR KEY
let conversationHistory = [];


// Navigation Functions
function navigateTo(page) {

    if(page == "home" || page =="topics")
    {
         get_allowed_department_rec();

    }
    // Hide all pages
    const pages = document.querySelectorAll('.page');
    pages.forEach(p => p.classList.remove('active'));
    
    // Show target page
    const targetPage = document.getElementById(page + '-page');
    if (targetPage) {
        targetPage.classList.add('active');
        currentPage = page;
    }
}

function navigateToTopics() {
    if (selectedLanguage) {
        navigateTo('topics');
        get_allowed_department_rec();
        // fetchTopics();
    }
}

// Language Selection Functions
function selectLanguage(languageCode, customName) {
    // Remove previous selection
    const cards = document.querySelectorAll('.language-card');
    cards.forEach(card => {
        card.classList.remove('selected');
        const tick = card.querySelector('.selected-tick');
        if (tick) tick.remove();
    });

    // Find the clicked card
    let card;
    if (customName) {
        // For custom language, find the "Other" card
        card = Array.from(cards).find(c => c.querySelector('.language-name')?.textContent === 'Other');
    } else {
        card = event.target.closest('.language-card');
    }

    if (card) {
        card.classList.add('selected');
        // Add green tick
        const tickDiv = document.createElement('div');
        tickDiv.className = 'selected-tick';
        tickDiv.innerHTML = `<svg width="20" height="20" viewBox="0 0 20 20" fill="white"><circle cx="10" cy="10" r="10" fill="#22c55e"/><path d="M6 10.5l2.5 2.5 5-5" stroke="white" stroke-width="2" fill="none" stroke-linecap="round"/></svg>`;
        tickDiv.style.position = 'absolute';
        tickDiv.style.top = '8px';
        tickDiv.style.right = '8px';
        tickDiv.style.background = 'transparent';
        card.style.position = 'relative';
        card.appendChild(tickDiv);
    }

    selectedLanguage = customName || languageCode;

    console.log(`Selected language: ${selectedLanguage}`);

    // Enable next button
    document.getElementById('next-btn').disabled = false;
}

// Popup logic for "Other"
function showOtherLanguagePopup() {
    document.getElementById('other-language-modal').style.display = 'flex';
    document.getElementById('other-language-input').value = '';
    setTimeout(() => {
        document.getElementById('other-language-input').focus();
    }, 100);
}
function closeOtherLanguagePopup() {
    document.getElementById('other-language-modal').style.display = 'none';
}
function submitOtherLanguage() {
    const val = document.getElementById('other-language-input').value.trim();
    if (val) {
        closeOtherLanguagePopup();
        selectLanguage('other', val);
    }
}

// Fetch topics for 2nd app UI
async function fetchTopics(response) {

    
//     get_quiz_history_by_em().then((quizMap) => {
//     console.log("Returned quiz map:", quizMap);
// });

  const quizMap = await get_quiz_history_by_em();
//   console.log("Returned quiz map:", quizMap);
  // Use the container for dynamically injected cards
  const topicGrid = document.querySelector('.topics-container') || document.getElementById('topics-grid') || document.getElementById('topic-grid');
  if (!topicGrid) return;

  topicGrid.innerHTML = ''; // Clear grid

for (let i = 0; i < response.length; i++) {
  let topicName = response[i]?.Quiz_Topic;
  console.log("Topic Name:", topicName);
  max_attempt = response[i]?.Max_Attempts;
  let quiz_video_url = response[i]?.Quiz_Video_Url;
  let videoUrl = quiz_video_url.url;
 
//   let quiz_transcript_safe = quiz_transcript?.replace(/"/g, '&quot;').replace(/'/g, '&#39;') || '';
//   console.log("quiz_transcript safe",quiz_transcript_safe);
//   let encodedTranscript = encodeURIComponent(quiz_transcript || "");

    // Column C
//   history["2344"]
  // let docUrl = response[i][2]; // Column D (not used here)
  let docId = response[i].ID;
  let quizInfo = quizMap[docId] || {}; 
  let no_of_attempt = quizInfo.Number_of_Attempt || 0;
  let last_score = quizInfo.Last_Score || 0 ;
//   console.log("no_of_attempt",no_of_attempt);
  let score_ = 0;

  let colorClass = i % 2 === 0 ? 'orange-red' : 'green-blue';

 let start_quiz_button = `
  <button style="border-radius: 18px; font-size: 16px;" class="btn btn-gradient ${colorClass}"
    onclick="startQuiz('${max_attempt}','${docId}', '${topicName.replace(/'/g,"\\'")}')">
    <i class="fa-brands fa-jedi-order"></i>
    Start Quiz
  </button>
`;
  if (no_of_attempt >= max_attempt) {
    start_quiz_button = `<button 
  style="border-radius: 18px; font-size: 16px; background-color: #e0e0e0; color: #a0a0a0; cursor: not-allowed; pointer-events: none; border: 1px solid #ccc;" 
  class="btn btn-outline btn-video" 
  disabled>
  No. Of Attempts Exceed
</button>`
  }

  const topicDiv = document.createElement('div');
  topicDiv.classList.add('topic-card');
  topicDiv.innerHTML = `
    <div class="topic-color-bar ${colorClass}"></div>
    <div class="topic-content">
      <h3 class="topic-title">${topicName}</h3>
      <p ><i>Max Attempt : ${max_attempt}</i></p>
      <div class="topic-buttons">
        <button style="border-radius: 18px; font-size: 16px;" class="btn btn-outline btn-video" onclick="openVideo('${videoUrl}')">
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <polygon points="5,3 19,12 5,21"/>
          </svg>
          Watch Video
        </button>
        ${start_quiz_button}
      </div>
      <p><i>Total Attempt :${no_of_attempt}</i><p>
      <p><i>Last Score :${last_score}<i><p>
    </div>
  `;
  topicGrid.appendChild(topicDiv);
}
  // }).get_all_topics(serverrec_id);
}


// Start quiz for 2nd app UI
async function startQuiz(max_attempt,docId, topicName) {

 ZOHO.CREATOR.UTIL.getQueryParams().then(async function (response_params) {
   const log_in_details = JSON.parse(response_params.login_details);
   let emp_rec_id = log_in_details.Employee_Rec_Id;
    try {
        const allRecords = [];
        let recordCursor = "";
        let config = {};

        do {
            config = {
                app_name: "chaizup-order-to-delivery",
                report_name: "Quiz_History",
                max_records: 1000,
                criteria: "Employee_Name ==" + emp_rec_id + "&&"+"Quiz_Topic =="+ docId,
                // criteria: `Employee_Name == "${emp_rec_id}" && Quiz_Topic == "${quiz_id}"`, // filter applied
                record_cursor: recordCursor
            };

            const response = await ZOHO.CREATOR.DATA.getRecords(config);
            recordCursor = response?.record_cursor;
            // console.log("response",response);
           

            if (response.code === 3000) {
                let rec_data = response.data;
                
               allRecords.push(...response.data);   
               for (let element of rec_data) {
               let no_of_attempt = element.Number_of_Attempt;
               let no_of_att = no_of_attempt + 1;
                if (no_of_att > max_attempt) {
                alert("No of attempts exceeded");
                navigateToTopics();
                return true; // this will now correctly return from the function
                }
             }
          
            
            }
        } while (recordCursor);
        
         
    } catch (error) {
          // console.error("Error fetching records from Quiz History:, error")
    }
}); 


//   const quizTranscript = await GetMasterRecordById(docId);
//   console.log("quiz Transcript:", quizTranscript);

   let quiz_master = {
                   app_name: "chaizup-order-to-delivery",
                   report_name: "Quiz_Master_Report",
                   id : docId
};
ZOHO.CREATOR.DATA.getRecordById(quiz_master).then(function (response) {
  console.log(response);
  if(response.code == 3000)
  {
  let quiz_data = response.data;
   quiz_transcript = quiz_data.Quiz_Transcript;
//   console.log("quiz_transcript",quiz_transcript);
  }
  currentQuestionIndex = 0;
  score = 0;
  currentQuizDocId = docId; 
  window.lastSelectedOptionIndex = null;
  selectedTopic = topicName || '';
  conversationHistory = [];
  document.getElementById('mcq-question-area').style.display = 'none';
  document.getElementById('quiz-loader').style.display = 'block';
  navigateTo('quiz');

  let lang = selectedLanguage;
  if (!lang || lang.trim() === '') lang = 'English';

  // Fetch the story from Apps Script using docId
//   google.script.run.withSuccessHandler(function(fullStory) {
    // Now fullStory contains the entire article/transcript text
    const systemPrompt = `You are an AI quiz master. You will be given a short story. Your task is to:
1. Create exactly ${TOTAL_QUESTIONS} unique, sequential multiple-choice questions *only* on the provided story. Ensure multiple-choice questions cover different parts of the story.
2. Conduct the entire quiz (questions, feedback, final score message) ONLY in the specified language: **${lang}**.
3. Ask the first question immediately.
4. When the user replies with an answer, check if it is **a single alphabet character ["A", "B", "C", or "D"]**.
* If yes, check the answer based on the story and respond with:
* "[CORRECT] Correct!" (in ${lang}) if the answer is correct.
* "[INCORRECT] Incorrect. No Points. The correct answer is [correct answer]..." (in ${lang}) if incorrect.
* If no (e.g., answer is "AA", "abc", "I don't know", empty, or asking for the answer and any number includes example 1,A1 .. ), respond with:
* "[INCORRECT] Incorrect. No Points." (in ${lang})

5. Always continue to the **next sequential question immediately after giving feedback**.
6. Do **not** provide answers directly or reveal future questions.
7. Do **not** add small talk, commentary, or greetings. Just show feedback and the next question.
8. After the final question (question number ${TOTAL_QUESTIONS}), show:
* "Quiz Complete! Final Score: X/${TOTAL_QUESTIONS}" (in ${lang}), where X is the number of correct answers.
* Do **not** ask any more questions after this.

**IMPORTANT INSTRUCTION FOR OUTPUT FORMAT:**
After your feedback for each answer (including the very first question), you must ALWAYS provide the next question as a JSON object on its own line, in this exact format:
{"question": "Your question text here", "options": ["A) ...", "B) ...", "C) ...", "D) ..."]}
Do not write anything else after the JSON object. Do not repeat the question or options in any other format.



**IMPORTANT**: For every feedback, always start the feedback line with [CORRECT] or [INCORRECT], then provide your response as usual in the quiz language. Do not translate [CORRECT] or [INCORRECT]—they must be in English and at the start of the feedback line.

---
${quiz_transcript}

---
Now, ask the first question. After the question, provide the JSON object as described above.`;

    conversationHistory.push({ role: "system", content: systemPrompt });
    callOpenAI();
//   }).get_quiz_content_by_doc_id(docId);
});
}


// Quiz Functions
function initializeQuiz() {
    // // const chatMessages = document.getElementById('chat-messages');
    // // chatMessages.innerHTML = '';
    
    //     // Set color bar based on topic
    // const colorBar = document.getElementById('quiz-color-bar');
    // if (colorBar) {
    //     colorBar.className = 'topic-color-bar ' + (selectedTopic === 'chaizup' ? 'orange-red' : 'green-blue');
    // }

    // const topicName = selectedTopic === 'chaizup' ? 'Chaizup and chai market trends' : 'India\'s FMCG sector';
    
    // // Welcome message
    // // addMessage('ai', `Welcome to the quiz! I'll ask you ${TOTAL_QUESTIONS} questions about ${topicName}. Let's begin!`);
    
    // // Update score display
    // updateScoreDisplay();
    
    // // Start first question after delay
    // setTimeout(() => {
    //     // askQuestion(0);
    // }, 500);

      // 1. Set color bar based on topic
  const colorBar = document.getElementById('quiz-color-bar');
  if (colorBar) {
    colorBar.className =
      'topic-color-bar ' +
      (selectedTopic === 'chaizup' ? 'orange-red' : 'green-blue');
  }

  // 2. (Optional) Display a welcome message in your UI
  //    e.g. addMessage('system', `Quiz starting: ${TOTAL_QUESTIONS} questions on ${topicName}.`);

  // 3. Initialize score display
  updateScoreDisplay();

  // 4. Immediately call the AI for the first question
  callOpenAI();
}

// Renders AI-provided questionObj onto your MCQ UI
function renderMCQFromAI(questionObj) {
      document.getElementById('quiz-loader').style.display = 'none';
    document.getElementById('mcq-question-area').style.display = 'block';
    const area = document.getElementById('mcq-question-area');
    area.innerHTML = `
      <div class="mcq-question">Q${currentQuestionIndex + 1}: ${questionObj.question}</div>
      <div class="mcq-options">
        ${questionObj.options.map((opt,i)=>`
          <div class="mcq-option" data-index="${i}" onclick="selectMCQOptionAI('${['A','B','C','D'][i]}', ${i})">
            <span class="mcq-radio">
                <i class="fa-solid fa-check icon-tick" style="display:none"></i>
                <i class="fa-solid fa-xmark icon-cross" style="display:none"></i>
            </span>
            <span>${opt}</span>
          </div>`).join('')}
      </div>
      <div id="bot-loader" style="display:none; margin-top:2.5rem; text-align:center;">
        <svg width="56" height="56" viewBox="0 0 64 64" fill="none" stroke="#222" stroke-width="3.2" stroke-linecap="round" stroke-linejoin="round" class="thinking-bot-svg">
          <rect x="8" y="20" width="48" height="32" rx="10" stroke="#222" fill="none"/>
          <circle cx="32" cy="10" r="4" stroke="#222" fill="none"/>
          <line x1="32" y1="14" x2="32" y2="20" stroke="#222"/>
          <rect x="4" y="28" width="8" height="16" rx="2" stroke="#222" fill="none"/>
          <rect x="52" y="28" width="8" height="16" rx="2" stroke="#222" fill="none"/>
          <circle cx="24" cy="36" r="3" fill="#222"/>
          <circle cx="40" cy="36" r="3" fill="#222"/>
          <path d="M27 44 Q32 48 37 44" stroke="#222" fill="none"/>
        </svg>
        <div class="bot-think-text" style="color:#222; font-weight:500; font-size:1rem; margin-top:.7rem; letter-spacing:.01em;">Thinking...</div>
      </div>
    `;
    window.lastSelectedOptionIndex = null;
    updateScoreDisplay();
}

async function callOpenAI() {
  // setLoading(true);
  try {
    const res = await fetch(OPENAI_API_URL, {
      method:'POST',
      headers:{
        'Content-Type':'application/json',
        'Authorization':`Bearer ${API_KEY}`
      },
      body: JSON.stringify({
        model: "gpt-4",  // or "gpt-4" or "gpt-3.5-turbo"
        messages: conversationHistory,
        temperature: 0.5
      })
    });
    const data = await res.json();
    if (!res.ok || !data.choices || !data.choices[0] || !data.choices[0].message) {
      console.error('OpenAI API error:', data);
      alert("OpenAI API Error: " + (data.error?.message ?? JSON.stringify(data)));
      // setLoading(false);
      return;
    }
    const aiText = data.choices[0].message.content.trim();
    conversationHistory.push({ role:'assistant', content: aiText });
    handleAIResponse(aiText);
  } catch (e) {
    alert("Network or OpenAI error: " + e.message);
    console.error(e);
  } finally {
    // setLoading(false);
  }
}

function extractLastJsonObject(text) {
    // If the text itself is a JSON object, just parse it
    const trimmed = text.trim();
    if (trimmed.startsWith('{') && trimmed.endsWith('}')) {
        try {
            return JSON.parse(trimmed);
        } catch (e) { return null; }
    }
    // Otherwise, try to find the last {...} in the text
    const regex = /({[\s\S]*})/m;
    const match = text.match(regex);
    if (match) {
        try {
            return JSON.parse(match[1]);
        } catch (e) { return null; }
    }
    return null;
}

function handleAIResponse(text) {
    console.log("AI RAW RESPONSE:", text);
        const botLoader = document.getElementById('bot-loader');
    if (botLoader) botLoader.style.display = 'none';
    // 1. If it contains "Quiz Complete", parse the final score and show results
    if (/Quiz Complete/i.test(text)) {
        const m = text.match(/Final Score:\s*(\d+)\/(\d+)/i);
        if (m) score = parseInt(m[1], 10);
        showResults();
        return;
    }

    // 2. Robust handling: Detect if AI sent pure JSON or feedback+JSON
    let feedback, nextQraw;
    if (text.trim().startsWith('{') && text.trim().endsWith('}')) {
        // AI sent only JSON, no feedback
        feedback = '';
        nextQraw = text.trim();
    } else {
        const parts = text.split('\n');
        feedback = parts[0];
        nextQraw = parts.slice(1).join('\n').trim();
    }

    // 3. Highlight the last selected option safely
    const options = document.querySelectorAll('.mcq-option');
    const idx = window.lastSelectedOptionIndex;

let wasCorrect = false;
if (typeof idx === 'number' && options[idx]) {
    if (feedback.startsWith('[CORRECT]')) {
        options[idx].classList.add('correct');
        options[idx].querySelector('.icon-tick').style.display = 'block';
        wasCorrect = true;
    } else if (feedback.startsWith('[INCORRECT]')) {
        options[idx].classList.add('incorrect');
        options[idx].querySelector('.icon-cross').style.display = 'block';
        // Also mark the correct answer if AI mentions it (optional, based on your prompt)
        const correctLabel = feedback.match(/([A-D])\)/)?.[1];
        if (correctLabel) {
            const cidx = ['A','B','C','D'].indexOf(correctLabel);
            if (cidx > -1 && options[cidx]) {
                options[cidx].classList.add('correct');
                options[cidx].querySelector('.icon-tick').style.display = 'block';
            }
        }
    }
}

    // 4. Wait so user sees feedback, THEN increment question and (if correct) score, render next
    setTimeout(() => {
        const obj = extractLastJsonObject(nextQraw);
        console.log("Myobj", obj);
        if (obj && obj.question && obj.options) {
            if (typeof idx === 'number') {
                currentQuestionIndex++;
                if (wasCorrect) score++;
            }
            renderMCQFromAI(obj);
        } else {
            // Fallback: try to parse plain text options
            const matches = nextQraw.match(/^(.+?)\nA\)[\s\S]+/);
            if (matches) {
                const question = matches[1].trim();
                const optionsArr = nextQraw.match(/[A-D]\)[^\n]+/g);
                if (optionsArr && optionsArr.length === 4) {
                    if (typeof idx === 'number') {
                        currentQuestionIndex++;
                        if (wasCorrect) score++;
                    }
                    renderMCQFromAI({ question, options: optionsArr });
                    return;
                }
            }
            showResults();
            console.error("Failed to parse AI question JSON:", nextQraw);
        }
    }, 900);
}

window.selectMCQOptionAI = function(label, optionIndex) {
    // 1. Block further clicks
    document.querySelectorAll('.mcq-option').forEach(o=>o.onclick=null);

    // 2. Store which option was selected, to highlight after AI feedback
    window.lastSelectedOptionIndex = optionIndex;

    // 2.5. Show the bot loader!
    const botLoader = document.getElementById('bot-loader');
    if (botLoader) botLoader.style.display = 'block';

    // 3. Push the user's choice into conversationHistory
    conversationHistory.push({ role: "user", content: label });

    // 4. Immediately call the AI for feedback + next question
    callOpenAI();
};

function enableInput() {
    const input = document.getElementById('quiz-input');
    const sendBtn = document.getElementById('send-btn');
    
    input.disabled = false;
    input.placeholder = "Type your answer...";
    sendBtn.disabled = false;
    
    input.focus();
}

function disableInput() {
    const input = document.getElementById('quiz-input');
    const sendBtn = document.getElementById('send-btn');
    
    input.disabled = true;
    input.placeholder = "Waiting for next question...";
    sendBtn.disabled = true;
}

function submitAnswer() {
    const input = document.getElementById('quiz-input');
    const answer = input.value.trim();
    
    if (!answer || !isWaitingForAnswer) return;
    
    // Add user message
    // addMessage('user', answer);
    
    // Clear input
    input.value = '';
    disableInput();
    
    // Check answer
    const questions = quizData[selectedTopic];
    const correctAnswer = questions[currentQuestionIndex].answer.toLowerCase();
    const userAnswer = answer.toLowerCase();
    
    // Simple keyword matching
    const isCorrect = correctAnswer.split(' ').some(word => userAnswer.includes(word)) || 
                     userAnswer.includes(correctAnswer.split(' ')[0]);
    
    let responseMessage;
    if (isCorrect) {
        score++;
        responseMessage = `Correct! Great job. The answer is: ${questions[currentQuestionIndex].answer}`;
    } else {
        responseMessage = `Not quite right. The correct answer is: ${questions[currentQuestionIndex].answer}`;
    }
    
    // addMessage('ai', responseMessage);
    updateScoreDisplay();
    isWaitingForAnswer = false;
    
    // Move to next question
    setTimeout(() => {
        currentQuestionIndex++;
        // askQuestion(currentQuestionIndex);
    }, 2000);
}

function updateScoreDisplay() {
    const questionNum = currentQuestionIndex + 1;
    document.getElementById('question-number').textContent = `Question ${questionNum} of ${TOTAL_QUESTIONS}`;
    document.getElementById('correct-count').textContent = `Correct: ${score}`;
    // Update progress bar
    const progress = document.getElementById('quiz-progress');
    const progressPercent = ((questionNum - 1) / TOTAL_QUESTIONS) * 100;
    progress.style.width = progressPercent + '%';
}

function completeQuiz() {
    // addMessage('ai', `Quiz completed! You scored ${score} out of ${TOTAL_QUESTIONS}. Let's see your detailed results!`);
    
    setTimeout(() => {
        showResults();
    }, 2000);
}

function showResults() {

   let quiz_id = currentQuizDocId;
   console.log("quiz_id",quiz_id);
    navigateTo('results');
    renderResults();
    GetQuizHistory(quiz_id,score);

 
    // Debug logs (remove after verification)
    // console.log('Employee Name:', serverEmployeeName);
    // console.log('Employee Email:', serverEmployeeEmail);
    // console.log('REC ID:', serverrec_id);
    // console.log('Quiz ID:', currentQuizDocId);

    // let passed_object = {
    //     name: serverEmployeeName,
    //     email: serverEmployeeEmail,
    //     rec_id: serverrec_id,
    //     score: score,
    //     quiz_id: currentQuizDocId
    // };
    // google.script.run.withSuccessHandler(function(res){
    //     console.log("Score pushed to Quiz Attendees sheet!", res);
    // }).append_score(passed_object);



}

function renderResults() {
    const resultsContent = document.getElementById('results-content');
    const percentage = Math.round((score / TOTAL_QUESTIONS) * 100);
    // const topicName = selectedTopic === 'chaizup' ? 'Chaizup Market' : 'FMCG Sector';
    const topicName = selectedTopic

    // Build the new summary UI
    resultsContent.innerHTML = `
        <div class="quiz-summary-container">
            <!-- Header with Topic and Circular Progress -->
            <div class="quiz_summary_header">
                <div class="header-content">
                    <h1 class="title">Quiz Summary</h1>
                    <div class="topic-section">
                        <span class="topic-label">Topic:</span>
                        <span class="topic-name" id="topicName">${topicName}</span>
                    </div>
                </div>
                <!-- Circular Progress -->
            </div>

            <!-- Stats Grid -->
            <div class="stats-grid">
                <div class="stat-card blue-card">
                    <div class="stat-number" id="totalQuestions">${TOTAL_QUESTIONS}</div>
                    <div class="stat-label">Total Questions</div>
                </div>
                <div class="stat-card green-card">
                    <div class="stat-number" id="correctAnswers">${score}</div>
                    <div class="stat-label">Correct Answers</div>
                </div>
                <div class="stat-card purple-card">
                    <div class="stat-number" id="accuracyRate">${percentage}%</div>
                    <div class="stat-label">Accuracy Rate</div>
                </div>
            </div>

            <!-- Progress Bar -->
            <div class="progress-section">
                <div class="progress-header">
                    <span class="progress-label">Progress</span>
                    <span class="progress-fraction" id="progressFraction">${score}/${TOTAL_QUESTIONS}</span>
                </div>
                <div class="progress-bar-container">
                    <div class="progress-bar-two" id="progressBar"></div>
                </div>
            </div>

            <!-- Performance Message -->
            <div class="performance-message">
                <div class="message-title"></div>
                <div class="message-text"></div>
            </div>
        </div>
    `;

    // Set progress bar width
    const progressBar = document.getElementById('progressBar');
    progressBar.style.width = `${percentage}%`;

    // Set performance message
    const messageTitle = resultsContent.querySelector('.message-title');
    const messageText = resultsContent.querySelector('.message-text');
    if (percentage >= 80) {
        messageTitle.textContent = '🎉 Excellent Work!';
        messageText.textContent = "Outstanding performance! You've mastered this topic.";
    } else if (percentage >= 60) {
        messageTitle.textContent = '👍 Good Job!';
        messageText.textContent = 'Good work! A little more practice will make you perfect.';
    } else {
        messageTitle.textContent = '📚 Keep Learning!';
        messageText.textContent = 'Room for improvement - review the material.';
    }
}

function getMoodData(percentage) {
    if (percentage >= 80) {
        return {
            mood: "excellent",
            emoji: "🎉",
            title: "Outstanding Performance!",
            message: "You're a true expert! Your knowledge is impressive and you should be proud of this achievement."
        };
    } else if (percentage >= 60) {
        return {
            mood: "good",
            emoji: "😊",
            title: "Great Job!",
            message: "You did well! There's room for improvement, but you clearly understand the fundamentals."
        };
    } else if (percentage >= 40) {
        return {
            mood: "neutral",
            emoji: "😐",
            title: "Not Bad!",
            message: "You got some answers right! With a bit more study, you'll definitely improve your score."
        };
    } else {
        return {
            mood: "needs-improvement",
            emoji: "😞",
            title: "Keep Learning!",
            message: "Don't worry! Everyone starts somewhere. Review the material and try again - you've got this!"
        };
    }
}

// Event Listeners
document.addEventListener('DOMContentLoaded', function() {
    // Quiz input enter key handler
    const quizInput = document.getElementById('quiz-input');
    if (quizInput) {
        quizInput.addEventListener('keypress', function(e) {
            if (e.key === 'Enter' && !e.shiftKey) {
                e.preventDefault();
                submitAnswer();
            }
        });
    }
    
    // Initialize with home page
    navigateTo('home');
});

function submitOtherLanguage() {
    const val = document.getElementById('other-language-input').value.trim();
    if (val) {
        closeOtherLanguagePopup();
        // Update the "Custom Language" label in the Other card
        const otherCard = Array.from(document.querySelectorAll('.language-card')).find(
            c => c.querySelector('.language-name')?.textContent === 'Other'
        );
        if (otherCard) {
            const englishDiv = otherCard.querySelector('.language-english');
            if (englishDiv) {
                englishDiv.textContent = val;
            }
        }
        selectLanguage('other', val);
    }
}

// Utility Functions
function resetQuiz() {
    currentQuestionIndex = 0;
    score = 0;
    messages = [];
    isWaitingForAnswer = false;
    selectedLanguage = '';
    selectedTopic = '';
    
    // Reset language selection
    const cards = document.querySelectorAll('.language-card');
    cards.forEach(card => card.classList.remove('selected'));
    
    // Disable next button
    document.getElementById('next-btn').disabled = true;
    
    navigateTo('home');
}

function openVideo(video_url) {
    let _video_container = document.getElementById('videoContainer_id');
    _video_container.style.display = 'flex';
    _video_container.innerHTML = `
        <div style="position:relative; width:90vw; max-width:600px;">
            <iframe width="100%" height="340" id="video_embeder" src="${video_url}"
            frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
            sandbox="allow-scripts allow-popups allow-forms allow-same-origin"
            allowfullscreen style="border-radius:12px; background:#000;"></iframe>
            <button class="cross-button" onclick="closedVideo()" style="position:absolute;top:-18px;right:-18px;width:36px;height:36px;border-radius:50%;background:#fff;color:#222;border:none;box-shadow:0 2px 8px rgba(0,0,0,0.22);font-size:2rem;cursor:pointer;z-index:10;">×</button>
        </div>
    `;
}
function closedVideo() {
    let _video_container = document.getElementById('videoContainer_id');
    _video_container.style.display = 'none';
    _video_container.innerHTML = "";
}

// Export functions for global access (if needed)
window.navigateTo = navigateTo;
window.selectLanguage = selectLanguage;
window.navigateToTopics = navigateToTopics;
window.startQuiz = startQuiz;
window.submitAnswer = submitAnswer;
window.resetQuiz = resetQuiz;
     


