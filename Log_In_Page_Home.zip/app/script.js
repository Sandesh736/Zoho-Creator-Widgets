 const toggles = document.querySelectorAll('.task-toggle');
const overlay = document.getElementById('overlay');
const overlayTitle = document.getElementById('overlayHeader');
const clearBtn = document.getElementById('clear-filters');
let retail_pending_data = [];


toggles.forEach(toggle => {
  toggle.addEventListener('click', () => {
    const title = toggle.getAttribute('data-title');
    overlay.classList.remove('hidden');

    if (title === "My Tasks") {
  overlayTitle.textContent = "My Tasks";
  populateFiltersTask();
  fetchTaskData();
  count_of_pending_task();


  // Set the clear button handler using closure to capture title
    
  

  // Wait until filters are in the DOM (you can adjust timing or use MutationObserver for dynamic UIs)
  setTimeout(() => {
    // const filterStatus = document.getElementById("filter-status");
    // const filterType = document.getElementById("filter-type");
    // const filterFrom = document.getElementById("filter-from");
    // const filterTo = document.getElementById("filter-to");

    // const getFilterValues = () => ({
    //   status: filterStatus.value,
    //   type: filterType.value,
    //   fromDate: filterFrom.value,
    //   toDate: filterTo.value
    // });

    // // Trigger when any filter is changed
    // [filterStatus, filterType, filterFrom, filterTo].forEach(input =>
    //   input.addEventListener("change", () => {
    //     const values = getFilterValues();
    //     filterTasks(values);
    //   })
    // );
     clearBtn.onclick = () => {
      filterStatus.value = "";
      filterType.value = "";
      filterFrom.value = "";
      filterTo.value = "";
      fetchTaskData();
      count_of_pending_task();
    };

    // Optional: Run it once on load
    // filterTasks(getFilterValues());

  }, 100); // Delay ensures the filters are in the DOM
}
else if (title === "Cash Claim") {
  overlayTitle.textContent = "Cash Claim";
  populateFiltersCashClaim();
  fetchcashclaim();
  count_of_pending_cash_claim();
  

  setTimeout(() => {
  //   const filterClaimType = document.getElementById("filter-status");
  //   const filterClaimCategory = document.getElementById("filter-type");
  //   const filterPaymentStatus = document.getElementById("filter-payment-status");
  //   const filterFromClaim = document.getElementById("filter-from");
  //   const filterToClaim = document.getElementById("filter-to");

  //   const getCashClaimFilterValues = () => ({
  //     claimType: filterClaimType.value,
  //     category: filterClaimCategory.value,
  //     paymentStatus: filterPaymentStatus.value,
  //     fromDate: filterFromClaim.value,
  //     toDate: filterToClaim.value
  //   });

  //   [filterClaimType, filterClaimCategory, filterPaymentStatus, filterFromClaim, filterToClaim].forEach(input =>
  //     input.addEventListener("change", () => {
  //       const values = getCashClaimFilterValues();
  //       filterCashClaim(values);
  //     })
  //   );
// ✅ SET CLEAR BUTTON HERE
    clearBtn.onclick = () => {
      filterClaimType.value = "";
      filterClaimCategory.value = "";
      filterPaymentStatus.value = "";
      filterFromClaim.value = "";
      filterToClaim.value = "";
       fetchcashclaim(); 
       count_of_pending_cash_claim();
    };
    

    // Optional: run filter once on load
    // filterCashClaim(getCashClaimFilterValues());

  }, 100);
  
  
} 
else if (title === "My Help Ticket") {
  overlayTitle.textContent = "My Help Ticket";
  populatefiltershelpTicket();
  fetchHelpTicketkData();
  count_of_pending_help_ticket();
  

  setTimeout(() => {
    // const filterTicketStatus = document.getElementById("filter-status");
    // const filterTicketFrom = document.getElementById("filter-from");
    // const filterTicketTo = document.getElementById("filter-to");

    // const getHelpTicketFilterValues = () => ({
    //   status: filterTicketStatus.value,
    //   fromDate: filterTicketFrom.value,
    //   toDate: filterTicketTo.value
    // });

    // [filterTicketStatus, filterTicketFrom, filterTicketTo].forEach(input =>
    //   input.addEventListener("change", () => {
    //     const values = getHelpTicketFilterValues();
    //     filterhelpTicket(values);
    //   })
    // );


    clearBtn.onclick = () => {
      filterTicketStatus.value = "";
      filterTicketFrom.value = "";
      filterTicketTo.value = "";
      
      fetchHelpTicketkData();
      count_of_pending_help_ticket();
    };

    // filterhelpTicket(getHelpTicketFilterValues());
  }, 100);

  
}
});
});


  function closeOverlay() {
    overlay.classList.add('hidden');
   const card_list = document.getElementById("card-list");
   card_list.innerHTML = "";
    filterFrom.value = "";
    filterTo.value = "";
    filterTicketFrom.value = "";
    filterTicketTo.value = "";
     filterFromClaim.value = "";
      filterToClaim.value = "";
  
  }


  // Back button closes overlay
  document.querySelector('.back-button').addEventListener('click', closeOverlay);

  function populateFiltersTask() {
     document.getElementById('filter-type').style.display = "block";
      document.getElementById('filter-status').style.display = "block";
      document.getElementById('filter-from').style.display = "block";
      document.getElementById('filter-to').style.display = "block";
     document.getElementById('filter-payment-status').style.display = "none";
     document.getElementById('filter-claim-type').style.display = "none";
     document.getElementById('filter-claim-category').style.display = "none";
     document.getElementById('filter-from-claim').style.display = "none";
     document.getElementById('filter-to-claim').style.display = "none";
     document.getElementById('filter-ticket-status').style.display = "none";
     document.getElementById('filter-ticket-from').style.display = "none";
     document.getElementById('filter-ticket-to').style.display = "none";
    // 1. Status Filter Options
    const statusOptions = [
      "Working on it",
      "Resolved / Completed",
      "Not Completed",
      "Created"
    ];
    
    const statusSelect = document.getElementById('filter-status');
    statusSelect.innerHTML = `<option value="" disabled selected hidden>Task Status</option>`; // Reset and keep placeholder
    statusOptions.forEach(status => {
      const option = document.createElement('option');
      option.value = status;
      option.textContent = status;
      statusSelect.appendChild(option);
    });

    // 2. Type Filter Options
    const typeOptions = [
      "Help Ticket",
      "Deligation(One Time)",
      "Daily",
      "Weekly",
      "Quarterly",
      "Yearly",
      "Monthly",
      "Fortnightly"
    ];

    const typeSelect = document.getElementById('filter-type');
    typeSelect.innerHTML = `<option value="" disabled selected hidden>Task Type</option>`;
    typeOptions.forEach(type => {
      const option = document.createElement('option');
      option.value = type;
      option.textContent = type;
      typeSelect.appendChild(option);
    });

    // 3. Date Filters (Set default to last 7 days)
    const fromDateInput = document.getElementById('filter-from');
    const toDateInput = document.getElementById('filter-to');

    // document.getElementById('clear-filters').addEventListener('click', function () {
    //   statusSelect.value = "";
    //   typeSelect.value = "";
    //   fromDateInput.value = "";
    //   toDateInput.value = "";
    //   fetchTaskData();

    //   });
  }

function populateFiltersCashClaim()
{
   document.getElementById('filter-type').style.display = "none";
   document.getElementById('filter-status').style.display = "none";
   document.getElementById('filter-from').style.display = "none";
   document.getElementById('filter-to').style.display = "none";
   document.getElementById('filter-ticket-status').style.display = "none";
   document.getElementById('filter-ticket-from').style.display = "none";
   document.getElementById('filter-ticket-to').style.display = "none";
   document.getElementById('filter-payment-status').style.display = "block";
   document.getElementById('filter-claim-type').style.display = "block";
   document.getElementById('filter-from-claim').style.display = "block";
   document.getElementById('filter-to-claim').style.display = "block";
   document.getElementById('filter-claim-category').style.display = "block";
  // 1. Status Filter Options
    const statusOptions = [
      "Expense Reimbursement"
      

    ];
    const paymentStatusOptions = [
      "Partial Payment",
      "Pending",
      "Paid"
    ];

    const statusSelect = document.getElementById('filter-claim-type');
    statusSelect.innerHTML = `<option value="" disabled selected hidden> Claim Type </option>`; // Reset and keep placeholder
    statusOptions.forEach(status => {
      const option = document.createElement('option');
      option.value = status;
      option.textContent = status;
      statusSelect.appendChild(option);
    });

    const paymentStatusSelect = document.getElementById('filter-payment-status');
    paymentStatusSelect.innerHTML = `<option value="" disabled selected hidden>Payment Status</option>`; // Reset and keep placeholder

    paymentStatusOptions.forEach(status => {
      const option = document.createElement('option');
      option.value = status;
      option.textContent = status;
      paymentStatusSelect.appendChild(option);
    });

    // 2. Type Filter Options
    const typeOptions = [
      "Consumable",
      "Repairs & Maintenance",
      "Transportation/Courier",
      "Factory Tools & Utilities",
      "Fuel",
      "Office/Recharge",
      "Stationery",
      "Outstation Travel",
      "Transport/Carpool",
      "Factory Overheads",
      "IT Department",
      "Incentive",
      "Food Entertainment"
    ];

    const typeSelect = document.getElementById('filter-claim-category');
    typeSelect.innerHTML = `<option value="" disabled selected hidden>Claim Category</option>`;
    typeOptions.forEach(type => {
      const option = document.createElement('option');
      option.value = type;
      option.textContent = type;
      typeSelect.appendChild(option);
    });

    // 3. Date Filters (Set default to last 7 days)
    // const fromDateInput = document.getElementById('filter-from');
    // const toDateInput = document.getElementById('filter-to');

    // document.getElementById('clear-filters').addEventListener('click', function () {
    //   statusSelect.value = "";
    //   paymentStatusSelect.value = "";
    //   typeSelect.value = "";
    //   fromDateInput.value = "";
    //   toDateInput.value = "";
    //   fetchcashclaim();

    //   });

    
  }

  function populatefiltershelpTicket()
  {
     document.getElementById('filter-type').style.display = "none";
   document.getElementById('filter-status').style.display = "none";
   document.getElementById('filter-from').style.display = "none";
   document.getElementById('filter-to').style.display = "none";
   document.getElementById('filter-ticket-status').style.display = "block";
   document.getElementById('filter-ticket-from').style.display = "block";
   document.getElementById('filter-ticket-to').style.display = "block";
   document.getElementById('filter-payment-status').style.display = "none";
   document.getElementById('filter-claim-type').style.display = "none";
   document.getElementById('filter-from-claim').style.display = "none";
   document.getElementById('filter-to-claim').style.display = "none";
   document.getElementById('filter-claim-category').style.display = "none";
    const statusOptions = [
      "Working on it",
      "Resolved / Completed",
      "Not Completed",
      "Created"

    ];
    const statusSelect = document.getElementById('filter-ticket-status');
    statusSelect.innerHTML = `<option value="" disabled selected hidden>Ticket Status</option>`; // Reset and keep placeholder
    statusOptions.forEach(status => {
      const option = document.createElement('option');
      option.value = status;
      option.textContent = status;
      statusSelect.appendChild(option);
    });
    
    // const fromDateInput = document.getElementById('filter-from');
    // const toDateInput = document.getElementById('filter-to');


    // document.getElementById('clear-filters').addEventListener('click', function () {
    //   statusSelect.value = "";
    //   fromDateInput.value = "";
    //   toDateInput.value = "";
    //   fetchHelpTicketkData();

    //   });

  }


// Event Listner for Pending Task Table

const taskCount = document.getElementById('taskCountToggle');
const tableContainer = document.getElementById('taskTableContainer');

taskCount.addEventListener('click', () => {
  pending_task_count_task_type_wise();
  tableContainer.classList.toggle('hidden');
});

// Event Listner for pending cash claim table

document.addEventListener("DOMContentLoaded", function () {
  const pettyCountText = document.getElementById("CashClaimCount");

  pettyCountText.addEventListener("click", function () {
    pending_cash_claim_count();
    const tableSection = document.getElementById("PendingCashClaim");

    // Toggle display
    tableSection.style.display = 
      tableSection.style.display === "none" || tableSection.style.display === ""
        ? "block"
        : "none";
  });
});


document.addEventListener("DOMContentLoaded", function () {
  const helpticketcount = document.getElementById("helpticketCountToggle");

  helpticketcount.addEventListener("click", function () {
    pending_help_ticket_count();
    const tableSection = document.getElementById("HelpTicketTableContainer");

    // Toggle display
    tableSection.style.display = 
      tableSection.style.display === "none" || tableSection.style.display === ""
        ? "block"
        : "none";
  });
})




function clearfilters(title)
{

if (title === "My Tasks") {
    // Clear My Tasks filters
      statusSelect.value = "";
      typeSelect.value = "";
      fromDateInput.value = "";
      toDateInput.value = "";
    
    fetchTaskData(); // Re-fetch with cleared filters
  }
else if (title === "Cash Claim") {
    // Clear Cash Claim filters
      statusSelect.value = "";
      paymentStatusSelect.value = "";
      typeSelect.value = "";
      fromDateInput.value = "";
      toDateInput.value = "";
    
    fetchcashclaim(); // Re-fetch with cleared filters
  }

}




// <!-- get today date -->


document.addEventListener("DOMContentLoaded", function () {
const today = new Date();
const options = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' };
const formattedDate = today.toLocaleDateString('en-GB', options);
document.getElementById('today-date').textContent = "" + formattedDate;
});


function formatDate(date_is) {
const given_date = new Date(date_is).toDateString().split(' ');
const formatted_date = `${given_date[2]}-${given_date[1]}-${given_date[3]}`;
//  console.log(formatted_date);
return formatted_date;
}
// DISPLAY TASK DETAILS ON CARD
function renderTasks(list) {
try{

const taskList = document.getElementById("card-list");
taskList.innerHTML = "";
if (list.length === 0) {
taskList.innerHTML = "<p class='text-sm text-gray-500'>No tasks found.</p>";
return;
}

ZOHO.CREATOR.UTIL.getQueryParams().then((response) => {
response = JSON.parse(response.login_details);
report_url = response.report_url;
// r_url = report_url + "Tasks/";
r_url = "/chaizup/chaizup-order-to-delivery/record-summary/Tasks/";


list.forEach((task) => {
const card = document.createElement("div");
card.className = "p-4 border rounded-lg shadow-sm bg-white";

const shouldShowButton = task.Task_Status !== "Resolved / Completed" && task.Task_Status !== "Not Completed";
view_btn_url = r_url + task.ID;
// let view_btn_url = "https://o2d.zohocreatorportal.in/chaizup/chaizup-order-to-delivery/record-summary/Tasks/" + task.ID;
// // open_url('${view_btn_url}')
// view_btn_url = "https://creatorapp.zoho.in/chaizup/environment/development/chaizup-order-to-delivery/record-summary/Tasks/" + task.ID;
card.innerHTML = `
<div class="flex justify-between mb-2">
  <span class="text-xs bg-blue-100 text-blue-600 px-2 py-1 rounded">${task.Task_Type}</span>
  <span class="text-xs ${getStatusColor(task.Task_Status)} px-2 py-1 rounded">${task.Task_Status}</span>
</div>
<div class="font-bold text-sm mb-1">${task.Task_Name}</div>
<div class="text-xs text-gray-700 mb-1">
  Completed : <span class="text-green-500">${task.Task_Closed_Timestamp}</span>
</div>
<div class="text-xs text-gray-500 mb-2">Due ${new Date(task.TAT).toDateString()}</div>

<div class="flex justify-between mb-2">
  <button id="viewtaskdetails" onclick="open_url('${view_btn_url}')"class="bg-gray-400 text-white px-2 py-1 rounded hover:bg-gray-700 flex items-center">
    <svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4" fill="none"
         viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
      <path stroke-linecap="round" stroke-linejoin="round"
            d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
      <path stroke-linecap="round" stroke-linejoin="round"
            d="M2.458 12C3.732 7.943 7.523 5 12 5c4.477 0 8.268 2.943 
            9.542 7-1.274 4.057-5.065 7-9.542 7-4.477 0-8.268-2.943-9.542-7z" />
    </svg>
  </button>

  ${shouldShowButton ? `
    <button rec_id="${task.ID}" onclick="OpenTaskModal('${task.ID}')" class="bg-red-300 text-white px-2 py-1 rounded hover:bg-red-700 text-xs">
      <svg rec_id="${task.ID}"  xmlns="http://www.w3.org/2000/svg" class="h-4 w-4" fill="none"
        viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
        <path stroke-linecap="round" stroke-linejoin="round"
          d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5M18.5 2.5l3 3L12 15l-4 1 1-4 9.5-9.5z" />
      </svg>
    </button>
  ` : ''}
</div>
`;

taskList.appendChild(card);
});
});

}
catch(e)
{
let error_message = e.message;
let error_reference = e.stack; 
let fn_name = "renderTasks";
let error_msg =`
        fnction: ${fn_name},
        error_message: ${error_message},
        error_reference: ${error_reference}`
}

}

// function to open company policy page,digital ID Card
function open_page_url(url_name,url_type)
{
let url_ = "";

ZOHO.CREATOR.UTIL.getQueryParams().then((response) => {
response = JSON.parse(response.login_details);
console.log(response);
let  page_url = response.page_base_url ;
let report_url = response.report_url;
let form_url = response.form_base_url;
// const url1 = page_url + page_name;
if(url_type =="Form")
  {
  //  url_ = form_url + url_name;
   url_ = "/chaizup/chaizup-order-to-delivery#Form:"+ url_name;
   console.log(url_);


  }
if(url_type=="Report")
{
  // url_ = report_url + url_name;
  url_ = "/chaizup/chaizup-order-to-delivery#Report:"+ url_name;
} 
if(url_type=="Page")
{
  // url_ = page_url + url_name;
  url_ = "/chaizup/chaizup-order-to-delivery#Page:"+ url_name;
}

config = {
    action :"open",
    url :url_,
    window :"new"
}
ZOHO.CREATOR.UTIL.navigateParentURL(config);

});

}

// function getTaskTypeCount(TaskType)
// {
//   switch(TaskType)
//   {




//   }
// }

// function for color of task status and claim type
function getStatusColor(status) {
switch (status) {
case "Created" ||"Approval Pending": return "bg-yellow-100 text-yellow-600";
case "Resolved / Completed": return "bg-green-100 text-green-600";
case "Overdue": return "bg-red-100 text-red-600";
case "Approve": return "bg-blue-100 text-blue-600";
case "Working on it": return "bg-yellow-100 text-yellow-600";
case "Reject": return "bg-red-100 text-red-600";
case "Approval Pending": return "bg-yellow-100 text-yellow-600";
default: return "bg-gray-100 text-gray-600";
}
} 
function count_of_pending_task()
{

  ZOHO.CREATOR.UTIL.getQueryParams().then((response) => {
response = JSON.parse(response.login_details);

let Employee_record_id = response.Employee_Rec_Id;


var config1 = 
{
app_name: "chaizup-order-to-delivery",
report_name: "Tasks",
criteria:`(Task_Owner == ${Employee_record_id} && Task_Status !="Resolved / Completed" && Task_Status!="Not Completed")`
}

ZOHO.CREATOR.DATA.getRecordCount(config1).then(function (response) {
// console.log(response.result.records_count);
let count_of_task =  response.result.records_count;
if(count_of_task>100)
{
document.getElementById("Count").innerText="100+";
// document.getElementById("taskCount1").innerText="100+";
}
else
{
document.getElementById("Count").innerText = "" + count_of_task;
// document.getElementById("taskCount1").innerText = "" + count_of_task;
}
});
});
}
function count_of_pending_cash_claim()
{

ZOHO.CREATOR.UTIL.getQueryParams().then((response) => {
response = JSON.parse(response.login_details);

let Employee_record_id = response.Employee_Rec_Id;


var config = {
app_name: "chaizup-order-to-delivery",
report_name: "All_Petty_Cash_Claims",
criteria:`(Request_Raised_By_Employee.Reporting_Manager == ${Employee_record_id} || Request_Raised_By_Employee == ${Employee_record_id} && Payment_Status!="Paid" && Approval!="Reject")`
// criteria:`(Request_Raised_By_Employee.Reporting_Manager == ${Employee_record_id} || Request_Raised_By_Employee == ${Employee_record_id})`
}; 


ZOHO.CREATOR.DATA.getRecordCount(config).then(function (response) {
// console.log(response.result.records_count);
let count_of_petty =  response.result.records_count;
if(count_of_petty>100)
{
document.getElementById("Count").innerText = "100+";
// document.getElementById("PettyCount1").innerText = "100+";

}
else
{
document.getElementById("Count").innerText = "" + count_of_petty;
// document.getElementById("PettyCount1").innerText = "" + count_of_petty;
}
});





});

}
function count_of_pending_help_ticket()
{
  ZOHO.CREATOR.UTIL.getQueryParams().then((response) => {
response = JSON.parse(response.login_details);

let Employee_record_id = response.Employee_Rec_Id;


  // count of pending help ticket
var help_ticket_count = {

  app_name: "chaizup-order-to-delivery",
  report_name: "Help_Ticket_Form_Database",
  criteria:`(Help_Ticket_Owner == ${Employee_record_id} && Rate_Ticket_Resolution == null && Generated_User_Task_ID.Task_Status != "Not Completed")`,

}


ZOHO.CREATOR.DATA.getRecordCount(help_ticket_count).then(function (response) {
  let count_of_help_tickets = response.result.records_count;
 
  if(count_of_help_tickets>100)
  {
    document.getElementById("Count").innerText = "100+";
   

  }
  else
  {
    document.getElementById("Count").innerText = "" + count_of_help_tickets;
    
  }
});
});

}
// display sales team activity
sales_team_data();
function sales_team_data()
{

ZOHO.CREATOR.UTIL.getQueryParams().then((response) => {

response =JSON.parse(response.login_details);

const activity_stream = response.activity_stream;
//  activity_stream = "Field";
let logged_mai_is = response.Mail;
const today = new Date();
let  todayFormatted = formatDate(today);
console.log(activity_stream);
console.log("query params",response);
// const  = today.toISOString().split('T')[0];
get_pending_order_count();
let current_activities = response.get_current_activity;
let active_beats = response.get_active_beat;
document.getElementById("current activities").textContent = current_activities;

document.getElementById("active_beats").textContent = active_beats;

const activityDiv = document.getElementById("activity-summary");
if (activity_stream =="Field") 
{
  activityDiv.style.display = "block";
} 
else
{
  activityDiv.style.display = "none";
}

// Change button text if current_activities is null or empty
const changeButton = document.getElementById("change-activity-button");
if (!current_activities || current_activities.trim() === "") {
  changeButton.textContent = "Select Activity";
} 
else {
  changeButton.textContent = "Change Activity";
}

});
}

// pending_task_count_task_type_wise();
// display pending task count in table
function pending_task_count_task_type_wise()
{
ZOHO.CREATOR.UTIL.getQueryParams().then((response) => {
response = JSON.parse(response.login_details);
const Employee_record_id = response.Employee_Rec_Id;


      // const currentDate = new Date();
      // const firstDayOfMonth = new Date(currentDate.getFullYear(), currentDate.getMonth(), 1);
      // const lastDayOfMonth = new Date(currentDate.getFullYear(), currentDate.getMonth() + 1, 0);

      // const fromDate = formatDate(firstDayOfMonth);
      // const toDate = formatDate(lastDayOfMonth);

var config = {
  app_name: "chaizup-order-to-delivery",
  report_name: "Tasks",
  criteria: `(Task_Owner == ${Employee_record_id} && Task_Status !="Resolved / Completed" && Task_Status!="Not Completed")`
};

ZOHO.CREATOR.DATA.getRecords(config).then(function (response) {
  const taskInfo = response.data;

  const taskTypeCounts = {
    "Help Ticket": 0,
    "Delegation (One Time)": 0,
    "Daily": 0,
    "Weekly": 0,
    "Monthly": 0,
    "Quarterly": 0,
    "Yearly": 0,
    "Fortnightly": 0
  };
  
  const todayDueCounts = {};
  const overdueCounts = {};
  
  // Initialize all types
  for (let type in taskTypeCounts) {
    todayDueCounts[type] = 0;
    overdueCounts[type] = 0;
  }
  
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  
  // Loop through tasks
  taskInfo.forEach((task) => {
    const taskType = task.Task_Type;
    const dueDateStr = task.TAT; 
  
    if (taskTypeCounts.hasOwnProperty(taskType)) {
      taskTypeCounts[taskType]++;
    }
  
    if (dueDateStr && taskTypeCounts.hasOwnProperty(taskType)) {
      const due = new Date(dueDateStr);
      due.setHours(0, 0, 0, 0);
  
      if (due.getTime() === today.getTime()) {
        todayDueCounts[taskType]++;
      } else if (due < today) {
        overdueCounts[taskType]++;
      }
    }
  });
  
  // Inject into table
  const tableBody = document.querySelector("#taskCountTable tbody");
  tableBody.innerHTML = ""; // Clear table
  
  // Create header if not already present
  const thead = document.querySelector("#taskCountTable thead");
  thead.innerHTML = `
    <tr>
      <th class="text-[9px]">Task Type</th>
      <th class="text-[9px]">Total Count</th>
      <th class="text-[9px]">Today's Due</th>
      <th class="text-[9px]">Overdue</th>
    </tr>
  `;
  
  // Add rows
  for (let type in taskTypeCounts) {
    const total = taskTypeCounts[type];
    const todayDue = todayDueCounts[type];
    const overdue = overdueCounts[type];
  
    const row = document.createElement("tr");
  
    row.innerHTML = `
      <td class="text-center py-2 text-[9px] px-4 border-b even:bg-gray-50 hover:bg-white">${type}</td>
      <td class="text-center py-2 text-[9px] px-4 border-b even:bg-gray-50 hover:bg-gray-100">${total}</td>
      <td class="text-center py-2 text-[9px] px-4 border-b even:bg-gray-50 hover:bg-white text-orange-500">${todayDue}</td>
      <td class="text-center py-2 text-[9px] px-4 border-b even:bg-gray-50 hover:bg-gray-100 text-red-500">${overdue}</td>
    `;
  
    tableBody.appendChild(row);
  }
});

});
}
// display pending_cash_claim_count in table
function pending_cash_claim_count()
{

ZOHO.CREATOR.UTIL.getQueryParams().then((response) => {
response = JSON.parse(response.login_details);
const Employee_record_id = response.Employee_Rec_Id;


      const currentDate = new Date();
      const firstDayOfMonth = new Date(currentDate.getFullYear(), currentDate.getMonth(), 1);
      const lastDayOfMonth = new Date(currentDate.getFullYear(), currentDate.getMonth() + 1, 0);

      const fromDate = formatDate(firstDayOfMonth);
      const toDate = formatDate(lastDayOfMonth);

var config = {
  app_name: "chaizup-order-to-delivery",
  report_name: "All_Petty_Cash_Claims",
  // criteria:`(Request_Raised_By_Employee.Reporting_Manager == ${Employee_record_id} || Request_Raised_By_Employee == ${Employee_record_id} && Payment_Status!="Paid" && Added_Time>= "${fromDate}" && Added_Time <= "${toDate}")`
  criteria:`(Request_Raised_By_Employee.Reporting_Manager == ${Employee_record_id} || Request_Raised_By_Employee == ${Employee_record_id} && Payment_Status!="Paid" && Approval !="Reject")`
};

ZOHO.CREATOR.DATA.getRecords(config).then(function (response) {
  
  const claiminfo = response.data;
  console.log(claiminfo);
  

  const claimTypeCounts = {
    "Advance Request": 0,
    "Expense Reimbursement": 0,
    "Advance Utilization": 0
  };

  const approvalPendingCounts = {
    "Advance Request": 0,
    "Expense Reimbursement": 0,
    "Advance Utilization": 0
  };
  
  const paymentPendingCounts = {
    "Advance Request": 0,
    "Expense Reimbursement": 0,
    "Advance Utilization": 0
  };

  const needsYourApprovalCounts = {
    "Advance Request": 0,
    "Expense Reimbursement": 0,
    "Advance Utilization": 0
  };
  
  
  
  
  // Loop through tasks
  claiminfo.forEach((claim) => {
    const claimType = claim.Claim;
    const ClaimStatus = claim.Approval;
    const PaymentStatus = claim.Payment_Status;
    const RaisedByManager = claim["Request_Raised_By_Employee.Reporting_Manager"];
    const RaisedByManagerId = RaisedByManager?.ID;
    console.log(RaisedByManagerId);
  
    if (claimTypeCounts.hasOwnProperty(claimType)) {
      claimTypeCounts[claimType]++;
  
      if (ClaimStatus === "Approval Pending") {
        approvalPendingCounts[claimType]++;
      }
  
      if (PaymentStatus === "Pending" || PaymentStatus === "Partial Payment") {
        paymentPendingCounts[claimType]++;
      }
  
      // ✅ Count Needs Your Approval if user is the manager
      if (ClaimStatus === "Approval Pending" && RaisedByManagerId === Employee_record_id) {
        needsYourApprovalCounts[claimType]++;
      }
    }
  });
  // Inject into table
  const tableBody = document.querySelector("#ClaimCountTable tbody");
  tableBody.innerHTML = ""; // Clear table
  
  // Create header if not already present
  const thead = document.querySelector("#ClaimCountTable thead");
  thead.innerHTML = `
  <tr>
<th class="bg-[#A0C878] text-[9px] border border-white" rowspan="2"> Claim Type</th>
<th colspan="2" class="text-center bg-[#A0C878] border border-white text-[9px]">Claim Raised By You</th>
<th colspan="2" class="text-center bg-[#A0C878] border border-white text-[9px]">Claim Raised By Your Team</th>

</tr>
<tr>


      <th class="py-2 sm:py-3 px-2 text-[9px] sm:px-4 text-left border-b border-l border-white">Approval Pending</th>
      <th class="py-2 sm:py-3 px-2 text-[9px] sm:px-4 text-left border-b border-l border-white">Payment Pending</th>
      <th class="py-2 sm:py-3 px-2 text-[9px] sm:px-4 text-left border-b border-l border-white">Needs Your Approval</th>
</tr>
  `;
  
 
  for (let type in claimTypeCounts) {
    const approvalPending = approvalPendingCounts[type];
    const paymentPending = paymentPendingCounts[type];
    const needsYourApproval = needsYourApprovalCounts[type];
  
    const row = document.createElement("tr");
  
    row.innerHTML = `
      <td class="text-center text-[9px] py-2 px-4 border-b even:bg-gray-50 hover:bg-white">${type}</td>
      <td class="text-center text-[9px] py-2 px-4 border-b even:bg-gray-50 hover:bg-gray-100">${approvalPending}</td>
      <td class="text-center text-[9px] py-2 px-4 border-b even:bg-gray-50 hover:bg-white text-red-500">${paymentPending}</td>
      <td class="text-center text-[9px] py-2 px-4 border-b even:bg-gray-50 hover:bg-gray-100">${needsYourApproval}</td>
    `;
  
    tableBody.appendChild(row);

   
    
  }
  
});

});

}

function pending_help_ticket_count()
{

  ZOHO.CREATOR.UTIL.getQueryParams().then((response) => {
    response = JSON.parse(response.login_details);
    const Employee_record_id = response.Employee_Rec_Id;
  
    var config = {
      app_name: "chaizup-order-to-delivery",
      report_name: "Help_Ticket_Form_Database",
      criteria: `(Help_Ticket_Owner == ${Employee_record_id})`
    };
  
    ZOHO.CREATOR.DATA.getRecords(config).then(function (response) {
      const ticketinfo = response.data;
  
      let createdCount = 0;
      let workingOnItCount = 0;
      let needsYourRatingCount = 0;
  
      ticketinfo.forEach(ticket => {
        const ticket_status = ticket["Generated_User_Task_ID.Task_Status"];
        const ticket_rating = ticket.Rate_Ticket_Resolution;

  
        if (ticket_status === "Created") {
          createdCount++;
        } else if (ticket_status === "Working on it") {
          workingOnItCount++;
        }
  
        if ((ticket_status === "Resolved / Completed") &&
            (!ticket_rating || ticket_rating.trim() === "")) {
          needsYourRatingCount++;
        }
      });
  
      const pendingCount = createdCount + workingOnItCount;
  
      const tableBody = document.querySelector("#HelpTicketCountTable tbody");
      tableBody.innerHTML = ""; // Clear table
  
      const thead = document.querySelector("#HelpTicketCountTable thead");
      thead.innerHTML = `
        <tr>
          <th class="text-[9px]">Pending Tickets</th>
          <th class="text-[9px]">Needs Your Rating</th>
        </tr>
      `;
  
      const row = document.createElement("tr");
      row.innerHTML = `
        <td class="text-center py-2 text-[9px] px-4 border-b even:bg-gray-50 hover:bg-white">${pendingCount}</td>
        <td class="text-center py-2 text-[9px] px-4 border-b even:bg-gray-50 hover:bg-gray-100">${needsYourRatingCount}</td>
      `;
      tableBody.appendChild(row);
      let count_of_help_tickets = pendingCount + needsYourRatingCount;
      document.getElementById("HelpTicketCount").innerText = "" + count_of_help_tickets;
      // document.getElementById("HelpTicketCount1").innerText = "" + count_of_help_tickets;
    });
  });
  




}

// FECTH TASK DATA  USING CRITTERIAL AND PASS INTO RENDERTASK FUNCTION

function fetchHelpTicketkData()
{

  ZOHO.CREATOR.UTIL.getQueryParams().then((response) => {
    response = JSON.parse(response.login_details);
    
    let Employee_record_id = response.Employee_Rec_Id;
    
    var config = {
    app_name: "chaizup-order-to-delivery",
    report_name: "Help_Ticket_Form_Database",
    // criteria:`(Help_Ticket_Owner == ${Employee_record_id} && Generated_User_Task_ID.Task_Status != "Resolved / Completed" || Rate_Ticket_Resolution == "" && Generated_User_Task_ID.Task_Status != "Not Completed")`,
    criteria:`(Help_Ticket_Owner == ${Employee_record_id} && Rate_Ticket_Resolution == null && Generated_User_Task_ID.Task_Status != "Not Completed")`,
    max_records:1000
    };

    ZOHO.CREATOR.DATA.getRecords(config).then(function (response) {
      //  console.log(response);
      
      if (response.code == 3000)
       {
        let res_data = response.data;
        console.log("help ticket data",res_data);
        renderHelpTicket(res_data);
        // console.log("petty cash data",res_data);
          // RenderCashClaim(res_data);
       }
     
      else 
      {
         console.log("No data found for help ticket");
        //  RenderCashClaim([]); // Render filtered tasks
      }
  }).catch(function(e){
      console.log("no data found for help ticket");
      console.log(e);
      renderHelpTicket([]);
    //  RenderCashClaim([]);
  });

});



}
function renderHelpTicket(list) 
{

  const help_ticket_list = document.getElementById("card-list");
  help_ticket_list.innerHTML = "";
  if (list.length === 0) {
    help_ticket_list.innerHTML = "<p class='text-sm text-gray-500'>No Help Ticket found.</p>";
    return;
  }

ZOHO.CREATOR.UTIL.getQueryParams().then((response) => {
response = JSON.parse(response.login_details);
let Employee_record_id = response.Employee_Rec_Id;
report_url = response.report_url;
// r_url = report_url + "Help_Ticket_Form_Database/";
// r_url = "https://yoddha.chaizup.in/chaizup/chaizup-order-to-delivery/record-summary/" + "Help_Ticket_Form_Database/";
r_url = "/chaizup/chaizup-order-to-delivery/record-summary/Help_Ticket_Form_Database/";


list.forEach((help_ticket) => {
const card = document.createElement("div");
card.className = "p-4 border rounded-lg shadow-sm bg-white";


view_btn_url = r_url + help_ticket.ID;
let ticket_status = help_ticket["Generated_User_Task_ID.Task_Status"];
let ticket_Closed_Timestamp = help_ticket["Generated_User_Task_ID.Task_Closed_Timestamp"];
let ticket_name = help_ticket["Ticket_Type.Ticket_Name"];
let due = help_ticket["Ticket_Type.TAT"];
let added_time = new Date(help_ticket["Added_Time"]);
added_time = added_time.toDateString()+" "+added_time.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
let responsible_person = help_ticket.Responsible_Person;
let rp = responsible_person.Name_With_ID;
const shouldShowButton = ticket_status == "Resolved / Completed" && help_ticket.Rate_Ticket_Resolution == "";
// console.log("show button",shouldShowButton);
// console.log("ticket test status",ticket_status);
// console.log("ticket_name",ticket_name);

// let view_btn_url = "https://o2d.zohocreatorportal.in/chaizup/chaizup-order-to-delivery/record-summary/Tasks/" + help_ticket.ID;
// // open_url('${view_btn_url}')
// view_btn_url = "https://creatorapp.zoho.in/chaizup/environment/development/chaizup-order-to-delivery/record-summary/Tasks/" + task.ID;
card.innerHTML = `
<div class="flex justify-end w-full">
  
  <span class="text-xs ${getStatusColor(ticket_status)} px-2 py-1 rounded">${ticket_status}</span>
</div>
<div class="font-bold text-sm mb-1">${ticket_name}</div>
<div class="text-xs text-gray-700 mb-1">
  Added Time: <span class="text-green-500">${added_time}</span>
</div>
<div class="text-xs text-gray-700 mb-2">Responsible Person:<span class="text-red-500">${rp}</span></div>

<div class="flex justify-between mb-2">
  <button onclick="open_url('${view_btn_url}','new')" class="bg-gray-400 text-white px-2 py-1 rounded hover:bg-gray-700 flex items-center">
    <svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4" fill="none"
         viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
      <path stroke-linecap="round" stroke-linejoin="round"
            d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
      <path stroke-linecap="round" stroke-linejoin="round"
            d="M2.458 12C3.732 7.943 7.523 5 12 5c4.477 0 8.268 2.943 
            9.542 7-1.274 4.057-5.065 7-9.542 7-4.477 0-8.268-2.943-9.542-7z" />
    </svg>
  </button>
  
  ${shouldShowButton ? `
    <button rec_id="${help_ticket.ID}" onclick="OpenHelpTicketModal('${help_ticket.ID}')" class="bg-yellow-300 text-white px-2 py-1 rounded hover:bg-red-700 text-xs">
  <svg rec_id="${help_ticket.ID}" xmlns="http://www.w3.org/2000/svg" class="h-4 w-4" fill="currentColor" viewBox="0 0 20 20">
    <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.286 3.965a1 1 0 00.95.69h4.173c.969 0 1.371 1.24.588 1.81l-3.378 2.455a1 1 0 00-.364 1.118l1.287 3.966c.3.921-.755 1.688-1.538 1.118l-3.378-2.454a1 1 0 00-1.175 0l-3.378 2.454c-.783.57-1.838-.197-1.538-1.118l1.287-3.966a1 1 0 00-.364-1.118L2.05 9.392c-.783-.57-.38-1.81.588-1.81h4.174a1 1 0 00.95-.69l1.287-3.965z"/>
  </svg>
</button>
  ` : ''}
</div>
`;

help_ticket_list.appendChild(card);

});
});

}

function filterhelpTicket()
{

  let Employee_record_id = "";
  ZOHO.CREATOR.UTIL.getQueryParams().then((response1) => {
    response1 = JSON.parse(response1.login_details);
    Employee_record_id = response1.Employee_Rec_Id;
   
    // console.log(Employee_record_id);
    

    const status = filterTicketStatus.value;
    let fromDate = filterTicketFrom.value;
    let toDate = filterTicketTo.value;
    
    let ticket_status_condition = status ? `Generated_User_Task_ID.Task_Status == "${status}" &&` : "";


    if (!fromDate || !toDate)
     {
      // console.log("No date selected, using current month");
      const currentDate = new Date();
      const firstDayOfMonth = new Date(currentDate.getFullYear(), currentDate.getMonth(), 1);
      const lastDayOfMonth = new Date(currentDate.getFullYear(), currentDate.getMonth() + 1, 0);

      fromDate = formatDate(firstDayOfMonth);
      toDate = formatDate(lastDayOfMonth);
     }
    else{
      // from = formatDate(from);
      // to = formatDate(to);

      // First, create Date objects
       let fromDateObj = new Date(fromDate);
       let toDateObj = new Date(toDate);

      // Add 1 day to "to" date
       toDateObj.setDate(toDateObj.getDate() + 1);

      // Now format both
       fromDate = formatDate(fromDateObj);
       toDate = formatDate(toDateObj);

    }
    

  

    var config = {
      app_name: "chaizup-order-to-delivery",
      report_name: "Help_Ticket_Form_Database",
      criteria: `(Help_Ticket_Owner == ${Employee_record_id} && ${ticket_status_condition} Added_Time >= "${fromDate}" && Added_Time < "${toDate}")`,
      max_records : 1000
    };
    console.log(config);

    ZOHO.CREATOR.DATA.getRecords(config).then(function (response) {
      if (response.code == 3000)
       {
        let res_data = response.data;
        let count = res_data.length;
        document.getElementById("Count").innerText = "" + count;  
        renderHelpTicket(res_data); 
      }
      else 
      {
      
        renderHelpTicket([]); 
      }
  }).catch(function(e){
    //  console.log(e);
    document.getElementById("Count").innerText = "0";
     renderHelpTicket([]);
  });
});
}

function OpenHelpTicketModal(ticket_id)
{




  ModalParent.classList.remove('hidden');


tid = ticket_id;
let config2 = {
app_name: "chaizup-order-to-delivery",
report_name: "Help_Ticket_Form_Database",
id: tid
};

ZOHO.CREATOR.DATA.getRecordById(config2).then(function (response) {
const ticket_data = response.data;

let ticket_description = ticket_data.Describe_the_Problem;
let rating = ticket_data.Rate_Ticket_Resolution;


let ticket_name = ticket_data["Ticket_Type.Ticket_Name"];
let ticket_status = ticket_data["Generated_User_Task_ID.Task_Status"];
let ticket_Closed_Timestamp = ticket_data["Generated_User_Task_ID.Task_Closed_Timestamp"];
let ticket_remarks = ticket_data["Generated_User_Task_ID.Task_Owner_Remarks"];
let rating_remarks = ticket_data.Rating_Remarks;
let responsible_person = ticket_data.Responsible_Person;
let rp = responsible_person.Name_With_ID;

let due = ticket_data["Ticket_Type.TAT"];
console.log("ticket status modal",ticket_status);
// safe fallback

// Create modal content
// const taskItem = document.createElement("div");
// taskItem.className = "modal bg-[#F1EFEC] p-4 rounded-lg w-80 relative";
let modal_ui_for_ticket_update= `
  <button onclick="CloseModal()" class="absolute top-2 right-2 text-gray-500 hover:text-black">&times;</button>

  <h2 id="pageHeading" class="text-lg font-semibold mb-2 w-full text-center">${ticket_name}</h2>
  <ul class="text-[9pt]">
    <li><strong>Ticket Description:</strong> ${ticket_description}</li>
    <li><strong>Responsible Person:</strong> ${rp}</li>
    <li><strong>Rating:</strong> ${rating}</li>
    <li><strong>TAT:</strong> Ticket will solve in ${due} days</li>
  </ul>

 <label for="ticket_remarks" class="block text-[12px] font-bold mb-1">Responsible Person Remarks:</label>
<textarea id="ticket_remarks"
    class="w-full p-2 text-[12px] rounded mb-2 border border-gray-400 focus:outline-none focus:border-blue-500"
    readonly>${ticket_remarks}</textarea>

  

  
<select id="rating" name="rating" class="w-full text-[12px] p-2 border rounded mb-4">
  <option value="" disabled selected hidden> Choose a rating </option>
  <!-- Ratings 1 to 10 -->
  <option value="1">1</option>
  <option value="2">2</option>
  <option value="3">3</option>
  <option value="4">4</option>
  <option value="5">5</option>
  <option value="6">6</option>
  <option value="7">7</option>
  <option value="8">8</option>
  <option value="9">9</option>
  <option value="10">10</option>
</select>


<textarea id="ticket_rating_remarks" placeholder="Enter your rating remarks here"
    class="w-full p-2 text-[12px] rounded mb-2 border border-gray-400 focus:outline-none focus:border-blue-500"
    >${rating_remarks}</textarea>


  <div class="flex justify-between items-center">
    <button onclick="CloseModal()" class="bg-gray-400 text-white text-[10pt] py-1 px-4 rounded-2xl">Cancel</button>
    <button onclick="UpdateTicket('${tid}')"
      class="submitBtn1 text-white text-[10pt] py-1 px-4 rounded-2xl">Update Ticket</button>
  </div>
`;

// Get modal container and insert new content
const modalContainer = document.getElementById("ModalChild");

modalContainer.innerHTML = modal_ui_for_ticket_update; // Clear existing content

});
}

function UpdateTicket(ticket_id)
{
   const rating_remarks = document.getElementById("ticket_rating_remarks").value.trim();
  
  const rating = document.getElementById("rating").value;

  if (!rating || !rating_remarks) {
    let alert_details = {
      btn_txt_color: "white",
      btn_bg: "#1888C4",
      alert_bg: "#F1EFEC",
      msg_txt: "Rating and Remarks are required.",
      msg_txt_color: "#FF8383"
    };
   const fname ="";
    showFancyAlert(alert_details,fname);
  } 
  else {
  
    let alert_details = {
      btn_txt_color: "white",
      btn_bg: "#1888C4",
      alert_bg: "#F1EFEC",
      msg_txt: "Data Updated Successfully.",
      msg_txt_color: "#A0C878"
    };
  
   
    let TicketRemarks = document.getElementById("ticket_rating_remarks").value;
    let TicketRating = document.getElementById("rating").value;
  
    let config = {
      app_name: "chaizup-order-to-delivery",
      report_name: "Help_Ticket_Form_Database",
      id: ticket_id,
      payload: {
        "data": {
            "Rating_Remarks":TicketRemarks,
           "Rate_Ticket_Resolution": TicketRating
        }
      }
    };
  
    // console.log(config);
  
    ZOHO.CREATOR.DATA.updateRecordById(config).then(function (response) {
       console.log(response);
      if (response.code == 3000) {
      
        showFancyAlert(alert_details,CloseModal);
         fetchHelpTicketkData();
         onload_initial_updates();
         count_of_pending_help_ticket();
        // filterTasks();
      }
    });  




}
}


function fetchTaskData()
{

try{
ZOHO.CREATOR.UTIL.getQueryParams().then((response) => {
response = JSON.parse(response.login_details);

const Employee_record_id = response.Employee_Rec_Id;

var config = {
app_name: "chaizup-order-to-delivery",
report_name: "Tasks",

criteria:`(Task_Owner == ${Employee_record_id} && Task_Status !="Resolved / Completed" && Task_Status!="Not Completed")`,
max_records:1000
};

ZOHO.CREATOR.DATA.getRecords(config).then(function (response) {
  try {
  let taskInfo = [];
  
  taskInfo = response.data;
  

  renderTasks(taskInfo); // ✅ Now we render
} catch (error) {
  console.error("An error occurred:", error);
}
}).catch(function(e){
    //  console.log(e);

     renderTasks([]);
  });
});
}
catch(e)
{
let error_message = e.message;
let error_reference = e.stack; 
let fn_name = "fetchTaskData";
let error_msg =`
        fnction: ${fn_name},
        error_message: ${error_message},
        error_reference: ${error_reference}`
}


}
//FILTER TASK 
function filterTasks()
{
try{
  // console.log("values of filtertask",status,type,fromDate,toDate);
  let Employee_record_id = "";
  ZOHO.CREATOR.UTIL.getQueryParams().then((response1) => {
    response1 = JSON.parse(response1.login_details);
    Employee_record_id = response1.Employee_Rec_Id;
    // console.log(Employee_record_id);

     status = filterStatus.value;
     type = filterType.value;
    let fromDate = filterFrom.value;
    let toDate = filterTo.value;
    let task_type_condition = type ? `Task_Type == "${type}" &&` : "";
    let task_status_condition = status ? `Task_Status == "${status}" &&` : "";
    
   
    
    

    if (!fromDate || !toDate)
     {
      // console.log("No date selected, using current month");
      const currentDate = new Date();
      const firstDayOfMonth = new Date(currentDate.getFullYear(), currentDate.getMonth(), 1);
      const lastDayOfMonth = new Date(currentDate.getFullYear(), currentDate.getMonth() + 1, 0);

      fromDate = formatDate(firstDayOfMonth);
      toDate = formatDate(lastDayOfMonth);
     }
    else{
      // from = formatDate(from);
      // to = formatDate(to);

      // First, create Date objects
       let fromDateObj = new Date(fromDate);
       let toDateObj = new Date(toDate);

      // Add 1 day to "to" date
       toDateObj.setDate(toDateObj.getDate() + 1);

      // Now format both
       fromDate = formatDate(fromDateObj);
       toDate = formatDate(toDateObj);
    
    }
    

  

    var config = {
      app_name: "chaizup-order-to-delivery",
      report_name: "Tasks",
      criteria: `(Task_Owner == ${Employee_record_id} && ${task_type_condition} ${task_status_condition} TAT >= "${fromDate}" && TAT < "${toDate}")`,
      max_records : 1000
    };
    // console.log(config);

    ZOHO.CREATOR.DATA.getRecords(config).then(function (response) {
      if (response.code == 3000)
       {
        let res_data = response.data;
        let count = res_data.length;
        document.getElementById("Count").innerText = "" + count;

        // console.log(res_data);
        renderTasks(res_data); // Render filtered tasks
      }
      else 
      {
        // console.log("No data found");
        renderTasks([]); // Render filtered tasks
      }
  }).catch(function(e){
    //  console.log(e);
    document.getElementById("Count").innerText = "0";
     renderTasks([]);
  });
});

}
catch(e)
{
let error_message = e.message;
let error_reference = e.stack; 
let fn_name = "filterTasks";
let error_msg =`
          fnction: ${fn_name},
          error_message: ${error_message},
          error_reference: ${error_reference}`
  // console.log(error_message);        
}
} 



// event listner for filter task
document.addEventListener("DOMContentLoaded", () => {
filterStatus = document.getElementById("filter-status");

filterType = document.getElementById("filter-type");
filterFrom = document.getElementById("filter-from");
filterTo = document.getElementById("filter-to");

[filterStatus, filterType, filterFrom, filterTo].forEach(input =>
input.addEventListener("change", filterTasks)
);


});
// event listner for filter claim cash form
document.addEventListener("DOMContentLoaded", () => {
filterClaimType = document.getElementById("filter-claim-type");
filterClaimCategory = document.getElementById("filter-claim-category");
filterPaymentStatus = document.getElementById("filter-payment-status");
filterFromClaim = document.getElementById("filter-from-claim");
filterToClaim = document.getElementById("filter-to-claim");

[filterClaimType, filterClaimCategory, filterPaymentStatus,filterFromClaim, filterToClaim].forEach(input =>
input.addEventListener("change", filterCashClaim)
);

});

// event listner for filter help ticket

document.addEventListener("DOMContentLoaded", () => {
  filterTicketStatus = document.getElementById("filter-ticket-status");
  
 
  filterTicketFrom = document.getElementById("filter-ticket-from");
  filterTicketTo = document.getElementById("filter-ticket-to");
  
  [filterTicketStatus,filterTicketFrom, filterTicketTo].forEach(input =>
  input.addEventListener("change", filterhelpTicket)
  );
  
  
  });

// function for add record in cash claim form
function AddClaim()
{
try{
  AddClaimModalParent.classList.remove('hidden');
   
   

let modal_ui_for_AddClaim_update= `
  <button onclick="CloseClaim()" class="absolute top-2 right-2 text-gray-500 hover:text-black">&times;</button>

  <h2 id="pageHeading" class="text-lg font-semibold mb-2 w-full text-center">Raised Claim</h2>
  <select id="filter-claim-type_addclaim" required class="w-[280px] p-2 border rounded text-gray-700">
      <option value="" disabled selected hidden>Claim Type</option>
      <!-- <option value="Advance Request">Advance Request</option> -->
      <option value="Expense Reimbursement">Expense Reimbursement</option>
     <!-- <option value="Advance Utilization">Advance Utilization</option> -->
      
    </select>
    <br><br>
    <select id="filter-claim-category_addclaim" required class="w-[280px] p-2 border rounded text-gray-700">
      <option value="" disabled selected hidden>Claim Category</option>
      <option value="Consumable">Consumable</option>
      <option value="Repairs & Maintenance">Repairs & Maintenance</option>
      <option value="Transportation/Courier">Transportation/Courier</option>
      <option value="Factory Tools & Utilities">Factory Tools & Utilities</option>
      <option value="Fuel">Fuel</option>
      <option value="Incentive">Incentive</option>
      <option value="Food Entertainment">Food Entertainment</option>  
      <option value="Transport/Courier">Transport/Courier</option>  
      <option value="Office/Recharge">Office/Recharge</option>
      <option value="Stationery">Stationery</option>
      <option value="Outstation Travel">Outstation Travel</option>
      <option value="Transport/Carpool">Transport/Carpool</option>
      <option value="Factory Overheads">Factory Overheads</option>
      <option value="IT Department">IT Department</option>
    </select>
   <br><br>
   
   <input type="number" id="claim_amount"  required placeholder="Claim Amount"
    class="w-[280px] p-2 text-[12px] rounded mb-2 border border-gray-400 focus:outline-none focus:border-blue-500">
    <br><br>
  <textarea id="remarks_add_claim" placeholder="Claim remarks"
    class="w-[280px] p-2 text-[12px] rounded mb-2 border border-gray-400 focus:outline-none focus:border-blue-500"></textarea>
  <br>
  <label for="myfile">Upload a File:</label>
  <input type="file" id="myfile" name="myfile">
  <br><br>
  <div class="flex justify-between items-center">
    <button onclick="CloseClaim()" class="bg-gray-400 text-white text-[10pt] py-1 px-4 rounded-2xl">Cancel</button>
    <button id="raiseClaimBtn" onclick="RaiseClaim()" class=" bg-[#A0C878] hover:bg-[#88b268] text-white text-[10pt] py-1 px-4 rounded-2xl">Raise Claim</button>
  </div>
`;

const modalContainer = document.getElementById("AddClaimModalChild");
modalContainer.innerHTML = modal_ui_for_AddClaim_update;
const raiseBtn = document.getElementById("raiseClaimBtn");
raiseBtn.disabled = false;
raiseBtn.classList.remove("opacity-50", "cursor-not-allowed");
}
catch(e)
{

  let error_message = e.message;
  let error_reference = e.stack; 
  let fn_name = "AddClaim";
  let error_msg =`
        function: ${fn_name},
        error_message: ${error_message},
        error_reference: ${error_reference}`
}
}

//call add records zoho api when user click on raise claim button
function RaiseClaim() {
try {
  const raiseBtn = document.getElementById("raiseClaimBtn");
  raiseBtn.disabled = true;
  raiseBtn.classList.add("opacity-50", "cursor-not-allowed");
  raiseBtn.classList.remove("hover:bg-[#88b268]");
// console.log(document.getElementById("AddClaimModalChild"));

const claim = document.getElementById("filter-claim-type_addclaim").value;
const category = document.getElementById("filter-claim-category_addclaim").value;
const amount = document.getElementById("claim_amount").value;
const claim_remarks = document.getElementById("remarks_add_claim").value;
let fileObject = document.getElementById("myfile").files[0];
const isAdvanceRequest = claim.toLowerCase() === "advance request";

if (!claim || !category || !amount || !claim_remarks || (!isAdvanceRequest && !fileObject)) {
  let alert_details = {
    btn_txt_color: "white",
    btn_bg: "#1888C4",
    alert_bg: "#F1EFEC",
    msg_txt: "All Fields Are Mandatory",
    msg_txt_color: "#FF8383"
  };
  showFancyAlert(alert_details, () => {});
} else {
  ZOHO.CREATOR.UTIL.getQueryParams().then((response) => {
    response = JSON.parse(response.login_details);
    const Employee_record_id = response.Employee_Rec_Id;
    const emp_mail = response.Mail;


    var config = {
      app_name: "chaizup-order-to-delivery",
      form_name: "Petty_Cash_Claim_Form",
      payload: {
        data: {
          "Claim": claim,
          "Category": category,
          "Amount": amount,
          "Claim_Remarks": claim_remarks,
          "Request_Raised_By_Employee": Employee_record_id,
          "Request_Raised_By": emp_mail
          // "File_upload": handled separately
        }
      }
    };

    ZOHO.CREATOR.DATA.addRecords(config).then(function (response) {
      if (response.code == 3000) {
        let alert_details = {
          btn_txt_color: "white",
          btn_bg: "#1888C4",
          alert_bg: "#F1EFEC",
          msg_txt: "Data Added Successfully.",
          msg_txt_color: "#A0C878"
        };

        let rec_data = response.data;
        let rec_id = rec_data.ID;

        if (fileObject) {
          var uploadConfig = {
            app_name: "chaizup-order-to-delivery",
            report_name: "All_Petty_Cash_Claims",
            id: rec_id,
            field_name: "File_upload",
            file: fileObject
          };

          ZOHO.CREATOR.FILE.uploadFile(uploadConfig).then(function (response) {
            showFancyAlert(alert_details, CloseClaim);
            onload_initial_updates();
            console.log("file uploaded", response);
          }).catch(function (e) {
            console.error("Unable to update file:", e);
            showFancyAlert(alert_details, CloseClaim);
            onload_initial_updates();
          });
        } else {
          // No file upload needed (Advance Request)
          showFancyAlert(alert_details, CloseClaim);
          onload_initial_updates();
        }
      }
    });
  });
}
} catch (e) {
let error_message = e.message;
let error_reference = e.stack;
let fn_name = "RaiseClaim";
let error_msg = `
        function: ${fn_name},
        error_message: ${error_message},
        error_reference: ${error_reference}`;
console.error(error_msg);
}
}

// function to close  cash claim modal
function CloseClaim()
{
document.getElementById("AddClaimModalChild").innerHTML = "";
AddClaimModalParent.classList.add('hidden');
}

// function for opening task modal when click on edit button

function OpenTaskModal(taskId) {
try{
// console.log("Modal open function called", taskId);
ModalParent.classList.remove('hidden');


tid = taskId;
let config2 = {
app_name: "chaizup-order-to-delivery",
report_name: "Tasks",
id: tid
};

ZOHO.CREATOR.DATA.getRecordById(config2).then(function (response) {
const taskdata = response.data;
const taskName = taskdata.Task_Name;
const Task_Owner_Remarks = taskdata.Task_Owner_Remarks || ""; // safe fallback

// Create modal content
// const taskItem = document.createElement("div");
// taskItem.className = "modal bg-[#F1EFEC] p-4 rounded-lg w-80 relative";
let modal_ui_for_task_update= `
  <button onclick="CloseModal()" class="absolute top-2 right-2 text-gray-500 hover:text-black">&times;</button>

  <h2 id="pageHeading" class="text-lg font-semibold mb-2 w-full text-center">${taskName}</h2>
  <ul class="text-[9pt]">
    <li><strong>Task Description:</strong> ${taskdata.Task_Description}</li>
    <li><strong>Task Type:</strong> ${taskdata.Task_Type}</li>
    <li><strong>TAT:</strong> ${taskdata.TAT}</li>
  </ul>

  <textarea id="remarks" placeholder="Enter remarks"
    class="w-full p-2 text-[12px] rounded mb-2 border border-gray-400 focus:outline-none focus:border-blue-500">${Task_Owner_Remarks}</textarea>

  <select id="dropdown" class="w-full text-[12px] p-2 border rounded mb-4">
    <option value="" disabled selected hidden>Task Status</option>
    <option value="Working on it">Working on it</option>
    <option value="Resolved / Completed">Resolved/Completed</option>
    <option value="Not Completed">Not Completed</option>
  </select>

  <div class="flex justify-between items-center">
    <button id="cancelBtn" onclick="CloseModal()" class="bg-gray-400 text-white text-[10pt] py-1 px-4 rounded-2xl">Cancel</button>
    <button id="submitBtn" onclick="UpdateTask('${tid}')"
      class="submitBtn1 text-white text-[10pt] py-1 px-4 rounded-2xl">Update Task</button>
  </div>
`;

// Get modal container and insert new content
const modalContainer = document.getElementById("ModalChild");

modalContainer.innerHTML = modal_ui_for_task_update; // Clear existing content

});
}
catch(e)
{
let error_message = e.message;
let error_reference = e.stack; 
let fn_name = "OpenTaskModal";
let error_msg =`
        fnction: ${fn_name},
        error_message: ${error_message},
        error_reference: ${error_reference}`
}
}


// function for update task status
function UpdateTask(TaskID) {
try{

const remarks = document.getElementById("remarks").value.trim();
const status = document.getElementById("dropdown").value;

if (!remarks || !status) {
  let alert_details = {
    btn_txt_color: "white",
    btn_bg: "#1888C4",
    alert_bg: "#F1EFEC",
    msg_txt: "Remarks and Task Status are required.",
    msg_txt_color: "#FF8383"
  };
 const fname ="";
  showFancyAlert(alert_details,fname);
} 
else {

  let alert_details = {
    btn_txt_color: "white",
    btn_bg: "#1888C4",
    alert_bg: "#F1EFEC",
    msg_txt: "Data Updated Successfully.",
    msg_txt_color: "#A0C878"
  };

  let TaskStatus = document.getElementById("dropdown").value;
  let TaskRemarks = document.getElementById("remarks").value;

  let config = {
    app_name: "chaizup-order-to-delivery",
    report_name: "Tasks",
    id: TaskID,
    payload: {
      "data": {
        "Task_Status": TaskStatus,
        "Task_Owner_Remarks": TaskRemarks
      }
    }
  };

  // console.log(config);

  ZOHO.CREATOR.DATA.updateRecordById(config).then(function (response) {
    // console.log(response);
    if (response.code == 3000) {
      // const fname = closeModal();
      showFancyAlert(alert_details,CloseModal);
       fetchTaskData();
       onload_initial_updates();
       count_of_pending_task();
      // filterTasks();
    }
  });  

} 
}
catch(e)
{
let error_message = e.message;
let error_reference = e.stack; 
let fn_name = "UpdateTask";
let error_msg =`
        fnction: ${fn_name},
        error_message: ${error_message},
        error_reference: ${error_reference}` 
}



}

// function for open modal for cash claim form

// function for closing task modal
function CloseModal() {
document.getElementById("ModalChild").innerHTML = "";
ModalParent.classList.add('hidden');
}
// function for close modal of cash claim form
function CloseCashClaimModal() {
document.getElementById("CashClaimModalChild").innerHTML = "";
CashClaimModalParent.classList.add('hidden');
}
// function for close modal of help ticket form
function CloseHelpTicketModal() {
  document.getElementById("HelpTicketModalChild").innerHTML = "";
  HelpTicketModalParent.classList.add('hidden'); 
}

// show alert box

function showFancyAlert(alert_details, fname) {
try {
const dialog_box = document.getElementById("fancyAlert");

let btn_txt_color = alert_details.btn_txt_color || "white";
let btn_bg = alert_details.btn_bg || "#1888C4";
let alert_bg = alert_details.alert_bg || "#F1EFEC";
let msg_txt = alert_details.msg_txt || "";
let msg_txt_color = alert_details.msg_txt_color || "black";

let warn_dlg_bx = `
  <div class="bg-[${alert_bg}] p-6 rounded-lg shadow-lg text-center max-w-md w-full mx-4">
    <h2 class="text-lg font-semibold text-red-600 mb-1"></h2>
    <p class="text-sm text-[${msg_txt_color}] mb-4">${msg_txt}</p>
    <button id="okBtn" class="bg-[${btn_bg}] text-white text-sm px-4 py-1 rounded">
      OK
    </button>
  </div>`;

dialog_box.innerHTML = warn_dlg_bx;
document.getElementById("fancyAlert").classList.remove("hidden");

// Now attach the onclick **after** HTML is set
const okButton = document.getElementById('okBtn');
okButton.onclick = function() {
  closeFancyAlert();
  if (typeof fname === 'function') {
    fname(); // call the passed function
  }
};
}


catch(e)
{
let error_message = e.message;
let error_reference = e.stack;
let fn_name = "showFancyAlert";
let error_msg =`
        fnction: ${fn_name},
        error_message: ${error_message},
        error_reference: ${error_reference}`
} 
}

// function to open url for viewing task details

function open_url(url_,window_type){
try{
//`https://o2d.zohocreatorportal.in/chaizup/chaizup-order-to-delivery/record-summary/Tasks/` + rec_id
config = {
    action : "open",
    url : url_,
    window : window_type || "new"
}
ZOHO.CREATOR.UTIL.navigateParentURL(config);
}

catch(e)
{
let error_message = e.message;
let error_reference = e.stack;
let fn_name = "open_url";
let error_msg =`
        fnction: ${fn_name},
        error_message: ${error_message},
        error_reference: ${error_reference}`
}
}

function closeFancyAlert() {
document.getElementById("fancyAlert").classList.add("hidden");
}

window.addEventListener("load", function () {
// fetchcashclaim();
onload_initial_updates();
displayduration();
}); 

//COUNT OF TASK,COUNT OF CASH CLAIM,LOG IN DETAILS
async function onload_initial_updates(){

  let getelement = document.getElementById("delivery-pending-box");

  try {
    queryParams = await ZOHO.CREATOR.UTIL.getQueryParams();
    response = JSON.parse(queryParams.login_details);
    Employee_record_id = response.Sales_Access;

  } catch (e) {
    console.error("Error in Aman:", e);
    return;
  }
console.log("Aman", Employee_record_id);

  if (Employee_record_id !== "Sales Teams") {
    getelement.style.display = "none";
  }

try{
/*.on
*update cout of task
*update coutn of petty cash
*log in detail with counter
*user name display
*/
//  jv v2 count function
ZOHO.CREATOR.UTIL.getQueryParams().then((response) => {
response = JSON.parse(response.login_details);

const Employee_record_id = response.Employee_Rec_Id;
document.getElementById("empname").textContent = ` ${response.Employee_Name}`;

var config = {
app_name: "chaizup-order-to-delivery",
report_name: "All_Petty_Cash_Claims",
criteria:`(Request_Raised_By_Employee.Reporting_Manager == ${Employee_record_id} || Request_Raised_By_Employee == ${Employee_record_id} && Payment_Status!="Paid" && Approval!="Reject")`
// criteria:`(Request_Raised_By_Employee.Reporting_Manager == ${Employee_record_id} || Request_Raised_By_Employee == ${Employee_record_id})`
}; 
// // raisedby==login user || raisedby.manager == log in user && payamet !== paid 
// // (for count )
ZOHO.CREATOR.DATA.getRecordCount(config).then(function (response) {
// console.log(response.result.records_count);
let count_of_petty =  response.result.records_count;
if(count_of_petty>100)
{
document.getElementById("PettyCount").innerText = "100+";
// document.getElementById("PettyCount1").innerText = "100+";

}
else
{
document.getElementById("PettyCount").innerText = "" + count_of_petty;
// document.getElementById("PettyCount1").innerText = "" + count_of_petty;
}
});

var config1 = {

app_name: "chaizup-order-to-delivery",
report_name: "Tasks",
criteria:`(Task_Owner == ${Employee_record_id} && Task_Status !="Resolved / Completed" && Task_Status!="Not Completed")`
// criteria:`(Task_Owner == ${Employee_record_id})`



}

ZOHO.CREATOR.DATA.getRecordCount(config1).then(function (response) {
// console.log(response.result.records_count);
let count_of_task =  response.result.records_count;
if(count_of_task>100)
{
document.getElementById("taskCount").innerText="100+";
// document.getElementById("taskCount1").innerText="100+";
}
else
{
document.getElementById("taskCount").innerText = "" + count_of_task;
// document.getElementById("taskCount1").innerText = "" + count_of_task;
}
});

// // count of pending help ticket
// var help_ticket_count = {

//   app_name: "chaizup-order-to-delivery",
//   report_name: "Help_Ticket_Form_Database",
//   criteria: `(Help_Ticket_Owner == ${Employee_record_id}  && Generated_User_Task_ID.Task_Status !="Resolved / Completed" && Generated_User_Task_ID.Task_Status!="Not Completed")`

// }


// ZOHO.CREATOR.DATA.getRecordCount(help_ticket_count).then(function (response) {
//   let count_of_help_tickets = response.result.records_count;
 
//   if(count_of_help_tickets>100)
//   {
//     document.getElementById("HelpTicketCount").innerText = "100+";
//     document.getElementById("HelpTicketCount1").innerText = "100+";

//   }
//   else
//   {
//     document.getElementById("HelpTicketCount").innerText = "" + count_of_help_tickets;
//     document.getElementById("HelpTicketCount1").innerText = "" + count_of_help_tickets;
//   }
// });
pending_help_ticket_count();

});

}
catch(e)
{

let error_message = e.message;
  let error_reference = e.stack; 
  let fn_name = "onload_initial_updates";
  let error_msg =`
          fnction: ${fn_name},
          error_message: ${error_message},
          error_reference: ${error_reference}`;
          console.log(error_msg);
          console.log(fn_name);

}
}

// Call the function on page load
// fetchcashclaim();
// fetchcashclaim();
// function to fetch cash claim data
function fetchcashclaim()
{
try{


ZOHO.CREATOR.UTIL.getQueryParams().then((response) => {
response = JSON.parse(response.login_details);

const Employee_record_id = response.Employee_Rec_Id;




      // const currentDate = new Date();
      // const firstDayOfMonth = new Date(currentDate.getFullYear(), currentDate.getMonth(), 1);
      // const lastDayOfMonth = new Date(currentDate.getFullYear(), currentDate.getMonth() + 1, 0);

      // const fromDate = formatDate(firstDayOfMonth);
      // const toDate = formatDate(lastDayOfMonth);
     

  var config = {
  app_name: "chaizup-order-to-delivery",
  report_name: "All_Petty_Cash_Claims",
  // criteria:`(Request_Raised_By_Employee.Reporting_Manager == ${Employee_record_id} || Request_Raised_By_Employee == ${Employee_record_id} && Payment_Status!="Paid" && Added_Time>= "${fromDate}" && Added_Time <= "${toDate}")`,
  criteria:`(Request_Raised_By_Employee.Reporting_Manager == ${Employee_record_id} || Request_Raised_By_Employee == ${Employee_record_id} && Payment_Status!="Paid" && Approval!="Reject")`,
  max_records:1000
};
// console.log("print config",config);
ZOHO.CREATOR.DATA.getRecords(config).then(function (response) {
  //  console.log(response);
    const petty_cash_info = response.data;
    // console.log("petty cash info",response);
     RenderCashClaim(petty_cash_info);
    //  const count_of_petty = petty_cash_info.length;
    //  document.getElementById("PettyCount").innerText = "" + count_of_petty;
    //  document.getElementById("PettyCount1").innerText = "" + count_of_petty;
}).catch(function(e){
    //  console.log(e);
    // document.getElementById("Count").innerText = "0";
     RenderCashClaim([]);
  });
});
}

catch (e) {
let error_message = e.message;
let error_reference = e.stack;
let fn_name = "fetchcashclaim";
let error_msg =`
        fnction: ${fn_name},
        error_message: ${error_message},
        error_reference: ${error_reference}`
      

}
}

// display cash claim data on card
function RenderCashClaim(petty_cash_info)
{
 


try{


    const CashClaimList = document.getElementById("card-list");
    CashClaimList.innerHTML = "";
    if (petty_cash_info.length === 0)
    {
      CashClaimList.innerHTML = "<p class='text-sm text-gray-500'>No cash claim found.</p>";
        return;
    }

    ZOHO.CREATOR.UTIL.getQueryParams().then((response) => {
response = JSON.parse(response.login_details);

let report_url = response.report_url;
// let r_url = report_url +"All_Petty_Cash_Claims/"
// let r_url = "https://yoddha.chaizup.in/chaizup/chaizup-order-to-delivery/record-summary/All_Petty_Cash_Claims/";
r_url = "/chaizup/chaizup-order-to-delivery/record-summary/All_Petty_Cash_Claims/";

let  Employee_record_id = response.Employee_Rec_Id;


    petty_cash_info.forEach((petty) => {
     
      // let claim_view_btn_url = "https://o2d.zohocreatorportal.in/chaizup/chaizup-order-to-delivery/record-summary/All_Petty_Cash_Claims/" + petty.ID;
// open_url('${view_btn_url}')
    //  claim_view_btn_url = "https://creatorapp.zoho.in/chaizup/environment/development/chaizup-order-to-delivery/record-summary/All_Petty_Cash_Claims/" + petty.ID;
      claim_view_btn_url = r_url + petty.ID;
      const card = document.createElement("div");
      card.className = "p-4 border rounded-lg shadow-sm bg-white";
      const reporting_manager = petty["Request_Raised_By_Employee.Reporting_Manager"];
      const shouldShowButton = petty.Approval !== "Approve" && petty.Approval !== "Reject" && reporting_manager?.ID == Employee_record_id;
      // const shouldshowtotalamount =petty.Total_Paid_Amount!==0;
      const request_raised_by = petty["Request_Raised_By_Employee"];
     let raised_by_name = request_raised_by.Name_With_ID;
      console.log("request_raised",raised_by_name);
      const Approval = petty.Approval;
      const claim_type = petty.Claim;
      const claim_category = petty.Category;
      const payment_status = petty.Payment_Status;
      const total_paid_amount = petty.Total_Paid_Amount;
      const last_payment_date = petty.Last_Payment_Date;
      const amount = petty.Amount;
      card.innerHTML = `    
 
<div class="flex justify-between mb-2">
<span class="text-xs ${getStatusColor(Approval)} px-2 py-1 rounded">${Approval}</span>

<span class="text-xs ${getStatusColor(payment_status)} bg-yellow-100 text-yellow-600 px-2 py-1 rounded">${payment_status}</span>
</div>

<div class="font-bold text-sm mb-1">${claim_type} - ${claim_category}</div>
<div class="text-xs text-gray-700 mb-1">Request Raised By: ${raised_by_name} </div>

<div class="text-xs text-gray-700 mb-1">
Total Paid Amount :
${total_paid_amount ? `
<span class="text-green-500">&#8377; ${total_paid_amount}</span>
<span class="text-blue-500">/ ${last_payment_date}</span>
` : `<span class="text-gray-400"></span>`}
</div>

<div class="text-black text-sm mb-8"> Cash Claim Amount : &#8377; ${amount}</div> 
<div class="flex justify-between items-center mb-2 relative">


<button id="viewtaskdetails" onclick="open_url('${claim_view_btn_url}')"class="bg-gray-400 text-white px-2 py-1 rounded hover:bg-gray-700 flex items-center">
<svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4" fill="none"
     viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
  <path stroke-linecap="round" stroke-linejoin="round"
        d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
  <path stroke-linecap="round" stroke-linejoin="round"
        d="M2.458 12C3.732 7.943 7.523 5 12 5c4.477 0 8.268 2.943 
        9.542 7-1.274 4.057-5.065 7-9.542 7-4.477 0-8.268-2.943-9.542-7z" />
</svg>
</button>

<!-- Update Approval Button (Right) -->
${shouldShowButton ? `
<button rec_id=${petty.ID} id="updateApproval" onclick="OpenCashClaimModal('${petty.ID}');"
  class="bg-[#1888C4] text-white text-xs px-3 py-1 rounded hover:bg-blue-700">
  Update Approval
</button>
` : ''}

</div>

`;
CashClaimList.appendChild(card);
}); 

});
} 
 catch(e)
{
  let error_message = e.message;
  let error_reference = e.stack; 
  let fn_name = "RenderCashClaim";
  let error_msg =`
          fnction: ${fn_name},
          error_message: ${error_message},
          error_reference: ${error_reference}`;
          // console.log(error_msg);
          // console.log(fn_name);

}    

} 

// filterCashClaim();
// filter cash claim data 
function filterCashClaim()
{
try{

ZOHO.CREATOR.UTIL.getQueryParams().then((response) => {
response = JSON.parse(response.login_details);
// console.log(response);
const Employee_record_id = response.Employee_Rec_Id;

 
 

    const type = filterClaimType.value;
    const category = filterClaimCategory.value;
    const payment_status = filterPaymentStatus.value;
    let fromDate = filterFromClaim.value;
    let toDate = filterToClaim.value;
    // console.log(type, category, from, to);
    let claim_type_condition = type ? `Claim == "${type}" &&` : "";

    let claim_category_condition = category ? `Category == "${category}" &&` : "";

    let payment_status_condition = payment_status ? `Payment_Status == "${payment_status}" &&`: "";
    if (!fromDate || !toDate)
     {
      // console.log("No date selected, using current month petty cash");
      const currentDate = new Date();
      const firstDayOfMonth = new Date(currentDate.getFullYear(), currentDate.getMonth(), 1);
      const lastDayOfMonth = new Date(currentDate.getFullYear(), currentDate.getMonth() + 1, 0);

      fromDate = formatDate(firstDayOfMonth);
      toDate = formatDate(lastDayOfMonth);
     }
    else{
      // from = formatDate(from);
      // to = formatDate(to);



      let fromDateObj = new Date(fromDate);
      let toDateObj = new Date(toDate);

     // Add 1 day to "to" date
      toDateObj.setDate(toDateObj.getDate() + 1);

     // Now format both
      fromDate = formatDate(fromDateObj);
      toDate = formatDate(toDateObj);
    }
  

    var config = {
      app_name: "chaizup-order-to-delivery",
      report_name: "All_Petty_Cash_Claims",
      criteria: `(Request_Raised_By_Employee.Reporting_Manager == ${Employee_record_id} || Request_Raised_By_Employee == ${Employee_record_id} && ${claim_type_condition} ${claim_category_condition} ${payment_status_condition} Added_Time>= "${fromDate}" && Added_Time < "${toDate}")`,
      max_records : 1000
      
    };
    // console.log("check",config);
   
   
    ZOHO.CREATOR.DATA.getRecords(config).then(function (response) {
      // console.log("petty cash data",response);
      
      if (response.code == 3000)
       {
        let res_data = response.data;
        // console.log("petty cash data",res_data);
        let count = res_data.length;
          document.getElementById("Count").innerText = "" + count;
          RenderCashClaim(res_data);
       }
     
      else 
      {
         console.log("No data found for petty cash");
         RenderCashClaim([]); // Render filtered tasks
      }
  }).catch(function(e){
    //  console.log(e);
    document.getElementById("Count").innerText = "0";
     RenderCashClaim([]);
  });

});


}
catch(e)
{
let error_message = e.message;
let error_reference = e.stack; 
let fn_name = "filterCashClaim";
let error_msg =`
          fnction: ${fn_name},
          error_message: ${error_message},
          error_reference: ${error_reference}`;
          
}
}







//       ##       ##       ######  ##       ########    ###    ########       ######## #### ##       ######## ######## ########       ########  #######  ########       ########    ###     ######  ##     ## 
//      ##       ##       ##    ## ##       ##         ## ##   ##     ##      ##        ##  ##          ##    ##       ##     ##      ##       ##     ## ##     ##         ##      ## ##   ##    ## ##    ##  
//     ##       ##        ##       ##       ##        ##   ##  ##     ##      ##        ##  ##          ##    ##       ##     ##      ##       ##     ## ##     ##         ##     ##   ##  ##       ##   ##   
//    ##       ##         ##       ##       ######   ##     ## ########       ######    ##  ##          ##    ######   ########       ######   ##     ## ########          ##    ##     ##  ######  #####     
//   ##       ##          ##       ##       ##       ######### ##   ##        ##        ##  ##          ##    ##       ##   ##        ##       ##     ## ##   ##           ##    #########       ## ##   ##   
//  ##       ##           ##    ## ##       ##       ##     ## ##    ##       ##        ##  ##          ##    ##       ##    ##       ##       ##     ## ##    ##          ##    ##     ## ##    ## ##    ##  
// ##       ##             ######  ######## ######## ##     ## ##     ##      ##       #### ########    ##    ######## ##     ##      ##        #######  ##     ##         ##    ##     ##  ######  ##     ## 

// document.getElementById('clear-filters').addEventListener('click', () => {
// // Reset all filter fields
// document.getElementById('filter-status').value = '';
// document.getElementById('filter-type').value = '';
// document.getElementById('filter-from').value = '';
// document.getElementById('filter-to').value = '';

// // Re-run filter logic to show all or current month tasks
// // filterTasks();
// fetchTaskData();
// });
// // CLEAR FILTER FOR CASH CLAIM
// document.getElementById('clear-filters-petty').addEventListener('click', () => {
// // Reset all filter fields
// document.getElementById('filter-claim-type').value = '';
// document.getElementById('filter-claim-category').value = '';
// document.getElementById('filter-from-claim').value = '';
// document.getElementById('filter-to-claim').value = '';
// document.getElementById('filter-payment-status').value = '';
// //  Re-run filter logic to show all or current month tasks
// // filterCashClaim();
// fetchcashclaim();
// });
// // clear filter for help ticket
// document.getElementById('clear-filters-ticket').addEventListener('click', () => {
//   // Reset all filter fields
//   document.getElementById('filter-ticket-status').value = '';
  
//   document.getElementById('filter-ticket-from').value = '';
//   document.getElementById('filter-ticket-to').value = '';
  
//   // Re-run filter logic to show all or current month tasks
//   // filterTasks();
//   fetchHelpTicketkData();
//   });







    // Get references to the slider elements
    // const sliderContent = document.getElementById('slider-content');
    // const sliderArrowControl = document.getElementById('slider-arrow-control');
    // const sliderIndicatorIcon = document.getElementById('slider-indicator-icon');

    // URLs for the icons
    // const iconUpUrl = 'https://cdn.jsdelivr.net/npm/lucide-static@latest/icons/chevron-up.svg';
    // const iconDownUrl = 'https://cdn.jsdelivr.net/npm/lucide-static@latest/icons/chevron-down.svg';

    // // Check if required elements exist
    // if (sliderContent && sliderArrowControl && sliderIndicatorIcon) {

    //     // Add an event listener to the ARROW CONTAINER DIV for click events
    //     sliderArrowControl.addEventListener('click', function() {
    //         // Toggle the visibility classes on the slider content
    //         sliderContent.classList.toggle('slider-hidden'); // Toggle peek state
    //         sliderContent.classList.toggle('slider-visible'); // Toggle open state

    //         // Change slider indicator icon based on state
    //         if (sliderContent.classList.contains('slider-visible')) {
    //             // State: Slider is now visible (open)
    //             sliderIndicatorIcon.src = iconDownUrl; // Panel shows down arrow
    //             sliderIndicatorIcon.alt = 'Slider is visible indicator (click to hide)';

    //         } else {
    //             // State: Slider is now hidden (peeking)
    //             sliderIndicatorIcon.src = iconUpUrl; // Panel shows up arrow
    //             sliderIndicatorIcon.alt = 'Slider is hidden indicator (click to show)';
    //         }
    //     });
//     } else {
//         // Log an error if elements aren't found
//         console.error("Required slider elements (content, arrow control, or indicator icon) not found!");
//     }

    
//



    
    // Get references to the slider elements
    // const sliderContent = document.getElementById('slider-content');
    // const sliderArrowControl = document.getElementById('slider-arrow-control');
    // const sliderIndicatorIcon = document.getElementById('slider-indicator-icon');

    // const iconUpUrl = 'https://cdn.jsdelivr.net/npm/lucide-static@latest/icons/chevron-up.svg';
    // const iconDownUrl = 'https://cdn.jsdelivr.net/npm/lucide-static@latest/icons/chevron-down.svg';

    // // Function to initialize slider state based on screen width
    // function initializeSliderState() {
    //     const isMobile = window.matchMedia("(max-width: 767px)").matches;

    //     if (isMobile) {
    //         // On mobile, show slider in peek state
    //         sliderContent.classList.add('slider-hidden');
    //         sliderContent.classList.remove('slider-visible');
            
    //         sliderIndicatorIcon.src = iconUpUrl;
    //     } else {
    //         // On desktop, completely hide slider
    //         sliderContent.style.display = 'none';
    //     }
    // }

    // // Toggle visibility on arrow click
    // if (sliderContent && sliderArrowControl && sliderIndicatorIcon) {
    //     sliderArrowControl.addEventListener('click', function () {
    //         // Ensure it's displayed before toggling
    //         sliderContent.style.display = 'block';

    //         sliderContent.classList.toggle('slider-hidden');
    //         sliderContent.classList.toggle('slider-visible');

    //         if (sliderContent.classList.contains('slider-visible')) {
    //             sliderIndicatorIcon.src = iconDownUrl;
    //             sliderIndicatorIcon.alt = 'Slider is visible indicator (click to hide)';
    //         } else {
    //             sliderIndicatorIcon.src = iconUpUrl;
    //             sliderIndicatorIcon.alt = 'Slider is hidden indicator (click to show)';
    //         }
    //     });
    // }

    // // Run on load
    // window.addEventListener('DOMContentLoaded', initializeSliderState);
  
    // // console.log("executing");

   





// function to open url to edit record of check in check out form
//log in
function open_checkIn_CheckOut_url(type){
try{
let Type = type;


ZOHO.CREATOR.UTIL.getQueryParams().then((response) => {
response = JSON.parse(response.login_details);
// console.log(response);
let employee_id = response.Employee_Rec_Id;
let userMailId = response.Mail;
let entry_rec_id = response.entry_rec_id;
let formurl = response.form_base_url;
let editurl = response.edit_url;
if(Type == "LOG IN")
{
  // formurl = formurl + "Check_In_Out_Form";
  formurl = "/chaizup/chaizup-order-to-delivery#Form:Check_In_Out_Form";

}
if(Type == "Form")
  {
    // formurl = formurl + "Help_Ticket_Form";
    formurl = "/chaizup/chaizup-order-to-delivery#Form:Help_Ticket_Form";
    
  
  }
if(Type == "LOG OUT")
{
  //  formurl = editurl + "Check_In_Out_Form/record-edit/Check_In_Out_Form_Report/"+entry_rec_id;
  formurl = "/chaizup/chaizup-order-to-delivery/Check_In_Out_Form/record-edit/Check_In_Out_Form_Report/"+entry_rec_id;
 

}
if(Type == "DAY END")
{ 
  // formurl = formurl + "Log_In_Form?Log_Type=Log+Out";
  formurl = "/chaizup/chaizup-order-to-delivery#Form:Log_In_Form?Log_Type=Log+Out";
  // formurl = formurl + "Log_In_Form/record-edit/Log_In_Form_Report/"+entry_rec_id;
  // https://o2d.zohocreatorportal.in/#Form:Log_In_Form?Log_Type=Log+Out

}



open_url(formurl, "same");

});
}
catch(e)
{
let error_message = e.message;
let error_reference = e.stack;
let fn_name = "open_checkIn_CheckOut_url";
let error_msg =`
          fnction: ${fn_name},
          error_message: ${error_message},
          error_reference: ${error_reference}`
}
}


//OPEN REPORT USING URL
function open_report(report_name)
{
ZOHO.CREATOR.UTIL.getQueryParams().then((response) => {
response = JSON.parse(response.login_details);
record_url = response.record_url;
r_url = record_url + report_name;
r_url = "/chaizup/chaizup-order-to-delivery#Report:" + report_name;
open_url(r_url,"new");

});
}
// display duration for log in log out 
// displayduration();

function displayduration() {
try {
ZOHO.CREATOR.UTIL.getQueryParams().then((response) => {
  response = JSON.parse(response.login_details);

  let employee_id = response.Employee_Rec_Id;
  let userMailId = response.Mail;
  let formurl = response.form_base_url + "Check_In_Out_Form";
  let is_logged_out_today = response.is_logged_out_today;
  let is_logged_today = response.is_logged_today;
  let last_logged_in = response.last_logged_in ? new Date(response.last_logged_in) : null;
  let last_logged_out = response.last_logged_out ? new Date(response.last_logged_out) : null;
  let working_hours = response.working_hours;
  let attendance = response.attendance;
  let activity_stream = response.activity_stream;
  
  // console.log(last_logged_in);
  // console.log(last_logged_out);
  // activity_stream = "Field"; // You may want to remove or replace this if already coming from response

  // 👇 New logic to show dayend and hide others if activity stream is Field
  if (activity_stream === "Field") {
    loginBtn.style.display = "none";
    logoutBtn.style.display = "none";
    DaysEnd.style.display = "block";
    DisplayDurationForField();
    return; // Exit further processing
  }
  else{
    DaysEnd.style.display="none";
  }


  // Assume these are provided
// last_logged_in: timestamp or null
// last_logged_out: timestamp or null
// is_logged_today: true if login today
// is_logged_out_today: true if logout also done today

if (!last_logged_in && !last_logged_out) {
    // No login/logout history - allow login
    loginBtn.style.display = "block";
    logoutBtn.style.display = "none";
    clockDisplay.textContent = "00:00:00";
    return;
}

if (is_logged_today) {
    loginBtn.style.display = "none";

    if (is_logged_out_today) {
        // Already logged in and out today - show duration only
        let duration = last_logged_out - last_logged_in;
        let result = formatDuration(duration);
        clockDisplay.textContent = result.formatted;
        logoutBtn.style.display = "none";
    } else {
        // Logged in but not logged out yet - show live duration and logout option
        startLiveDuration(last_logged_in);
        logoutBtn.style.display = "block";
    }
} else {
    // Login/logout done on previous day - show duration only
    if(last_logged_out == null || last_logged_out == "")
    {
       const now = new Date();
       last_logged_out = now;

    }
   
    logoutBtn.style.display = "none";
    loginBtn.style.display = "block"; // You may allow re-login here
    let duration = last_logged_out - last_logged_in;
    let result = formatDuration(duration);
    console.log("Result",result);
    clockDisplay.textContent = result.formatted;
}


  // Force show logout if no working hours and no attendance
  // if ((!working_hours || working_hours.trim() === "") && (!attendance || attendance.trim() === "")) {
  //   logoutBtn.style.display = "block";
  // }

});
} catch (e) {
let error_message = e.message;
let error_reference = e.stack;
let fn_name = "displayduration";
let error_msg = `
  function: ${fn_name},
  error_message: ${error_message},
  error_reference: ${error_reference}`;
// console.error(error_msg);
}
}


let durationInterval = null;

function startLiveDuration(startTime) {
if (durationInterval) clearInterval(durationInterval);

durationInterval = setInterval(() => {
const now = new Date();
const duration = now - startTime;
const result = formatDuration(duration);
clockDisplay.textContent = result.formatted;
}, 1000); // updates every second
}


function formatDuration(ms) {
const totalSeconds = Math.floor(ms / 1000);
const hours = Math.floor(totalSeconds / 3600);
const minutes = Math.floor((totalSeconds % 3600) / 60);
const seconds = totalSeconds % 60;

return {
formatted: `${pad(hours)}:${pad(minutes)}:${pad(seconds)}`
};
}

function pad(num) {
return num.toString().padStart(2, '0');
}
// this function will display duration for field activity stream
function DisplayDurationForField()
{

ZOHO.CREATOR.UTIL.getQueryParams().then((response) => {
response = JSON.parse(response.login_details);


let is_logged_out_today = response.is_logged_out_today;
let is_logged_today = response.is_logged_today;
let last_logged_in = new Date(response.last_logged_in);
let last_logged_out = new Date(response.last_logged_out);

let working_hours = response.working_hours;
let attendance = response.attendance;
// console.log("last_logged_in_field",last_logged_in);
// console.log("last_logged_out_field",last_logged_out);
// let activity_stream = response.activity_stream;
// activity_stream = "Field"; // You may want to remove or replace this if already coming from response


if (is_logged_today) {

if (is_logged_out_today) {
  let duration = last_logged_out - last_logged_in;
  let result = formatDuration(duration);
  clockDisplay.textContent = result.formatted;
  DaysEnd.style.display = "none";
  
} 
else 
{
  startLiveDuration(last_logged_in);
}
} 
else {
// hide day end button if not logged in

DaysEnd.style.display = "none";

let duration = last_logged_out - last_logged_in;
let result = formatDuration(duration);
clockDisplay.textContent = result.formatted;
}

// if ((!working_hours || working_hours.trim() === "") && (!attendance || attendance.trim() === "")) {
//   DaysEnd.style.display = "block";
// }

});

}



// function to Open Modal of  Cash Claim Form when click on update approval button on card
// this function will display cash claim data using id parameter
function OpenCashClaimModal(pid)
{


try{
// console.log("Modal open function called", pid);
ModalParent.classList.remove('hidden');

petty_ID = pid;
let config2 = {
app_name: "chaizup-order-to-delivery",
report_name: "All_Petty_Cash_Claims",
id: petty_ID
};

ZOHO.CREATOR.DATA.getRecordById(config2).then(function (response) {

const pettydata = response.data;
// console.log(pettydata);
const petty_type = pettydata.Claim;
const cash_claim_id = pettydata.ID;
const claim_category =pettydata.Category;
const claim_Remarks = pettydata.Claim_Remarks; // Claim_Remarks
const claim_amount = pettydata.Amount;
const added_by =  pettydata.Request_Raised_By_Employee.Name_With_ID;
let claim_date = new Date(pettydata.Added_Time);
 claim_date = claim_date.toDateString() +" , "+ claim_date.toLocaleTimeString();

// Create modal content
// const taskItem = document.createElement("div");
// taskItem.className = "modal bg-[#F1EFEC] p-4 rounded-lg w-80 relative";
let modal_ui_for_petty_update= `
  <button onclick="CloseModal()" class="absolute top-2 right-2 text-gray-500 hover:text-black">&times;</button>

  <h2 id="pageHeading" class="text-lg font-semibold mb-2 w-full text-center">${petty_type}</h2>
  <h3 class="text-[9pt] w-full text-center">${claim_category}</h3>
  <ul class="text-[9pt]">
    <li><strong>ID:</strong>${cash_claim_id}</li>
   <ul class="text-[9pt]">

<li>
<strong>Claim Remarks:</strong><br>
<textarea readonly class="w-full border border-gray-400 p-2 resize-y min-h-[60px]">${claim_Remarks}</textarea>
</li>
<li><strong>Claim Amount:</strong> ${claim_amount}</li>
<li><strong>Claim Date:</strong> ${claim_date}</li>
<li><strong>Added By:</strong> ${added_by}</li>
</ul>

    

  <textarea id="remarks_petty" placeholder="Enter Approval remarks"
    class="w-full p-2 text-[12px] rounded mb-2 border border-gray-400 focus:outline-none focus:border-blue-500"></textarea>

  <select id="dropdown_petty" class="w-full text-[12px] p-2 border rounded mb-4">
    <option value="" disabled selected hidden>Approve Status</option>
    <option value="Approve">Approve</option>
    <option value="Reject">Reject</option>
    
  </select>

  <div class="flex justify-between items-center">
    <button onclick="CloseModal()" class="bg-gray-400 text-white text-[10pt] py-1 px-4 rounded-2xl">Cancel</button>
    <button onclick="UpdateClaim('${petty_ID}')" class="bg-[#A0C878] text-white text-[10pt] py-1 px-4 rounded-2xl">Update Claim</button>
  </div>
`;

// Get modal container and insert new content
const modalContainer = document.getElementById("ModalChild");
modalContainer.innerHTML = modal_ui_for_petty_update; // Clear existing content

});
}
catch(e)
{
let error_message = e.message;
let error_reference = e.stack; 
let fn_name = "OpenCashClaimModal";
let error_msg =`
        fnction: ${fn_name},
        error_message: ${error_message},
        error_reference: ${error_reference}`
}

}


// function to Update Cash Claim Data through modal by manager
// when user click on update approval button it will update remarks and approval status of cash claim
function UpdateClaim(petty_id)
{


try{

const  petty_ID = petty_id;

const remarks = document.getElementById("remarks_petty").value.trim();
const status = document.getElementById("dropdown_petty").value;

if (!remarks || !status) {
let alert_details = {
  btn_txt_color: "white",
  btn_bg: "#1888C4",
  alert_bg: "#F1EFEC",
  msg_txt: "Remarks and Approval are required.",
  msg_txt_color: "#FF8383"
};
const fname = "";
showFancyAlert(alert_details,fname);
} 
else {

let alert_details = {
  btn_txt_color: "white",
  btn_bg: "#1888C4",
  alert_bg: "#F1EFEC",
  msg_txt: "Data Updated Successfully.",
  msg_txt_color: "#A0C878"
};

let Status = document.getElementById("dropdown_petty").value;
let Remarks = document.getElementById("remarks_petty").value;


ZOHO.CREATOR.UTIL.getQueryParams().then((response) => {
response = JSON.parse(response.login_details);
// console.log(response);
let employee_id = response.Employee_Rec_Id;





let config = {
  app_name: "chaizup-order-to-delivery",
  report_name: "All_Petty_Cash_Claims",
  id: petty_ID,
  payload: {
    "data": {
      "Approval": Status,
      "Approval_Remarks": Remarks,
      "Request_Approved_By_Employee":employee_id
    }
  }
};

// console.log(config);

ZOHO.CREATOR.DATA.updateRecordById(config).then(function (response) {
  // console.log(response);
  if (response.code == 3000) {
    // const fname = CloseCashClaimModal();
    showFancyAlert(alert_details,CloseModal);
      fetchcashclaim();
      onload_initial_updates();
      count_of_pending_cash_claim();
    // filterCashClaim();

  }
});  
});

} 
}
catch(e)
{
let error_message = e.message;
let error_reference = e.stack; 
let fn_name = "UpdateClaim";
let error_msg =`
      fnction: ${fn_name},
      error_message: ${error_message},
      error_reference: ${error_reference}` 
}

}
   
document.addEventListener("DOMContentLoaded", function () {
  const mainApp = document.getElementById('main-app');
  const deliveryBox = document.getElementById('delivery-pending-box');
  const deliveryCardsContainer = document.getElementById('delivery-cards-container');

  if (!mainApp || !deliveryBox || !deliveryCardsContainer) return;

  deliveryBox.addEventListener('click', function () {
    if (window._pendingDeliveryCount === 0) {
    showPendingDeliveryPopup();
    return; // Do not open the delivery cards page
  }
    mainApp.style.display = 'none';
    deliveryBox.style.display = 'none';
    deliveryCardsContainer.style.display = 'block';

    // Inject cards page content if not already present
    if (!document.getElementById('cardsContainer')) {
deliveryCardsContainer.innerHTML = `
  <div id="delivery-cards-header" class="fixed top-0 left-0 w-full z-50 bg-white flex items-center p-3 shadow-lg border-b border-gray-100" style="min-height:56px;">
    <button id="delivery-back-btn" class="flex items-center bg-[#2563eb] hover:bg-[#1d4ed8] text-white px-3 py-2 rounded-lg shadow-sm transition-all duration-300 text-sm font-medium mr-4 hover:scale-105 active:scale-95">
      <i class="fa-solid fa-arrow-left mr-2 text-sm"></i>
      Back
    </button>
    <h2 class="text-xl font-semibold text-gray-800 flex-1">Delivery Pending Orders</h2>
  </div>
  <div class="cards-grid" id="cardsContainer" style="margin-top:62px;"></div>
`;
    }

    renderDeliveryCards();

    // Back button handler
    setTimeout(() => {
      const backBtn = document.getElementById('delivery-back-btn');
      if (backBtn) {
        backBtn.onclick = function () {
          deliveryCardsContainer.style.display = 'none';
          mainApp.style.display = '';
          deliveryBox.style.display = '';
          get_pending_order_count();
        };
      }
    }, 0);
  });

  // Delivery data and render logic
  async function renderDeliveryCards(page = 1) {
retail_pending_data = [];
  // Get employee info
  const response = await ZOHO.CREATOR.UTIL.getQueryParams();
  const login = JSON.parse(response.login_details);
  const Employee_record_id = login.Employee_Rec_Id;

  // Prepare config
  const config = {
    app_name: "chaizup-order-to-delivery",
    report_name: "All_Retail_Orders",
    criteria: `(Order_Taken_By == ${Employee_record_id} && Delivery_Status == "Pending")`
  };

  // Await the records fetch
  const recordsResponse = await ZOHO.CREATOR.DATA.getRecords(config);
  const taskInfo = recordsResponse.data || [];
  retail_pending_data.push(...taskInfo);

  console.log("retail card deta", retail_pending_data);

const deliveryData = retail_pending_data.map(item => ({
    id: item.ID,
    shopName: item.Shop_Name?.Shop_Name || "",
    beatName: item.Beat?.Beat_Name || "",
    orderDate: item.Order_Date || "",
    orderAmount: item.Total_Amount || ""
  }));

  const cardsPerPage = 5;
  const totalPages = Math.ceil(deliveryData.length / cardsPerPage);
  const cardsContainer = document.getElementById('cardsContainer');
  if (!cardsContainer) return;

  // Calculate which cards to show
  const startIdx = (page - 1) * cardsPerPage;
  const endIdx = startIdx + cardsPerPage;
  const cardsToShow = deliveryData.slice(startIdx, endIdx);

  // Render cards
  cardsContainer.innerHTML = '';
  cardsToShow.forEach(data => {
    const card = document.createElement('div');
    card.className = 'delivery-card';
    card.id = `card-${data.id}`;
    card.innerHTML = `
      <div class="card-header">
        <div class="shop-info">
          <div class="icon-container">
            <i class="fa-solid fa-shop text-xl text-gray-700" style="font-size: 25px;"></i>
          </div>
          <div class="shop-details">
            <h3>${data.shopName}</h3>
            <div class="location">
              <svg class="location-icon" viewBox="0 0 24 24">
                <path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"/>
                <circle cx="12" cy="10" r="3"/>
              </svg>
              <span>${data.beatName}</span>
            </div>
          </div>
        </div>
        <button class="delivery-btn" onclick="markDelivered('${data.id}')">
          Mark Delivered
        </button>
      </div>
      <div class="order-details">
        <div class="detail-row">
          <div class="detail-label">
            <svg class="detail-icon" viewBox="0 0 24 24">
              <rect x="3" y="4" width="18" height="18" rx="2" ry="2"/>
              <line x1="16" y1="2" x2="16" y2="6"/>
              <line x1="8" y1="2" x2="8" y2="6"/>
              <line x1="3" y1="10" x2="21" y2="10"/>
            </svg>
            <span>Order Date</span>
          </div>
          <span class="detail-value">${data.orderDate}</span>
        </div>
        <div class="detail-row">
          <div class="detail-label">
            <svg class="detail-icon" viewBox="0 0 24 24">
              <path d="M6 3h12l2 6v8a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V9l2-6z"/>
              <path d="M6 3v6"/>
              <path d="M18 3v6"/>
              <path d="M6 15h12"/>
            </svg>
            <span>Amount</span>
          </div>
          <span class="detail-value amount">${data.orderAmount}</span>
        </div>
      </div>
      <div class="success-overlay">
        <div class="success-content">
          <div class="success-icon-container">
            <svg class="success-icon" viewBox="0 0 24 24">
              <path d="M20 6L9 17l-5-5"/>
            </svg>
          </div>
          <h4 class="success-title">Success!</h4>
          <p class="success-text">Order marked delivered successfully</p>
        </div>
      </div>
    `;

  // Add click event to the card (but ignore clicks on the button)
  card.addEventListener('click', function(e) {
  // Prevent card click if the button (or its child) was clicked
  if (e.target.closest('.delivery-btn')) return;
try{
let config_ = {
    action : "open",
    url : "https://o2d.zohocreatorportal.in/chaizup/chaizup-order-to-delivery/record-summary/All_Retail_Orders/" + data.id,
    window : "same"
}
ZOHO.CREATOR.UTIL.navigateParentURL(config_);
}
catch(e)
{
console.log(e.message);
console.log(e.stack);

}


  });

    cardsContainer.appendChild(card);
  });

 // ...inside renderDeliveryCards(page = 1)...
// Remove existing pagination if it exists
const existingPagination = document.getElementById('paginationContainer');
if (existingPagination) {
  existingPagination.remove();
}

// Determine button states
const isFirst = page === 1;
const isLast = page === totalPages;

// Button classes
const activeBtn = "w-45 px-4 py-1.5 rounded-lg text-sm font-medium border transition-colors text-white border-blue-600 bg-[#2563eb] hover:bg-[#1d4ed8] hover:shadow-sm";
const disabledBtn = "w-45 px-4 py-1.5 rounded-lg text-sm font-medium border border-gray-200 bg-gray-100 text-gray-600 opacity-50 cursor-not-allowed";

// Create pagination container
const paginationContainer = document.createElement('div');
paginationContainer.id = 'paginationContainer';
paginationContainer.className = 'flex justify-between items-center px-2 py-2 rounded-lg bg-white shadow w-[90vw] max-w-[500px] mx-auto mb-4 mt-4';

const paginationHTML = `
  <button id="prevPageBtn" class="${isFirst ? disabledBtn : activeBtn}" ${isFirst ? 'disabled' : ''}><i class="fa-solid fa-arrow-left"></i>
    Previous
  </button>
  <span class="px-3 py-1.5 text-sm font-medium text-gray-700 bg-white rounded-lg border border-gray-200">
    Page ${page} of ${totalPages}
  </span>
  <button id="nextPageBtn" class="${isLast ? disabledBtn : activeBtn}" ${isLast ? 'disabled' : ''}>
    Next <i class="fa-solid fa-arrow-right"></i>
  </button>
`;

paginationContainer.innerHTML = paginationHTML;
cardsContainer.parentNode.insertBefore(paginationContainer, cardsContainer.nextSibling);

// Pagination button handlers
const prevBtn = document.getElementById('prevPageBtn');
const nextBtn = document.getElementById('nextPageBtn');

if (prevBtn && !isFirst) {
  prevBtn.onclick = () => renderDeliveryCards(page - 1);
}
if (nextBtn && !isLast) {
  nextBtn.onclick = () => renderDeliveryCards(page + 1);
}
}

window.markDelivered = function(cardId) {
  const card = document.getElementById(`card-${cardId}`);
  const button = card.querySelector('.delivery-btn');
  const iconContainer = card.querySelector('.icon-container');
  const shopIcon = card.querySelector('.fa-shop');
  const overlay = card.querySelector('.success-overlay');
  if (button.classList.contains('delivered') || button.classList.contains('not-delivered')) return;

  // Disable the button immediately
  button.disabled = true;
  button.classList.add('opacity-50', 'cursor-not-allowed');
  overlay.classList.add('show');

  let config = {
    app_name: "chaizup-order-to-delivery",
    report_name: "All_Retail_Orders",
    id: cardId,
    payload: {
      "data": {
        "Delivery_Status": "Delivered"
      }
    }
  };

  ZOHO.CREATOR.DATA.updateRecordById(config).then(function (response) {
    // Success
    if (response.code == 3000) {
      setTimeout(() => {
        card.classList.add('delivered');
        iconContainer.classList.add('delivered');
        shopIcon.classList.add('delivered');
        button.classList.add('delivered');
        button.innerHTML = `<svg style="width: 16px; height: 16px; stroke: #15803d; stroke-width: 2; fill: none; flex-shrink: 0;" viewBox="0 0 24 24"><path d="M20 6L9 17l-5-5"/></svg><span>Delivered</span>`;
        const orderDetails = card.querySelector('.order-details');
        const successStatus = document.createElement('div');
        successStatus.className = 'success-status';
        successStatus.innerHTML = `<div class="status-dot" style="background:#22c55e"></div><span style="font-size: 14px; font-weight: 500; color:#15803d;">Order Delivered Successfully</span>`;
        orderDetails.parentNode.insertBefore(successStatus, orderDetails.nextSibling);
        setTimeout(() => {
          overlay.classList.remove('show');
        }, 2000);
      }, 300);
    } else {
      // Failure: Show error UI
      let errorMsg = "Failed to update data.";
      if (response.error && Array.isArray(response.error) && response.error[0]?.alert_message) {
        errorMsg = response.error[0].alert_message[0];
      } else if (response.error && Array.isArray(response.error) && response.error[1]?.message) {
        errorMsg = response.error[1].message;
      }

      setTimeout(() => {
        // Add not-delivered styles
        card.classList.add('not-delivered');
        card.style.background = "#ffeaea"; // light red
        iconContainer.classList.remove('delivered');
        shopIcon.classList.remove('delivered');
        button.classList.remove('delivered');
        button.classList.add('not-delivered');
        button.innerHTML = `<svg style="width: 16px; height: 16px; stroke:rgb(255, 255, 255); stroke-width: 2; fill: none; flex-shrink: 0;" viewBox="0 0 24 24"><path d="M6 6L18 18M6 18L18 6"/></svg><span style="color: white;">Not Delivered</span>`;
        const orderDetails = card.querySelector('.order-details');
        // Remove previous status if any
        let prevStatus = card.querySelector('.success-status');
        if (prevStatus) prevStatus.remove();
        // Add error status
        const errorStatus = document.createElement('div');
        errorStatus.className = 'success-status';
        errorStatus.innerHTML = `<div class="status-dot" style="background:#dc2626"></div><span style="font-size: 14px; font-weight: 500; color:#dc2626;">${errorMsg}</span>`;
        orderDetails.parentNode.insertBefore(errorStatus, orderDetails.nextSibling);
        overlay.classList.remove('show');
      }, 300);
    }
  });
};

});
 
function get_pending_order_count() {
  ZOHO.CREATOR.UTIL.getQueryParams().then((response) => {
    response = JSON.parse(response.login_details);
    let Employee_record_id = response.Employee_Rec_Id;

    let pending_order_count = {
      app_name: "chaizup-order-to-delivery",
      report_name: "All_Retail_Orders",
      criteria: `(Order_Taken_By == ${Employee_record_id} && Delivery_Status == "Pending")`,
    };

    ZOHO.CREATOR.DATA.getRecordCount(pending_order_count).then(function (response) {
      let pending_order_count_num = Number(response.result.records_count);
      console.log("Pending Delivery Count:", pending_order_count_num);
      console.log("Pending Delivery Count Response:", pending_order_count);
      // Update the count and its color dynamically
const countSpan = document.querySelector("#delivery-pending-box .count");
if (countSpan) {
  countSpan.textContent = pending_order_count_num;
  countSpan.classList.remove("text-red-600", "text-green-600");
  countSpan.classList.add(
    pending_order_count_num === 0 ? "text-green-600" : "text-red-600"
  );
}

      // Store the count for click handler
      window._pendingDeliveryCount = pending_order_count_num;
    });
  });
}

function handleDeliveryPendingClick() {
  if (Number(window._pendingDeliveryCount) === 0) {
    showPendingDeliveryPopup();
    return;
  } 

}

// Show popup
function showPendingDeliveryPopup() {
  const popup = document.getElementById('pending-delivery-popup');
  if (popup) popup.classList.remove('hidden');
}

// Hide popup
function hidePendingDeliveryPopup() {
  const popup = document.getElementById('pending-delivery-popup');
  if (popup) popup.classList.add('hidden');
}

// Attach close event
document.addEventListener('DOMContentLoaded', function () {
  const closeBtn = document.getElementById('close-pending-popup');
  if (closeBtn) {
    closeBtn.addEventListener('click', hidePendingDeliveryPopup);
  }
  // Optional: close popup on overlay click
  const popup = document.getElementById('pending-delivery-popup');
  if (popup) {
    popup.addEventListener('click', function (e) {
      if (e.target === popup) hidePendingDeliveryPopup();
    });
  }
});
          //       ##       ## ########    ###     ######  ########      ##     ## ######## ########  #### ######## ####  ######     ###    ######## ####  #######  ##    ##      ##     ##  #######  ########     ###    ##       
          //      ##       ##  ##         ## ##   ##    ## ##            ##     ## ##       ##     ##  ##  ##        ##  ##    ##   ## ##      ##     ##  ##     ## ###   ##      ###   ### ##     ## ##     ##   ## ##   ##       
          //     ##       ##   ##        ##   ##  ##       ##            ##     ## ##       ##     ##  ##  ##        ##  ##        ##   ##     ##     ##  ##     ## ####  ##      #### #### ##     ## ##     ##  ##   ##  ##       
          //    ##       ##    ######   ##     ## ##       ######        ##     ## ######   ########   ##  ######    ##  ##       ##     ##    ##     ##  ##     ## ## ## ##      ## ### ## ##     ## ##     ## ##     ## ##       
          //   ##       ##     ##       ######### ##       ##             ##   ##  ##       ##   ##    ##  ##        ##  ##       #########    ##     ##  ##     ## ##  ####      ##     ## ##     ## ##     ## ######### ##       
          //  ##       ##      ##       ##     ## ##    ## ##              ## ##   ##       ##    ##   ##  ##        ##  ##    ## ##     ##    ##     ##  ##     ## ##   ###      ##     ## ##     ## ##     ## ##     ## ##       
          // ##       ##       ##       ##     ##  ######  ########         ###    ######## ##     ## #### ##       ####  ######  ##     ##    ##    ####  #######  ##    ##      ##     ##  #######  ########  ##     ## ######## 

        // use cases of below variable : if in query paramter user image not foud we will confirm that new images submitted or not
let  new_image_added = false; // if user newly submitted image then this will be true
   let type = "";
   let added = "";
   let face_verification = false;
   const video = document.getElementById('video');
    const canvas = document.getElementById('canvas');
    const captureBtn = document.getElementById('capture-btn');
    const btnText = document.getElementById('btn-text');
    const statusTitle = document.getElementById('status-title');
    const statusMessage = document.getElementById('status-message');
    const cameraContainer = document.getElementById('camera-container');
    const statusIconContainer = document.getElementById('status-icon-container');
    const successIcon = document.getElementById('success-icon');
    const failureIcon = document.getElementById('failure-icon');
    const scanner = document.getElementById('scanner');
    const progressRing = document.getElementById('progress-ring');
    const progressCircle = document.querySelector('.progress-ring-circle');
    const radius = progressCircle.r.baseVal.value;
    const circumference = radius * 2 * Math.PI;
    
    // Modal specific DOM elements
    const loginBtn = document.getElementById('loginBtn');
    const logoutBtn = document.getElementById('logoutBtn');
    const faceVerificationModal = document.getElementById('faceVerificationModal');
    const closeModalBtn = document.getElementById('closeModalBtn');
    
    // New DOM elements for the "Add Image" feature
    const addImageBtn = document.getElementById('add-image-btn');
    const addBtnText = document.getElementById('add-btn-text');
    
    let stream = null;
    let isProcessing = false;
    
    // --- Initialize Camera ---
    async function initCamera() {
        try {
            const constraints = { video: { facingMode: 'user', width: { ideal: 480 }, height: { ideal: 480 } } };
            stream = await navigator.mediaDevices.getUserMedia(constraints);
            video.srcObject = stream;
            video.style.transform = "scaleX(1)";
        } catch (err) {
            console.error("Error accessing camera: ", err);
            statusTitle.textContent = "Camera Error";
            statusMessage.textContent = "Please allow camera access in your browser settings.";
            captureBtn.disabled = true;
        }
    }
    
    // --- Stop Camera Stream ---
    function stopCamera() {
        if (stream) {
            stream.getTracks().forEach(track => track.stop());
            stream = null;
        }
    }
    
    // --- Reset UI to initial state ---
    function resetUI() {

      
        isProcessing = false;
        statusTitle.textContent = "Face Attendance";
        statusMessage.textContent = "Center your face within the circle";
        statusMessage.classList.remove('text-green-400', 'text-red-400');
        statusMessage.classList.add('text-gray-400');
        
        btnText.textContent = "Capture & Verify";
        captureBtn.disabled = false;
        captureBtn.classList.remove('hidden'); // Ensure the original button is visible
        addImageBtn.classList.add('hidden'); // Hide the new button
        
        cameraContainer.classList.remove('verified-state', 'failed-state');
        statusIconContainer.classList.add('opacity-0', 'pointer-events-none');
        successIcon.classList.add('hidden');
        failureIcon.classList.add('hidden');
        successIcon.classList.remove('icon-enter');
        failureIcon.classList.remove('icon-enter');
    
        scanner.classList.remove('opacity-0');
        progressRing.classList.add('opacity-0');
        progressCircle.style.strokeDashoffset = circumference;
          ShowAddButton();
        // Re-initialize camera only if modal is open and camera is needed
        if (!faceVerificationModal.classList.contains('hidden')) { 
            initCamera();

        }
    }
    
    // --- New function to handle the "Add Image" logic ---
    
    // --- Handle Capture and Verification ---
    captureBtn.addEventListener('click', async () => {
        if (isProcessing) return;
        if (btnText.textContent === "Try Again") {
            resetUI();
            return;
        }
        
        isProcessing = true;
        // captureBtn.disabled = true;
        
        // 1. Capture frame
        statusMessage.textContent = "Verifying Wait 10 Sec...";
        const context = canvas.getContext('2d');
        canvas.width = video.videoWidth;
        canvas.height = video.videoHeight;
        context.drawImage(video, 0, 0, canvas.width, canvas.height);
        
        let capturedBase64Image = canvas.toDataURL('image/png');
        
        if (capturedBase64Image === "data:,") {
            // Handle error case if image capture fails
            console.error("Image capture failed.");
        } else {
            console.log("check capture");
            getLabourIdByFace(capturedBase64Image,"Verify"); // Call existing function for verification
        }
    
        // 2. Start verification animation
        statusMessage.textContent = "Analyzing...";
        scanner.classList.add('opacity-0');
        progressRing.classList.remove('opacity-0');
        progressCircle.style.strokeDashoffset = 0; // Animate progress
        
        // Stop camera after a short delay
        setTimeout(() => {
            stopCamera();
        }, 500);
    });
    
    // --- New "Add Image" button event listener ---
    addImageBtn.addEventListener('click', async () => {
        if (isProcessing) return;
          if (addImageBtn.textContent === "Try Again") {

            resetUI();
            addImageBtn.textContent ="Capture Face";
            addImageBtn.disabled = false;
            // AddEmployeeCloud(base64);
            return;
        }
        
        isProcessing = true;
        // addImageBtn.disabled = true;
        
        statusMessage.textContent = "Capturing image Wait 20 Seconds...";
        const context = canvas.getContext('2d');
        canvas.width = video.videoWidth;
        canvas.height = video.videoHeight;
        context.drawImage(video, 0, 0, canvas.width, canvas.height);
        
        const capturedBase64Image = canvas.toDataURL('image/png');
        
        if (capturedBase64Image === "data:,") {
            console.log("Image capture failed for adding face data.");
            statusTitle.textContent = "Error";
            statusMessage.textContent = "Could not capture image. Please try again.";
            addImageBtn.disabled = false;
            isProcessing = false;
        } else {
            console.log("Image captured for adding face data.");
            AddEmployeeCloud(capturedBase64Image);
            // addFaceData(capturedBase64Image); // Call the new function
            stopCamera(); // Stop camera after capture
        }
    });
    
    // --- Modal Control ---
    loginBtn.addEventListener('click', () => {
        type = 'LOG IN';
        faceVerificationModal.classList.remove('hidden'); // Show the modal
        resetUI(); // Initialize camera and reset UI when modal opens
        ShowAddButton(); // Call the function to check and show the add button
    });

     logoutBtn.addEventListener('click', () => {
        type = 'LOG OUT';
        faceVerificationModal.classList.remove('hidden'); // Show the modal
        resetUI(); // Initialize camera and reset UI when modal opens
        ShowAddButton(); // Call the function to check and show the add button
    });
    
    closeModalBtn.addEventListener('click', () => {
        faceVerificationModal.classList.add('hidden'); // Hide the modal
        stopCamera(); // Stop camera when modal closes
        resetUI(); // Reset UI state for next opening
    });
    
    // Close modal if user clicks outside of it
    faceVerificationModal.addEventListener('click', (e) => {
        if (e.target === faceVerificationModal) {
            faceVerificationModal.classList.add('hidden'); // Hide the modal
            stopCamera();
            resetUI();
        }
    });
    
    // --- Initial Setup (moved inside modal control for efficiency) ---
    window.addEventListener('load', () => {
        progressCircle.style.strokeDasharray = `${circumference} ${circumference}`;
        progressCircle.style.strokeDashoffset = circumference;
    });


    function resetUIAndStartCamera() {
    // Reset all UI elements to their initial state
    // initCamera();
    progressRing.classList.remove('opacity-0');
    statusIconContainer.classList.add('opacity-0', 'pointer-events-none');
    statusTitle.textContent = "Please capture your face";
    statusMessage.textContent = "Position your face in the center of the frame.";
    statusMessage.classList.replace('text-red-400', 'text-gray-400');
    cameraContainer.classList.remove('failed-state');
    failureIcon.classList.add('hidden');
    failureIcon.classList.remove('icon-enter');

    // Reset processing state and button states
    isProcessing = false;
    captureBtn.disabled = false;
    addImageBtn.disabled = false;
    addImageBtn.classList.remove('hidden'); // show the "Add Image" button initially
    captureBtn.classList.add('hidden'); // hide the "Capture" button initially
    btnText.textContent = "Capture";

    // Restart the camera
    initCamera(); // Make sure you have a function called startCamera()
}

    
    function ShowAddButton() {
    
      
        ZOHO.CREATOR.UTIL.getQueryParams().then(function (response_params) {
            const log_in_details = JSON.parse(response_params.login_details);
            let image = log_in_details.get_image;
            console.log("image",image);
            if (image == null || image == "" && !new_image_added) {
                // Show the "Add Image" button and hide the "Capture & Verify" button
                console.log("No image found");
                captureBtn.classList.add('hidden');
                addImageBtn.classList.remove('hidden');
                btnText.textContent = "Add Face"; // Update the text of the existing button if needed
            } else {
                // Hide the "Add Image" button if an image already exists
                console.log("Image Found");
                addImageBtn.classList.add('hidden');
                captureBtn.classList.remove('hidden');
                btnText.textContent = "Capture & Verify";
            }
        });
    }

    function ShowVerificationMessage(isVerified)
    {

       // --- SIMULATED VERIFICATION ---
            // await new Promise(resolve => setTimeout(resolve, 2500));    
            // const isVerified = Math.random() > 0.3; // 70% chance of success

            // 3. Show result
            progressRing.classList.add('opacity-0');
            statusIconContainer.classList.remove('opacity-0', 'pointer-events-none');

            if (isVerified) {

                     //first remove the failed state
                      cameraContainer.classList.remove('failed-state');
                      failureIcon.classList.add('hidden');
                      failureIcon.classList.remove('icon-enter');



                statusTitle.textContent = "Verified!";
                statusMessage.textContent = "Attendance marked successfully.";
                statusMessage.classList.replace('text-gray-400', 'text-green-400');
                cameraContainer.classList.add('verified-state');
                successIcon.classList.remove('hidden');
                successIcon.classList.add('icon-enter');
                btnText.textContent = "Done";
            } else {
                     //first remove the success state
                     cameraContainer.classList.remove('verified-state');
                    successIcon.classList.add('hidden');
                    successIcon.classList.remove('icon-enter');

                //failed state
                statusTitle.textContent = "Verification Failed";
                statusMessage.classList.replace('text-gray-400', 'text-red-400');
                statusMessage.textContent = "Could not verify face. Please try again.";
                cameraContainer.classList.add('failed-state');
                failureIcon.classList.remove('hidden');
                failureIcon.classList.add('icon-enter');
                captureBtn.disabled = false;
                btnText.textContent = "Try Again";
            }
            isProcessing = false;
        


    }   
   async function GetQueryParams() {
    return ZOHO.CREATOR.UTIL.getQueryParams()
        .then(function(response_params) {
            const log_in_details = JSON.parse(response_params.login_details);
            return log_in_details;
        })
        .catch(function(error) {
            console.error("Error fetching query params:", error);
            // Optionally, re-throw the error or return a specific value like null
            throw error;
        });
}

    async function AddEmployeeCloud(base64) {
        
      let is_valid =  await getLabourIdByFace(base64,"Add");
      console.log("is_valid", is_valid);
      if(!is_valid){
        return;
      }
 
        // console.log("base64",base64);
        let employee_details = await GetQueryParams();
        console.log("employee_details", employee_details);
        if(added === "added")
        {
          return;

        }

    
  
    // resetUIAndStartCamera();

    // resetUI();

      // Initialize camera and reset UI when modal opens
    //  ShowAddButton(); // Call the function to check and show the add button
     

    if (!employee_details) {
      console.log("Failed to retrieve employee details");
      return;
    }
    const emlployee_name = employee_details.Employee_Name;
   const employee_rec_id = employee_details.Employee_Rec_Id;
   const access_id = employee_details.get_access_id;
   console.log("access_id",access_id);

  try {
    let pureBase64 = base64.replace("data:image/png;base64,", "");


    const sanitize = (value) => {
      return value !== undefined && value !== null && String(value).trim() !== "" ? value : "NA";
    };

    const data = {
      address: sanitize("NA"),
      adhaar: sanitize("NA"),
      contractor_id: sanitize("NA"),
      dob: sanitize("NA"),
      doj: sanitize("NA"),
      gender: sanitize("NA"),
      lid: sanitize(employee_rec_id),
      name: sanitize(emlployee_name),
      pan: sanitize("NA"),
      phone_number: sanitize("NA"),
      zc_id: sanitize(employee_rec_id),
      images_base64: [pureBase64]
    };

    const url = "https://pehchan-api-2-803399936090.asia-south1.run.app/labour/api/create";
    const response = await fetch(url, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data)
    });
    console.log("response",response);
    if (!response.ok) {
    console.log("errror in addlabourcloud",response);

   // first remove the success state
    cameraContainer.classList.remove('verified-state');
    successIcon.classList.add('hidden');
    successIcon.classList.remove('icon-enter');



    
    progressRing.classList.add('opacity-0');
    statusIconContainer.classList.remove('opacity-0', 'pointer-events-none');
    statusTitle.textContent = "Failed to Add";
    statusMessage.classList.replace('text-gray-400', 'text-red-400');
    statusMessage.textContent = JSON.stringify(response);
   
    cameraContainer.classList.add('failed-state');
    failureIcon.classList.remove('hidden');
    failureIcon.classList.add('icon-enter');
    captureBtn.disabled = false;
    btnText.textContent = "Try Again"
    

    }

    const result = await response.json();
    if(result?.status =="success" && added !=="added")
    {
        console.log("result",result);
       added = "added";

       //first remove the failed state
       cameraContainer.classList.remove('failed-state');
       failureIcon.classList.add('hidden');
       failureIcon.classList.remove('icon-enter');
     
     
        statusMessage.classList.remove('text-gray-400', 'text-red-400');
        statusMessage.classList.add('text-green-400');
        statusTitle.textContent = "Success!";
        statusMessage.textContent = "Face image added successfully.";
        cameraContainer.classList.add('verified-state');
        statusIconContainer.classList.remove('opacity-0', 'pointer-events-none');
        successIcon.classList.remove('hidden');
        successIcon.classList.add('icon-enter');

         new_image_added = true;
        
        // btnText.textContent = "Close";
        // captureBtn.disabled = false;
        // addImageBtn.classList.add('hidden');
        // captureBtn.classList.remove('hidden');
        // btnText.textContent = "Capture & Verify";
        // isProcessing = false;
        
        // Set this to true to indicate a new image was added
        setTimeout(() => {
            resetUI();
         },2000); // Reset UI and restart camera after a delay   

       
      
    }
    console.log("Success:", result);
    if(result.detail !== undefined && result.detail !== "")
    {
    console.log("result detail", result.detail);

    //first remove the sucess state
    cameraContainer.classList.remove('verified-state');
    successIcon.classList.add('hidden');
    successIcon.classList.remove('icon-enter');




    progressRing.classList.add('opacity-0');
    statusIconContainer.classList.remove('opacity-0', 'pointer-events-none');
    statusMessage.classList.replace('text-gray-400', 'text-red-400');
    statusTitle.textContent = "Could Not Add";
    statusMessage.textContent =result.detail;
    cameraContainer.classList.add('failed-state');
    failureIcon.classList.remove('hidden');
    failureIcon.classList.add('icon-enter');
    
    addImageBtn.disabled = false;
    addImageBtn.textContent = "Try Again";
    isProcessing = false;


    }
  

    const img_url = result?.data?.image_urls?.[0];
    console.log("img_url", img_url);

  
    const Img_URL = img_url;
    console.log("Img_URL", Img_URL);
    let capturedImageFile = dataURLtoFile(base64, "captured_photo.png");
    if(Img_URL!=null && access_id!=null && base64!=null)
    {

   console.log("calling addfaceverification inside addemployeecloud");
    // await UpdateImageUrl(access_id, Img_URL);
    // uploadCapturedImage(access_id,capturedImageFile,"All_O2d_Access_Controls");
     await AddFaceVerification(employee_rec_id,Img_URL,capturedImageFile);
    } // ✅ Use await
  

  }
   catch (error) {
    console.log("Error in AddLabourCloud:", error);
      //first remove the sucess state
    cameraContainer.classList.remove('verified-state');
    successIcon.classList.add('hidden');
    successIcon.classList.remove('icon-enter');



    progressRing.classList.add('opacity-0');
    statusIconContainer.classList.remove('opacity-0', 'pointer-events-none');
    statusTitle.textContent = "Could not Add";
 
    statusMessage.classList.replace('text-gray-400', 'text-red-400');
    statusMessage.textContent = JSON.stringify(error);
    cameraContainer.classList.add('failed-state');
    failureIcon.classList.remove('hidden');
    failureIcon.classList.add('icon-enter');
    
    addImageBtn.disabled = false;
    addImageBtn.textContent = "Try Again";
    isProcessing = false;
  
  }
  


}

async function UpdateImageUrl(ID, Img_URL) {
  

  try {
    console.log("update function called", ID, Img_URL);

    let config = {
      app_name: "chaizup-order-to-delivery",
      report_name: "All_O2d_Access_Controls",
      id: ID,
      payload: {
        data: {
          "Image_Url": Img_URL
         
        }
      }
    };

    const response = await ZOHO.CREATOR.DATA.updateRecordById(config);
    console.log("response", response);

    if (response.code == 3000) {
      console.log("✅ Image URL updated successfully", response);
      
    } else {
    console.log("❌ Failed to update. Response code:", response.code);
    // progressRing.classList.add('opacity-0');
    // statusIconContainer.classList.remove('opacity-0', 'pointer-events-none');
    // statusTitle.textContent = "Could Not Add";
    // statusMessage.textContent ="Unable to Update Image URL";
    // statusMessage.classList.replace('text-gray-400', 'text-red-400');
    // cameraContainer.classList.add('failed-state');
    // failureIcon.classList.remove('hidden');
    // failureIcon.classList.add('icon-enter');
    
    // addImageBtn.disabled = false;
    // addImageBtn.textContent = "Try Again";
    // isProcessing = false;
        
      
    }

  } catch (error) {
    console.log("❌ Error in UpdateImageUrl:", error);
    progressRing.classList.add('opacity-0');
    statusIconContainer.classList.remove('opacity-0', 'pointer-events-none');
    statusTitle.textContent = "Could Not Add";
    statusMessage.textContent ="Unable to Update Image URL";
    statusMessage.classList.replace('text-gray-400', 'text-red-400');
    cameraContainer.classList.add('failed-state');
    failureIcon.classList.remove('hidden');
    failureIcon.classList.add('icon-enter');
    
    addImageBtn.disabled = false;
    addImageBtn.textContent = "Try Again";
    isProcessing = false;
  }
}






  async function getLabourIdByFace(base64,check) {
       let queryParams = await ZOHO.CREATOR.UTIL.getQueryParams();
   let response = JSON.parse(queryParams.login_details);
   let emp_rec_id = response?.Employee_Rec_Id;
   let face = response?.get_face_verification;
  let pureBase64 = base64.replace("data:image/png;base64,", "");


  let url = "https://pehchan-api-2-803399936090.asia-south1.run.app/labour/face_attendance";

  return fetch(url, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({ image_base64: pureBase64 })
  })
  .then(response => {
    if (!response.ok) {
      // show_alert("Error",`${response.status}`);
      console.log("Error",response);
      // throw new Error(`HTTP error! status: ${response.status}`);
      
      
    }
    return response.json();
  })
  .then(async data => {
    console.log("Response from server:", data);
   let data_detail = data?.detail;

  

   if(data_detail !== undefined && data_detail !== "" && check =="Add")
   {
    console.log("data_details", data_detail);

    //first remove the sucess state
    cameraContainer.classList.remove('verified-state');
    successIcon.classList.add('hidden');
    successIcon.classList.remove('icon-enter');

    progressRing.classList.add('opacity-0');
    statusIconContainer.classList.remove('opacity-0', 'pointer-events-none');
    statusMessage.classList.replace('text-gray-400', 'text-red-400');
    statusTitle.textContent = "Verification Failed";
    statusMessage.textContent = data_detail;
    cameraContainer.classList.add('failed-state');
    failureIcon.classList.remove('hidden');
    failureIcon.classList.add('icon-enter');
    addImageBtn.classList.remove('hidden');
    captureBtn.classList.add('hidden');
    addImageBtn.disabled = false;
    addImageBtn.textContent = "Try Again";
    isProcessing = false;

   }

if (data_detail !== undefined && data_detail !== "" && check =="Verify") {
 
    console.log("data_details", data_detail);

    //first remove the sucess state
    cameraContainer.classList.remove('verified-state');
    successIcon.classList.add('hidden');
    successIcon.classList.remove('icon-enter');

    progressRing.classList.add('opacity-0');
    statusIconContainer.classList.remove('opacity-0', 'pointer-events-none');
    statusMessage.classList.replace('text-gray-400', 'text-red-400');
    statusTitle.textContent = "Verification Failed";
    statusMessage.textContent = data_detail;
    cameraContainer.classList.add('failed-state');
    failureIcon.classList.remove('hidden');
    failureIcon.classList.add('icon-enter');
    captureBtn.disabled = false;
    btnText.textContent = "Try Again";
    isProcessing = false;

  // show_alert("Error", data_detail);
  return false;
}
    console.log("data",data);
    let labourID = data?.lid;
    let confidence = data?.confidence;
    console.log("labour_ID",labourID);
    console.log("confidence",confidence);
    //if employee id does not match with the emp_rec_id then show failed state
    if(labourID != emp_rec_id  && confidence > 0.65 && check == "Verify" && face==false)
    {
      // show_alert("Error","Employee ID does not match");
      console.log("Employee ID does not match");
      cameraContainer.classList.remove('verified-state');
      successIcon.classList.add('hidden');
      successIcon.classList.remove('icon-enter');

      progressRing.classList.add('opacity-0');
      statusIconContainer.classList.remove('opacity-0', 'pointer-events-none');
      statusMessage.classList.replace('text-gray-400', 'text-red-400');
      statusTitle.textContent = "Verification Failed";
      statusMessage.textContent = "Employee ID does not match";
      cameraContainer.classList.add('failed-state');
      failureIcon.classList.remove('hidden');
      failureIcon.classList.add('icon-enter');
      captureBtn.disabled = false;
      btnText.textContent = "Try Again";
      isProcessing = false;
      return false;
    }

    //if employee image confidence is greater than 0.65 then show success state
     if ( labourID !="" && confidence > 0.65 && check == "Verify") {
      // show_alert("Success","Confidence: "+ confidence);
       let capturedImageFile = dataURLtoFile(base64, "captured_photo.png");
      console.log("confidence",confidence);

      ShowVerificationMessage(true);
   
      AddFacedata(capturedImageFile);

setTimeout(() => {
  if (type === 'LOG IN') {
    open_checkIn_CheckOut_url('LOG IN');
  } else {
    open_checkIn_CheckOut_url('LOG OUT');
  }
}, 2000); // 2000 ms = 2 seconds

    

     
    }
    //if employee image confidence is less than 0.65 then show failed state
     if ( labourID !="" && confidence < 0.65 && check == "Verify") {
       
      //if face verification is true in hr control employee list then skip confidence error and redirect into log in form
 
    let face_verification = response?.get_face_verification;
    console.log("face_verification", face_verification);
    if(face_verification)
    {

      let capturedImageFile = dataURLtoFile(base64, "captured_photo.png");
      AddFacedata(capturedImageFile);
      if(type ==='LOG IN')
      {
       
          open_checkIn_CheckOut_url('LOG IN');
       
          
        
      }
      else{
        
          
          open_checkIn_CheckOut_url('LOG OUT');
         
        
        }
      
      }

    

      // show_alert("Success","Confidence: "+ confidence);
      console.log("confidence",confidence);
     cameraContainer.classList.remove('verified-state');
    successIcon.classList.add('hidden');
    successIcon.classList.remove('icon-enter');

    progressRing.classList.add('opacity-0');
    statusIconContainer.classList.remove('opacity-0', 'pointer-events-none');
    statusMessage.classList.replace('text-gray-400', 'text-red-400');
    statusTitle.textContent = "Verification Failed";
    statusMessage.textContent = "Image Confidence is "+ confidence;
    cameraContainer.classList.add('failed-state');
    failureIcon.classList.remove('hidden');
    failureIcon.classList.add('icon-enter');
    captureBtn.disabled = false;
    btnText.textContent = "Try Again";
    isProcessing = false;
    return false;
    }

    
     
    //if employee is present and confidence is greater than 0.70
    if(labourID !="" && confidence > 0.70 && check =="Add")
    {
      //first remove success state
      cameraContainer.classList.remove('verified-state');
      successIcon.classList.add('hidden');
      successIcon.classList.remove('icon-enter');


      progressRing.classList.add('opacity-0');
      statusIconContainer.classList.remove('opacity-0', 'pointer-events-none');
      statusTitle.textContent = "Could Not Add";
      statusMessage.classList.replace('text-gray-400', 'text-red-400');
      cameraContainer.classList.add('failed-state');
      statusMessage.textContent ="Employee Already Present";
      failureIcon.classList.remove('hidden');
      failureIcon.classList.add('icon-enter');
      console.log("Employee Already Present");
      captureBtn.classList.add('hidden'); // Ensure the original button is visible
      addImageBtn.classList.remove('hidden');
      captureBtn.disabled = false;
      addImageBtn.textContent = "Try Again";
    
      isProcessing = false;
     
    return false;
    }
    //if employee is not present and confidence is less than 0.70
    //then return true
    if(confidence < 0.70 && check == "Add")
    {
      return true;
     
    }

  
    
  
})
}
async function ExistingVerifyFaceOnCloud(base64)
{
  try {
    let url = "https://pehchan-api-2-803399936090.asia-south1.run.app/labour/face_attendance";

    return fetch(url, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({ image_base64: pureBase64 })
    })
    .then(response => {
      if (!response.ok) {
        console.log("Error", response);
      }
      return response.json();
    })
    .then(async data => {
      console.log("Response from server:", data);
      let data_detail = data?.detail;
      let confidence = data?.confidence;
      let labourID = data?.lid;

      if(labourID != "" && confidence > 0.70)
      {
         //first remove success state
      cameraContainer.classList.remove('verified-state');
      successIcon.classList.add('hidden');
      successIcon.classList.remove('icon-enter');

      //add failed state
      progressRing.classList.add('opacity-0');
      statusIconContainer.classList.remove('opacity-0', 'pointer-events-none');
      statusTitle.textContent = "Could Not Add";
      statusMessage.classList.replace('text-gray-400', 'text-red-400');
      cameraContainer.classList.add('failed-state');
      statusMessage.textContent ="Employee Already Present";
      failureIcon.classList.remove('hidden');
      failureIcon.classList.add('icon-enter');
      console.log("Employee Already Present");
      captureBtn.disabled = false;
      btnText.textContent = "Try Again"
      isProcessing = false;


      }
      // Add your logic here
    });
  } catch (e) {
    console.error("Error in ExistingVerifyFaceOnCloud:", e);
  }

}

async function AddFacedata(capturedImageFile)
{
    const response_params = await ZOHO.CREATOR.UTIL.getQueryParams();
    const log_in_details = JSON.parse(response_params.login_details);
    let emp_rec_id = log_in_details.Employee_Rec_Id;
    console.log("Employee Record ID:", emp_rec_id);
    var config = {
      app_name: "chaizup-order-to-delivery",
      form_name: "Face_Verification_Form",
      payload: {
        "data": {
          "Employee_Name": emp_rec_id,
          "Verification_Status": "Verified"
        }
      }
    };
    try {
      const response = await ZOHO.CREATOR.DATA.addRecords(config);
      if (response.code == 3000) {
        // isVerified = true;
        console.log("record added successfully", response);
        let res_data = response.data;
        let rec_id = res_data.ID;
       
        let call_upload = await uploadCapturedImage(rec_id, capturedImageFile, "All_Face_Verifications");


        // showVerificationMessage(isVerified)
        //   show_alert("Employee Verified Successfully", 'text-green-600');
      } else {
        // isVerified = false;
        // showVerificationMessage(isVerified)
      }
    } catch (error) {
      console.error("Error adding record:", error);
      // show_alert("Error", "Failed to add record: " + error.message);
    }
}

function dataURLtoFile(dataurl, filename) {
   
  const arr = dataurl.split(',');
  const matchResult = arr[0].match(/:(.*?);/);
  const mime = matchResult ? matchResult[1] : ''; // Safely handle null case
  // const mime = arr[0].match(/:(.*?);/)[1]; // extract MIME type
  const bstr = atob(arr[1]); // decode base64
  let n = bstr.length;
  const u8arr = new Uint8Array(n);

  while (n--) {
    u8arr[n] = bstr.charCodeAt(n);
  }

  return new File([u8arr], filename, { type: mime });

}

async function uploadCapturedImage(rec_id, capturedImageFile, report_name) {
  try {
    const config = {
      app_name: "chaizup-order-to-delivery",
      report_name: report_name,
      id: rec_id,
      field_name: "Image",
      file: capturedImageFile
    };

    const response = await ZOHO.CREATOR.FILE.uploadFile(config);
    console.log("check uploadcapture image", response);

    return response;
  } catch (error) {
    console.error("Error uploading captured image:", error);
    throw error;
  }
}

function AddAccessData()
 {
 ZOHO.CREATOR.UTIL.getQueryParams().then(function (response_params) {
   const log_in_details = JSON.parse(response_params.login_details);
    let emp_rec_id = log_in_details.Employee_Rec_Id;

    var config = {
  app_name: "chaizup-order-to-delivery",
  form_name: "Accesses",
  payload: {
    "data": {
     "Employee":emp_rec_id,
     "Image":capturedImageFile,
     "Image_Url":""
    
   }
  }
};
ZOHO.CREATOR.DATA.addRecords(config).then(function (response) {
   
  if (response.code == 3000) {
    // isVerified = true;
    console.log("record added successfully",response);
  }
  
});

 });
 }

 async function AddFaceVerification(employee_rec_id,Img_URL,capturedImageFile)
 {

     ZOHO.CREATOR.UTIL.getQueryParams().then(function (response_params) {
   const log_in_details = JSON.parse(response_params.login_details);
   let emp_rec_id = log_in_details.Employee_Rec_Id;
    console.log("Employee Record ID:", emp_rec_id);
    var config = {
  app_name: "chaizup-order-to-delivery",
  form_name: "Face_Verification_Form",
  payload: {
    "data": {
     "Employee_Name":emp_rec_id,
     "Verification_Status":"Verified",
     "Registration_Url_Image":{
      "value":"Img_Url",
      "url":Img_URL
     }
   }
  }
};
ZOHO.CREATOR.DATA.addRecords(config).then(function (response) {
   
  if (response.code == 3000) {
    // isVerified = true;
    console.log("record added successfully",response);
    let res_data = response.data;
     let rec_id = res_data.ID;
      // uploadCapturedImage(rec_id, capturedImageFile,"All_Face_Verifications");
      // showVerificationMessage(isVerified)
        //   show_alert("Employee Verified Successfully", 'text-green-600');
  }
  else
  {
    // isVerified = false;
    // showVerificationMessage(isVerified)
  }
}).catch(function (error) {
    console.error("Error adding record:", error);
    // show_alert("Error", "Failed to add record: " + error.message);
  });
});

 }
